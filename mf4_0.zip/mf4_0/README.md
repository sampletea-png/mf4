# MF4 文件读写系统

## 项目简介

本项目提供一个跨语言的 MF4 (Measurement Data Format version 4) 文件读写解决方案，支持 Python 和 Java 两种编程语言，为汽车行业的测量数据存储和分析提供统一的 API 接口。

## 设计文档

详细的设计文档请参阅 [docs/design](./docs/design/README.md)，包含：

- **数据模型设计** - 核心实体、关系和 JSON Schema
- **类图设计** - Python/Java 类结构、设计模式应用
- **序列图设计** - 读写流程、异常处理、缓存机制
- **泳道图设计** - 多层架构数据流、性能优化
- **API 设计** - Python/Java 统一接口、错误处理
- **文件结构** - 项目组织、依赖管理、构建配置

## 快速开始

### Python

```bash
cd python
pip install -e .
```

```python
from mf4 import Mf4Reader

with Mf4Reader.open("measurement.mf4") as reader:
    signal = reader.read_channel("Engine_Speed")
    print(signal.values)
```

### Java

```xml
<dependency>
    <groupId>com.mf4</groupId>
    <artifactId>mf4-core</artifactId>
    <version>1.0.0</version>
</dependency>
```

```java
import com.mf4.Mf4Reader;

try (Mf4Reader reader = Mf4Reader.open("measurement.mf4")) {
    Signal signal = reader.readChannel("Engine_Speed");
    System.out.println(Arrays.toString(signal.getValues()));
}
```

## 项目结构

```
mf4_0/
├── docs/          # 设计文档
├── python/        # Python SDK
├── java/          # Java SDK
├── shared/        # 共享资源
└── tools/         # 工具脚本
```

## 许可证

MIT License
