"""
测试信号追加功能

验证以下场景：
1. 向已存在的 MF4 文件追加新信号
2. 追加多个信号
3. 追加后读取验证数据完整性
"""

import pytest
import os
import numpy as np

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from mf4 import Mf4Writer, Mf4Reader


class TestSignalAppend:
    """测试信号追加功能"""
    
    def test_basic_append(self, temp_dir):
        """
        测试基本追加功能
        
        流程：
        1. 创建文件并写入初始数据
        2. 打开文件追加新信号
        3. 读取验证
        """
        file_path = os.path.join(temp_dir, "append_test.mf4")
        
        # 第一步：创建初始文件
        timestamps1 = np.linspace(0, 10, 100)
        speed_data = np.random.uniform(1000, 6000, 100)
        
        with Mf4Writer.create(file_path) as writer:
            writer.set_header(
                author="Initial Author",
                project="Append Test"
            )
            writer.add_signal(
                "Engine_Speed",
                timestamps1,
                speed_data,
                unit="rpm",
                comment="Initial engine speed"
            )
        
        # 验证文件已创建
        assert os.path.exists(file_path)
        initial_size = os.path.getsize(file_path)
        
        # 第二步：追加新信号
        timestamps2 = np.linspace(0, 10, 100)
        temp_data = np.random.uniform(70, 105, 100)
        
        with Mf4Writer.open_for_append(file_path) as writer:
            writer.append_signal(
                "Coolant_Temp",
                timestamps2,
                temp_data,
                unit="C",
                comment="Coolant temperature"
            )
        
        # 验证文件已更新
        new_size = os.path.getsize(file_path)
        assert new_size > initial_size
        
        # 第三步：读取验证
        with Mf4Reader.open(file_path) as reader:
            channels = reader.get_channels()
            channel_names = [ch.name for ch in channels]
            
            # 验证两个通道都存在
            assert "Engine_Speed" in channel_names
            assert "Coolant_Temp" in channel_names
            
            # 验证数据
            speed_signal = reader.read_channel("Engine_Speed")
            assert len(speed_signal) == 100
            
            temp_signal = reader.read_channel("Coolant_Temp")
            assert len(temp_signal) == 100
            assert temp_signal.unit == "C"
    
    def test_append_multiple_signals(self, temp_dir):
        """
        测试追加多个信号
        """
        file_path = os.path.join(temp_dir, "multi_append_test.mf4")
        
        # 创建初始文件
        timestamps = np.linspace(0, 50, 500)
        
        with Mf4Writer.create(file_path) as writer:
            writer.set_header(author="Test", project="Multi Append")
            writer.add_signal("Speed", timestamps, np.random.randn(500), unit="rpm")
        
        # 追加多个信号
        with Mf4Writer.open_for_append(file_path) as writer:
            writer.add_signal("Temp1", timestamps, np.random.randn(500), unit="C")
            writer.add_signal("Temp2", timestamps, np.random.randn(500), unit="C")
            writer.add_signal("Pressure", timestamps, np.random.randn(500), unit="bar")
        
        # 验证
        with Mf4Reader.open(file_path) as reader:
            channels = reader.get_channels()
            assert len(channels) >= 4
            
            channel_names = [ch.name for ch in channels]
            for name in ["Speed", "Temp1", "Temp2", "Pressure"]:
                assert name in channel_names
    
    def test_append_preserves_original_data(self, temp_dir):
        """
        测试追加不改变原始数据
        """
        file_path = os.path.join(temp_dir, "preserve_test.mf4")
        
        # 创建原始数据
        timestamps = np.linspace(0, 10, 50)
        original_speed = np.arange(50) * 100.0  # 0, 100, 200, ...
        
        with Mf4Writer.create(file_path) as writer:
            writer.add_signal("Engine_Speed", timestamps, original_speed, unit="rpm")
        
        # 追加新数据
        with Mf4Writer.open_for_append(file_path) as writer:
            writer.append_signal("Throttle", timestamps, np.ones(50) * 50.0, unit="%")
        
        # 验证原始数据未改变
        with Mf4Reader.open(file_path) as reader:
            speed_signal = reader.read_channel("Engine_Speed")
            
            # 验证数据完全一致
            np.testing.assert_array_almost_equal(
                speed_signal.values, original_speed, decimal=5
            )
    
    def test_get_existing_channels(self, temp_dir):
        """
        测试获取已存在的通道
        """
        file_path = os.path.join(temp_dir, "channels_test.mf4")
        
        timestamps = np.linspace(0, 10, 100)
        
        with Mf4Writer.create(file_path) as writer:
            writer.add_signal("Ch1", timestamps, np.random.randn(100))
            writer.add_signal("Ch2", timestamps, np.random.randn(100))
        
        with Mf4Writer.open_for_append(file_path) as writer:
            existing = writer.get_existing_channels()
            
            assert "Ch1" in existing
            assert "Ch2" in existing
            assert len(existing) == 2
    
    def test_channel_exists_check(self, temp_dir):
        """
        测试通道存在性检查
        """
        file_path = os.path.join(temp_dir, "exists_test.mf4")
        
        timestamps = np.linspace(0, 10, 50)
        
        with Mf4Writer.create(file_path) as writer:
            writer.add_signal("Existing", timestamps, np.random.randn(50))
        
        with Mf4Writer.open_for_append(file_path) as writer:
            assert writer.channel_exists("Existing") is True
            assert writer.channel_exists("NonExisting") is False
    
    def test_append_write_read_cycle(self, temp_dir):
        """
        测试完整的追加-读取循环
        """
        file_path = os.path.join(temp_dir, "cycle_test.mf4")
        
        # 第一次写入
        t1 = np.linspace(0, 10, 100)
        v1 = np.sin(t1)
        
        with Mf4Writer.create(file_path) as writer:
            writer.set_header(author="Cycle Test")
            writer.add_signal("Sine", t1, v1, unit="V")
        
        # 第一次追加
        t2 = np.linspace(0, 10, 100)
        v2 = np.cos(t2)
        
        with Mf4Writer.open_for_append(file_path) as writer:
            writer.append_signal("Cosine", t2, v2, unit="V")
        
        # 第二次追加
        t3 = np.linspace(0, 10, 100)
        v3 = t3
        
        with Mf4Writer.open_for_append(file_path) as writer:
            writer.append_signal("Linear", t3, v3, unit="s")
        
        # 最终读取验证
        with Mf4Reader.open(file_path) as reader:
            signals = reader.read_channels(["Sine", "Cosine", "Linear"])
            
            assert "Sine" in signals
            assert "Cosine" in signals
            assert "Linear" in signals
            
            # 验证数据正确
            np.testing.assert_array_almost_equal(signals["Sine"].values, v1, decimal=5)
            np.testing.assert_array_almost_equal(signals["Cosine"].values, v2, decimal=5)
            np.testing.assert_array_almost_equal(signals["Linear"].values, v3, decimal=5)


class TestAppendPerformance:
    """测试追加性能"""
    
    def test_large_append_performance(self, temp_dir):
        """
        测试大数据追加性能
        """
        import time
        
        file_path = os.path.join(temp_dir, "large_append.mf4")
        
        # 创建初始大文件
        num_records = 500_000
        
        timestamps = np.linspace(0, 100, num_records)
        data1 = np.random.randn(num_records)
        
        start_create = time.time()
        with Mf4Writer.create(file_path) as writer:
            writer.add_signal("Data1", timestamps, data1)
        create_time = time.time() - start_create
        
        # 追加大数据
        data2 = np.random.randn(num_records)
        
        start_append = time.time()
        with Mf4Writer.open_for_append(file_path) as writer:
            writer.append_signal("Data2", timestamps, data2)
        append_time = time.time() - start_append
        
        print(f"\n性能测试结果:")
        print(f"  初始创建: {create_time:.2f}s")
        print(f"  追加数据: {append_time:.2f}s")
        
        # 验证数据完整性
        with Mf4Reader.open(file_path) as reader:
            signal1 = reader.read_channel("Data1")
            signal2 = reader.read_channel("Data2")
            
            assert len(signal1) == num_records
            assert len(signal2) == num_records


if __name__ == "__main__":
    pytest.main([__file__, "-v", "-s"])