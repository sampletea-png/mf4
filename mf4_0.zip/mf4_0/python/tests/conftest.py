"""
pytest 配置文件

定义测试 fixture 和共享配置。
"""

import pytest
import os
import numpy as np

from mf4 import Mf4Writer
from mf4.config import Mf4Config

_TEST_OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "test_output")


@pytest.fixture
def temp_dir():
    """测试输出目录 fixture，文件保留在 tests/test_output 下"""
    os.makedirs(_TEST_OUTPUT_DIR, exist_ok=True)
    yield _TEST_OUTPUT_DIR


@pytest.fixture
def sample_mf4_file(temp_dir):
    """创建示例 MF4 文件"""
    file_path = os.path.join(temp_dir, "test_sample.mf4")
    
    # 创建 MF4 文件
    with Mf4Writer.create(file_path) as writer:
        writer.set_header(
            author="Test Author",
            organization="Test Organization",
            project="Test Project",
            comment="Test file for unit tests"
        )
        
        # 添加通道组
        cg_id = writer.add_channel_group("Engine_Data", comment="Engine measurement")
        
        # 添加通道
        writer.add_channel(cg_id, "Engine_Speed", unit="rpm", comment="Engine speed")
        writer.add_channel(cg_id, "Vehicle_Speed", unit="km/h", comment="Vehicle speed")
        writer.add_channel(cg_id, "Throttle_Position", unit="%", comment="Throttle position")
        
        # 创建示例数据
        timestamps = np.linspace(0, 10, 100)
        engine_speed = np.random.uniform(1000, 6000, 100)
        vehicle_speed = np.random.uniform(0, 120, 100)
        throttle = np.random.uniform(0, 100, 100)
        
        # 写入数据
        writer.write_data(
            cg_id,
            timestamps,
            {
                "Engine_Speed": engine_speed,
                "Vehicle_Speed": vehicle_speed,
                "Throttle_Position": throttle,
            }
        )
    
    return file_path


@pytest.fixture
def test_config():
    """测试配置 fixture"""
    return Mf4Config(
        buffer_size=1000,
        cache_size_mb=20,
        validate_on_read=False,
        validate_on_write=True,
    )


@pytest.fixture
def large_mf4_file(temp_dir):
    """创建大型 MF4 文件用于性能测试"""
    file_path = os.path.join(temp_dir, "test_large.mf4")
    
    with Mf4Writer.create(file_path) as writer:
        writer.set_header(author="Large Test")
        
        cg_id = writer.add_channel_group("Large_Data")
        writer.add_channel(cg_id, "Signal_1", unit="V")
        writer.add_channel(cg_id, "Signal_2", unit="A")
        
        # 创建大量数据
        timestamps = np.linspace(0, 1000, 10000)
        signal1 = np.random.uniform(0, 10, 10000)
        signal2 = np.random.uniform(0, 5, 10000)
        
        writer.write_data(
            cg_id,
            timestamps,
            {"Signal_1": signal1, "Signal_2": signal2}
        )
    
    return file_path