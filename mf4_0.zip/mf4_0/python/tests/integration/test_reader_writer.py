"""
集成测试 - 写入和读取
"""

import pytest
import os
import numpy as np

from mf4 import Mf4Reader, Mf4Writer
from mf4.enums import DataType, CompressionType


class TestWriterReader:
    """测试写入和读取"""
    
    def test_create_and_read_basic(self, temp_dir):
        """测试基本创建和读取"""
        file_path = os.path.join(temp_dir, "test_basic.mf4")
        
        # 创建文件
        with Mf4Writer.create(file_path) as writer:
            writer.set_header(
                author="Test Author",
                organization="Test Org",
                project="Test Project"
            )
            
            cg_id = writer.add_channel_group("Test_Data")
            writer.add_channel(cg_id, "Channel_1", unit="V")
            
            timestamps = np.linspace(0, 10, 100)
            data = np.sin(timestamps)
            
            writer.write_data(cg_id, timestamps, {"Channel_1": data})
        
        # 验证文件已创建
        assert os.path.exists(file_path)
        assert os.path.getsize(file_path) > 0
    
    def test_write_multiple_channels(self, temp_dir):
        """测试写入多个通道"""
        file_path = os.path.join(temp_dir, "test_multi.mf4")
        
        with Mf4Writer.create(file_path) as writer:
            writer.set_header(author="Test")
            
            cg_id = writer.add_channel_group("Multi_Data")
            writer.add_channel(cg_id, "Signal_A", unit="V")
            writer.add_channel(cg_id, "Signal_B", unit="A")
            writer.add_channel(cg_id, "Signal_C", unit="W")
            
            timestamps = np.linspace(0, 100, 1000)
            writer.write_data(
                cg_id,
                timestamps,
                {
                    "Signal_A": np.random.uniform(0, 10, 1000),
                    "Signal_B": np.random.uniform(0, 5, 1000),
                    "Signal_C": np.random.uniform(0, 100, 1000),
                }
            )
        
        assert os.path.exists(file_path)
    
    def test_context_manager(self, temp_dir):
        """测试上下文管理器"""
        file_path = os.path.join(temp_dir, "test_context.mf4")
        
        # 测试写入
        with Mf4Writer.create(file_path) as writer:
            writer.set_header(author="Context Test")
            cg_id = writer.add_channel_group("Data")
            writer.add_channel(cg_id, "Test", unit="V")
            writer.write_data(cg_id, np.linspace(0, 1, 10), {"Test": np.zeros(10)})
        
        # 文件应该已自动保存
        assert os.path.exists(file_path)
    
    def test_file_overwrite(self, temp_dir):
        """测试文件覆盖"""
        file_path = os.path.join(temp_dir, "test_overwrite.mf4")
        
        # 第一次创建
        with Mf4Writer.create(file_path) as writer:
            writer.set_header(author="First")
            writer.add_channel_group("Data")
        
        # 第二次创建（覆盖）
        with Mf4Writer.create(file_path) as writer:
            writer.set_header(author="Second")
            writer.add_channel_group("Data")
        
        # 应该成功
        assert os.path.exists(file_path)


class TestMf4Reader:
    """测试读取器"""
    
    def test_reader_context_manager(self, temp_dir):
        """测试读取器上下文管理器"""
        file_path = os.path.join(temp_dir, "test_reader.mf4")
        
        # 先创建文件
        with Mf4Writer.create(file_path) as writer:
            writer.set_header(author="Test")
            writer.add_channel_group("Data")
        
        # 测试读取
        with Mf4Reader.open(file_path) as reader:
            header = reader.header
            assert header is not None
    
    def test_reader_with_config(self, temp_dir, test_config):
        """测试带配置的读取器"""
        file_path = os.path.join(temp_dir, "test_config.mf4")
        
        with Mf4Writer.create(file_path) as writer:
            writer.set_header(author="Test")
            writer.add_channel_group("Data")
        
        with Mf4Reader.open(file_path, config=test_config) as reader:
            assert reader is not None


class TestConverter:
    """测试格式转换"""
    
    def test_to_csv(self, temp_dir):
        """测试转换为 CSV"""
        from mf4 import Mf4Converter
        
        mf4_path = os.path.join(temp_dir, "test.mf4")
        csv_path = os.path.join(temp_dir, "test.csv")
        
        # 创建 MF4 文件
        with Mf4Writer.create(mf4_path) as writer:
            writer.set_header(author="Test")
            cg_id = writer.add_channel_group("Data")
            writer.add_channel(cg_id, "Value", unit="V")
            
            timestamps = np.linspace(0, 1, 10)
            values = np.sin(timestamps)
            writer.write_data(cg_id, timestamps, {"Value": values})
        
        # 转换
        converter = Mf4Converter(mf4_path)
        converter.to_csv(csv_path)
        
        assert os.path.exists(csv_path)
        converter.close()