"""
完整的 MF4 SDK 功能测试

测试 asammdf 库的所有核心功能。
"""

import pytest
import os
import numpy as np
from datetime import datetime, timezone

from mf4 import Mf4Reader, Mf4Writer, Mf4Converter, Mf4Config, Mf4StreamingReader
from mf4.enums import DataType, ChannelType
from mf4.exceptions import Mf4ChannelNotFoundError
from mf4.storage import UnifiedWriter, UnifiedReader


class TestMf4Writer:
    """测试 MF4 文件写入功能"""
    
    def test_create_basic_mf4(self, temp_dir):
        """
        测试创建基本的 MF4 文件
        
        验证：
        - 文件能成功创建
        - 文件大小大于 0
        - asammdf 可以读取
        """
        file_path = os.path.join(temp_dir, "test_basic.mf4")
        
        with Mf4Writer.create(file_path) as writer:
            # 设置文件头信息
            writer.set_header(
                author="Test Author",
                organization="Test Organization",
                project="Test Project",
                comment="Basic test file"
            )
            
            # 创建模拟数据
            timestamps = np.linspace(0, 10, 1000)  # 10秒，1000个采样点
            engine_speed = 3000 + 500 * np.sin(2 * np.pi * timestamps / 5)  # 正弦波动
            
            # 添加信号
            writer.add_signal(
                name="Engine_Speed",
                timestamps=timestamps,
                values=engine_speed,
                unit="rpm",
                comment="Engine rotational speed"
            )
        
        # 验证文件已创建
        assert os.path.exists(file_path)
        assert os.path.getsize(file_path) > 0
        
        # 使用 asammdf 验证文件
        from asammdf import MDF
        mdf = MDF(file_path)
        assert 'Engine_Speed' in mdf.channels_db
        mdf.close()
    
    def test_create_with_multiple_signals(self, temp_dir):
        """
        测试创建包含多个信号的 MF4 文件
        
        验证：
        - 多个信号能正确写入
        - 信号共享时间轴
        """
        file_path = os.path.join(temp_dir, "test_multi.mf4")
        
        with Mf4Writer.create(file_path, version="4.10") as writer:
            writer.set_header(
                author="Multi-Signal Test",
                project="Signal Test"
            )
            
            # 创建时间轴
            timestamps = np.linspace(0, 100, 10000)  # 100秒
            
            # 创建多个信号
            signals = {
                "Engine_Speed": np.random.uniform(1000, 6000, 10000),
                "Vehicle_Speed": np.random.uniform(0, 180, 10000),
                "Throttle_Position": np.random.uniform(0, 100, 10000),
                "Coolant_Temp": np.random.uniform(60, 105, 10000),
                "Oil_Pressure": np.random.uniform(1, 5, 10000),
            }
            
            units = {
                "Engine_Speed": "rpm",
                "Vehicle_Speed": "km/h",
                "Throttle_Position": "%",
                "Coolant_Temp": "°C",
                "Oil_Pressure": "bar",
            }
            
            writer.add_signals(timestamps, signals, units=units)
        
        # 验证
        assert os.path.exists(file_path)
        
        from asammdf import MDF
        mdf = MDF(file_path)
        for signal_name in signals.keys():
            assert signal_name in mdf.channels_db
        mdf.close()
    
    def test_create_with_compression(self, temp_dir):
        """
        测试创建压缩的 MF4 文件
        
        验证：
        - 压缩选项能正确应用
        """
        file_path = os.path.join(temp_dir, "test_compressed.mf4")
        
        with Mf4Writer.create(file_path, compression=True) as writer:
            writer.set_header(author="Compression Test")
            
            timestamps = np.linspace(0, 10, 5000)
            values = np.random.randn(5000)
            
            writer.add_signal("Random_Data", timestamps, values, unit="V")
        
        assert os.path.exists(file_path)
    
    def test_create_large_file(self, temp_dir):
        """
        测试创建大型 MF4 文件（性能测试）
        
        验证：
        - 能处理大量数据
        """
        file_path = os.path.join(temp_dir, "test_large.mf4")
        
        # 创建大量数据
        sample_count = 100000
        
        with Mf4Writer.create(file_path) as writer:
            writer.set_header(author="Large File Test")
            
            timestamps = np.linspace(0, 1000, sample_count)
            
            # 多通道大数据
            for i in range(10):
                values = np.random.randn(sample_count)
                writer.add_signal(f"Signal_{i}", timestamps, values, unit="V")
        
        assert os.path.exists(file_path)
        
        # 验证文件大小
        file_size = os.path.getsize(file_path)
        assert file_size > 1024 * 1024  # 应该大于 1MB


class TestMf4Reader:
    """测试 MF4 文件读取功能"""
    
    @pytest.fixture
    def sample_file(self, temp_dir):
        """创建示例文件用于测试"""
        file_path = os.path.join(temp_dir, "sample.mf4")
        
        with Mf4Writer.create(file_path) as writer:
            writer.set_header(
                author="Sample Author",
                organization="Sample Org",
                project="Sample Project"
            )
            
            timestamps = np.linspace(0, 10, 100)
            
            writer.add_signal(
                "Engine_Speed",
                timestamps,
                np.linspace(1000, 6000, 100),
                unit="rpm"
            )
            
            writer.add_signal(
                "Vehicle_Speed",
                timestamps,
                np.linspace(0, 120, 100),
                unit="km/h"
            )
        
        return file_path
    
    def test_read_header(self, sample_file):
        """
        测试读取文件头信息
        
        验证：
        - 文件头信息正确读取
        """
        with Mf4Reader.open(sample_file) as reader:
            header = reader.header
            
            assert header is not None
            # 注意：asammdf 可能不支持所有头字段
    
    def test_get_channels(self, sample_file):
        """
        测试获取通道列表
        
        验证：
        - 能获取所有通道
        - 通道信息正确
        """
        with Mf4Reader.open(sample_file) as reader:
            channels = reader.get_channels()
            
            # 至少应该有写入的通道
            channel_names = [ch.name for ch in channels]
            
            # 可能包含时间通道，所以检查我们写入的通道是否存在
            assert len(channels) >= 2
    
    def test_read_channel_data(self, sample_file):
        """
        测试读取通道数据
        
        验证：
        - 能读取完整信号数据
        - 数据正确
        """
        with Mf4Reader.open(sample_file) as reader:
            signal = reader.read_channel("Engine_Speed")
            
            assert signal is not None
            assert len(signal) == 100
            assert signal.unit == "rpm"
            
            # 验证数据范围
            stats = signal.get_statistics()
            assert stats['min'] >= 1000
            assert stats['max'] <= 6000
    
    def test_read_multiple_channels(self, sample_file):
        """
        测试批量读取通道数据
        
        验证：
        - 能批量读取多个通道
        """
        with Mf4Reader.open(sample_file) as reader:
            signals = reader.read_channels(["Engine_Speed", "Vehicle_Speed"])
            
            assert "Engine_Speed" in signals
            assert "Vehicle_Speed" in signals
            assert len(signals["Engine_Speed"]) == 100
            assert len(signals["Vehicle_Speed"]) == 100
    
    def test_read_channel_not_found(self, sample_file):
        """
        测试读取不存在的通道
        
        验证：
        - 正确抛出异常
        """
        with Mf4Reader.open(sample_file) as reader:
            with pytest.raises(Mf4ChannelNotFoundError):
                reader.read_channel("Non_Existent_Channel")
    
    def test_read_time_range(self, sample_file):
        """
        测试按时间范围读取
        
        验证：
        - 时间范围过滤正确
        """
        with Mf4Reader.open(sample_file) as reader:
            # 只读取 2-5 秒的数据
            signal = reader.read_channel(
                "Engine_Speed",
                start_time=2.0,
                end_time=5.0
            )
            
            # 验证时间范围
            assert signal.timestamps[0] >= 2.0
            assert signal.timestamps[-1] <= 5.0
    
    def test_filter_channels(self, sample_file):
        """
        测试通道过滤
        
        验证：
        - 名称模式过滤正确
        """
        with Mf4Reader.open(sample_file) as reader:
            # 按名称模式过滤
            channels = reader.filter_channels(name_pattern="Engine_*")
            
            assert len(channels) >= 1
            for ch in channels:
                assert "Engine" in ch.name
    
    def test_to_dataframe(self, sample_file):
        """
        测试导出为 DataFrame
        
        验证：
        - DataFrame 结构正确
        """
        try:
            import pandas as pd
        except ImportError:
            pytest.skip("pandas not installed")
        
        with Mf4Reader.open(sample_file) as reader:
            df = reader.to_dataframe(["Engine_Speed", "Vehicle_Speed"])
            
            assert isinstance(df, pd.DataFrame)
            assert len(df) == 100
            assert "Engine_Speed" in df.columns


class TestMf4Converter:
    """测试格式转换功能"""
    
    @pytest.fixture
    def sample_file(self, temp_dir):
        file_path = os.path.join(temp_dir, "convert_sample.mf4")
        
        with Mf4Writer.create(file_path) as writer:
            writer.set_header(author="Converter Test")
            
            timestamps = np.linspace(0, 10, 50)
            writer.add_signal("Speed", timestamps, np.random.uniform(0, 100, 50), unit="km/h")
            writer.add_signal("Acceleration", timestamps, np.random.uniform(0, 10, 50), unit="m/s2")
        
        return file_path
    
    def test_to_csv(self, sample_file, temp_dir):
        """测试转换为 CSV"""
        output_path = os.path.join(temp_dir, "output.csv")
        
        converter = Mf4Converter(sample_file)
        converter.to_csv(output_path)
        
        assert os.path.exists(output_path)
        
        # 验证 CSV 内容
        with open(output_path, 'r') as f:
            content = f.read()
            assert 'Speed' in content or 'Acceleration' in content
        
        converter.close()
    
    def test_to_json(self, sample_file, temp_dir):
        """测试转换为 JSON"""
        try:
            import pandas
        except ImportError:
            pytest.skip("pandas not installed")
        
        output_path = os.path.join(temp_dir, "output.json")
        
        converter = Mf4Converter(sample_file)
        converter.to_json(output_path)
        
        assert os.path.exists(output_path)
        converter.close()


class TestMf4StreamingReader:
    """测试流式读取功能"""
    
    @pytest.fixture
    def large_file(self, temp_dir):
        """创建较大的测试文件"""
        file_path = os.path.join(temp_dir, "large.mf4")
        
        with Mf4Writer.create(file_path) as writer:
            writer.set_header(author="Large File")
            
            # 创建较多数据
            timestamps = np.linspace(0, 100, 10000)
            writer.add_signal("Signal_1", timestamps, np.random.randn(10000), unit="V")
            writer.add_signal("Signal_2", timestamps, np.random.randn(10000), unit="A")
            writer.add_signal("Signal_3", timestamps, np.random.randn(10000), unit="W")
        
        return file_path
    
    def test_read_batches(self, large_file):
        """
        测试批量读取
        
        验证：
        - 能按批次读取数据
        - 批次大小正确
        """
        with Mf4StreamingReader.open(large_file, buffer_size=1000) as reader:
            batch_count = 0
            total_samples = 0
            
            for batch in reader.read_batches(batch_size=2000):
                batch_count += 1
                total_samples += len(list(batch.values())[0])
            
            # 应该有多个批次
            assert batch_count >= 5
    
    def test_iter_signals(self, large_file):
        """
        测试迭代读取信号
        
        验证：
        - 能逐个读取信号
        """
        with Mf4StreamingReader.open(large_file) as reader:
            signal_count = 0
            
            for signal in reader.iter_signals():
                signal_count += 1
                assert signal is not None
                assert len(signal) > 0
            
            assert signal_count >= 3


class TestConfiguration:
    """测试配置功能"""
    
    def test_default_config(self):
        """测试默认配置"""
        config = Mf4Config.default()
        
        assert config.buffer_size == 10000
        assert config.cache_enabled is True
        assert config.validate_on_write is True
    
    def test_high_performance_config(self):
        """测试高性能配置"""
        config = Mf4Config.high_performance()
        
        assert config.buffer_size == 50000
        assert config.cache_size_mb == 500
    
    def test_low_memory_config(self):
        """测试低内存配置"""
        config = Mf4Config.low_memory()
        
        assert config.buffer_size == 1000
        assert config.cache_size_mb == 20
    
    def test_custom_config(self):
        """测试自定义配置"""
        config = Mf4Config(
            buffer_size=25000,
            cache_size_mb=150,
            validate_on_write=False
        )
        
        assert config.buffer_size == 25000
        assert config.cache_size_mb == 150
        assert config.validate_on_write is False
    
    def test_storage_mode_single_default(self):
        """测试默认 storage_mode 为 single"""
        config = Mf4Config()
        assert config.storage_mode == "single"
    
    def test_storage_mode_sharded(self):
        """测试 sharded 模式"""
        config = Mf4Config(storage_mode="sharded")
        assert config.storage_mode == "sharded"
    
    def test_storage_mode_invalid(self):
        """测试无效 storage_mode"""
        with pytest.raises(ValueError):
            Mf4Config(storage_mode="invalid")
    
    def test_storage_mode_in_merge(self):
        """测试 storage_mode 在 merge 中保留"""
        config = Mf4Config(storage_mode="sharded")
        merged = config.merge(buffer_size=20000)
        assert merged.storage_mode == "sharded"
        assert merged.buffer_size == 20000
    
    def test_storage_mode_in_to_dict(self):
        """测试 storage_mode 在 to_dict 中包含"""
        config = Mf4Config(storage_mode="sharded")
        d = config.to_dict()
        assert d["storage_mode"] == "sharded"


class TestEndToEnd:
    """端到端集成测试"""
    
    def test_write_read_cycle(self, temp_dir):
        """
        测试完整的写入-读取周期
        
        流程：
        1. 创建 MF4 文件
        2. 写入数据
        3. 读取验证
        """
        file_path = os.path.join(temp_dir, "cycle.mf4")
        
        # 原始数据
        original_timestamps = np.linspace(0, 10, 500)
        original_speed = 1000 + 500 * np.sin(original_timestamps)
        original_temp = 80 + 20 * np.cos(original_timestamps / 2)
        
        # 写入
        with Mf4Writer.create(file_path) as writer:
            writer.set_header(
                author="Cycle Test",
                project="End-to-End Test"
            )
            
            writer.add_signal("Speed", original_timestamps, original_speed, unit="rpm")
            writer.add_signal("Temperature", original_timestamps, original_temp, unit="°C")
        
        # 读取验证
        with Mf4Reader.open(file_path) as reader:
            speed_signal = reader.read_channel("Speed")
            temp_signal = reader.read_channel("Temperature")
            
            # 验证数据
            np.testing.assert_array_almost_equal(
                speed_signal.values, original_speed, decimal=5
            )
            np.testing.assert_array_almost_equal(
                temp_signal.values, original_temp, decimal=5
            )
    
    def test_write_convert_read_csv(self, temp_dir):
        """
        测试写入-转换-CSV读取流程
        """
        file_path = os.path.join(temp_dir, "workflow.mf4")
        csv_path = os.path.join(temp_dir, "workflow.csv")
        
        # 写入 MF4
        with Mf4Writer.create(file_path) as writer:
            writer.set_header(author="Workflow Test")
            
            timestamps = np.linspace(0, 5, 50)
            values = np.arange(50) * 2
            
            writer.add_signal("Counter", timestamps, values, unit="counts")
        
        # 转换为 CSV
        converter = Mf4Converter(file_path)
        converter.to_csv(csv_path)
        converter.close()
        
        # 验证 CSV
        assert os.path.exists(csv_path)
        
        # 读取 CSV 并验证
        import csv
        with open(csv_path, 'r') as f:
            reader = csv.DictReader(f)
            rows = list(reader)
            
            assert len(rows) == 50


if __name__ == "__main__":
    pytest.main([__file__, "-v"])