"""
测试数据模型
"""

import pytest
import numpy as np
from datetime import datetime, timezone

from mf4.model import (
    FileHeader, Channel, ChannelGroup, DataGroup,
    ChannelConversion, Signal, Attachment, Metadata
)
from mf4.enums import DataType, ChannelType, ConversionType


class TestFileHeader:
    """测试 FileHeader 模型"""
    
    def test_default_header(self):
        """测试默认文件头"""
        header = FileHeader()
        assert header.version == "4.10"
        assert header.author == ""
        assert header.start_time is not None
    
    def test_custom_header(self):
        """测试自定义文件头"""
        header = FileHeader(
            version="4.11",
            author="Test Author",
            organization="Test Org",
            project="Test Project"
        )
        assert header.version == "4.11"
        assert header.author == "Test Author"
    
    def test_validation_valid(self):
        """测试有效验证"""
        header = FileHeader()
        errors = header.validate()
        assert len(errors) == 0
    
    def test_validation_invalid_version(self):
        """测试无效版本验证"""
        header = FileHeader(version="3.0")
        errors = header.validate()
        assert len(errors) > 0
    
    def test_validation_invalid_time(self):
        """测试无效时间验证"""
        header = FileHeader(
            start_time=datetime(2022, 1, 2, tzinfo=timezone.utc),
            end_time=datetime(2022, 1, 1, tzinfo=timezone.utc)
        )
        errors = header.validate()
        assert any("end_time" in e for e in errors)
    
    def test_to_dict(self):
        """测试转换为字典"""
        header = FileHeader(author="Test")
        data = header.to_dict()
        assert data["author"] == "Test"
        assert "version" in data
    
    def test_from_dict(self):
        """测试从字典创建"""
        data = {
            "version": "4.11",
            "author": "Test Author",
            "organization": "Test Org"
        }
        header = FileHeader.from_dict(data)
        assert header.version == "4.11"
        assert header.author == "Test Author"


class TestChannel:
    """测试 Channel 模型"""
    
    def test_default_channel(self):
        """测试默认通道"""
        channel = Channel()
        assert channel.name == ""
        assert channel.data_type == DataType.FLOAT64
    
    def test_custom_channel(self):
        """测试自定义通道"""
        channel = Channel(
            name="Engine_Speed",
            unit="rpm",
            data_type=DataType.FLOAT64,
            byte_offset=0,
            bit_count=64
        )
        assert channel.name == "Engine_Speed"
        assert channel.unit == "rpm"
    
    def test_validation_valid(self):
        """测试有效验证"""
        channel = Channel(name="Test")
        errors = channel.validate()
        assert len(errors) == 0
    
    def test_validation_invalid_name(self):
        """测试无效名称"""
        channel = Channel()
        errors = channel.validate()
        assert any("name" in e.lower() for e in errors)
    
    def test_get_byte_size(self):
        """测试获取字节大小"""
        channel = Channel(bit_count=64)
        assert channel.get_byte_size() == 8
        
        channel = Channel(bit_count=32)
        assert channel.get_byte_size() == 4
    
    def test_get_numpy_dtype(self):
        """测试获取 NumPy 数据类型"""
        channel = Channel(data_type=DataType.FLOAT64)
        assert channel.get_numpy_dtype() == "float64"
        
        channel = Channel(data_type=DataType.INT32)
        assert channel.get_numpy_dtype() == "int32"


class TestChannelConversion:
    """测试 ChannelConversion 模型"""
    
    def test_no_conversion(self):
        """测试无转换"""
        conversion = ChannelConversion()
        assert conversion.apply(100.0) == 100.0
    
    def test_linear_conversion(self):
        """测试线性转换"""
        conversion = ChannelConversion(
            type=ConversionType.LINEAR,
            a=2.0,
            b=10.0
        )
        assert conversion.apply(5.0) == 20.0  # 2*5 + 10
    
    def test_linear_inverse(self):
        """测试线性逆转换"""
        conversion = ChannelConversion(
            type=ConversionType.LINEAR,
            a=2.0,
            b=10.0
        )
        assert conversion.inverse(20.0) == 5.0  # (20-10)/2
    
    def test_rational_conversion(self):
        """测试有理转换"""
        conversion = ChannelConversion(
            type=ConversionType.RATIONAL,
            a=1.0,
            b=0.0,
            c=0.0,
            d=1.0
        )
        assert conversion.apply(5.0) == 5.0


class TestChannelGroup:
    """测试 ChannelGroup 模型"""
    
    def test_default_channel_group(self):
        """测试默认通道组"""
        cg = ChannelGroup()
        assert cg.name == ""
        assert len(cg.channels) == 0
    
    def test_add_channel(self):
        """测试添加通道"""
        cg = ChannelGroup(name="Test_Group")
        channel = Channel(name="Test_Channel")
        cg.add_channel(channel)
        assert len(cg.channels) == 1
        assert cg.channels[0].name == "Test_Channel"


class TestSignal:
    """测试 Signal 模型"""
    
    def test_signal_creation(self):
        """测试信号创建"""
        timestamps = np.linspace(0, 10, 100)
        values = np.random.uniform(0, 100, 100)
        
        signal = Signal(
            name="Test_Signal",
            timestamps=timestamps,
            values=values,
            unit="V"
        )
        
        assert signal.name == "Test_Signal"
        assert len(signal) == 100
    
    def test_get_statistics(self):
        """测试获取统计信息"""
        timestamps = np.linspace(0, 10, 100)
        values = np.array([1.0] * 100)
        
        signal = Signal(
            name="Test",
            timestamps=timestamps,
            values=values,
            unit="V"
        )
        
        stats = signal.get_statistics()
        assert stats["min"] == 1.0
        assert stats["max"] == 1.0
        assert stats["mean"] == 1.0
    
    def test_get_value_at_time(self):
        """测试获取指定时间的值"""
        timestamps = np.array([0.0, 5.0, 10.0])
        values = np.array([1.0, 5.0, 10.0])
        
        signal = Signal(
            name="Test",
            timestamps=timestamps,
            values=values
        )
        
        assert signal.get_value_at_time(2.5) == 3.0  # 线性插值


class TestMetadata:
    """测试 Metadata 模型"""
    
    def test_metadata_operations(self):
        """测试元数据操作"""
        metadata = Metadata()
        metadata.add("key1", "value1")
        metadata.add("key2", 123)
        
        assert metadata.get("key1") == "value1"
        assert metadata.get("key2") == 123
        assert metadata.get("key3") is None
        assert metadata.get("key3", "default") == "default"
        
        assert metadata.remove("key1") is True
        assert metadata.get("key1") is None