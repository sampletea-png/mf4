"""
测试枚举类型
"""

import pytest
from mf4.enums import DataType, ChannelType, ConversionType, CompressionType


class TestDataType:
    """测试 DataType 枚举"""
    
    def test_from_mdf_code_valid(self):
        """测试有效的 MDF 代码转换"""
        assert DataType.from_mdf_code(0) == DataType.UINT8
        assert DataType.from_mdf_code(9) == DataType.FLOAT64
        assert DataType.from_mdf_code(6) == DataType.INT32
    
    def test_from_mdf_code_invalid(self):
        """测试无效的 MDF 代码"""
        with pytest.raises(ValueError):
            DataType.from_mdf_code(999)
    
    def test_to_numpy_dtype(self):
        """测试转换为 NumPy 数据类型"""
        assert DataType.FLOAT64.to_numpy_dtype() == 'float64'
        assert DataType.INT32.to_numpy_dtype() == 'int32'
        assert DataType.UINT16.to_numpy_dtype() == 'uint16'
    
    def test_get_byte_size(self):
        """测试获取字节大小"""
        assert DataType.FLOAT64.get_byte_size() == 8
        assert DataType.FLOAT32.get_byte_size() == 4
        assert DataType.INT32.get_byte_size() == 4
        assert DataType.INT16.get_byte_size() == 2
        assert DataType.UINT8.get_byte_size() == 1
    
    def test_string_types_have_zero_size(self):
        """测试字符串类型的大小为 0（可变长度）"""
        assert DataType.STRING_UTF8.get_byte_size() == 0
        assert DataType.STRING_UTF16.get_byte_size() == 0


class TestChannelType:
    """测试 ChannelType 枚举"""
    
    def test_channel_types(self):
        """测试通道类型值"""
        assert ChannelType.VALUE.value == 0
        assert ChannelType.MASTER.value == 1
        assert ChannelType.VIRTUAL_MASTER.value == 2
        assert ChannelType.SYNC.value == 3


class TestConversionType:
    """测试 ConversionType 枚举"""
    
    def test_conversion_types(self):
        """测试转换类型值"""
        assert ConversionType.NONE.value == 0
        assert ConversionType.LINEAR.value == 1
        assert ConversionType.RATIONAL.value == 2
        assert ConversionType.TABULAR.value == 4


class TestCompressionType:
    """测试 CompressionType 枚举"""
    
    def test_compression_types(self):
        """测试压缩类型值"""
        assert CompressionType.NONE.value == "none"
        assert CompressionType.DEFLATE.value == "deflate"
        assert CompressionType.LZ4.value == "lz4"
