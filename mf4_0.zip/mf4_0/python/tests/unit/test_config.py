"""
测试配置模块
"""

import pytest
import os
from mf4.config import Mf4Config


class TestMf4Config:
    """测试 Mf4Config 配置类"""
    
    def test_default_config(self):
        """测试默认配置"""
        config = Mf4Config.default()
        assert config.buffer_size == 10000
        assert config.cache_enabled is True
        assert config.validate_on_write is True
    
    def test_custom_config(self):
        """测试自定义配置"""
        config = Mf4Config(
            buffer_size=20000,
            cache_size_mb=200,
            validate_on_write=False
        )
        assert config.buffer_size == 20000
        assert config.cache_size_mb == 200
        assert config.validate_on_write is False
    
    def test_invalid_buffer_size(self):
        """测试无效的缓冲区大小"""
        with pytest.raises(ValueError):
            Mf4Config(buffer_size=10)
        
        with pytest.raises(ValueError):
            Mf4Config(buffer_size=2000000)
    
    def test_invalid_cache_size(self):
        """测试无效的缓存大小"""
        with pytest.raises(ValueError):
            Mf4Config(cache_size_mb=5)
        
        with pytest.raises(ValueError):
            Mf4Config(cache_size_mb=2000)
    
    def test_invalid_log_level(self):
        """测试无效的日志级别"""
        with pytest.raises(ValueError):
            Mf4Config(log_level="INVALID")
    
    def test_invalid_cache_strategy(self):
        """测试无效的缓存策略"""
        with pytest.raises(ValueError):
            Mf4Config(cache_strategy="invalid")
    
    def test_from_env(self, monkeypatch):
        """测试从环境变量读取配置"""
        monkeypatch.setenv("MF4_BUFFER_SIZE", "30000")
        monkeypatch.setenv("MF4_CACHE_SIZE_MB", "150")
        
        config = Mf4Config.from_env()
        assert config.buffer_size == 30000
        assert config.cache_size_mb == 150
    
    def test_high_performance_config(self):
        """测试高性能配置"""
        config = Mf4Config.high_performance()
        assert config.buffer_size == 50000
        assert config.cache_size_mb == 500
        assert config.max_workers == 8
    
    def test_low_memory_config(self):
        """测试低内存配置"""
        config = Mf4Config.low_memory()
        assert config.buffer_size == 1000
        assert config.cache_size_mb == 20
        assert config.max_workers == 1
    
    def test_merge_config(self):
        """测试配置合并"""
        base_config = Mf4Config.default()
        merged = base_config.merge(buffer_size=25000)
        assert merged.buffer_size == 25000
        assert base_config.buffer_size == 10000  # 原配置不变
    
    def test_to_dict(self):
        """测试转换为字典"""
        config = Mf4Config.default()
        config_dict = config.to_dict()
        assert isinstance(config_dict, dict)
        assert "buffer_size" in config_dict
        assert "cache_size_mb" in config_dict