"""
测试异常类
"""

import pytest
from mf4.exceptions import (
    Mf4Error,
    Mf4FileNotFoundError,
    Mf4CorruptedFileError,
    Mf4UnsupportedVersionError,
    Mf4ChannelNotFoundError,
    Mf4ValidationError,
    Mf4ParseError,
)


class TestMf4Error:
    """测试基础异常类"""
    
    def test_basic_error(self):
        """测试基本错误"""
        error = Mf4Error("Test error")
        assert str(error) == "Test error"
        assert error.message == "Test error"
        assert error.file_path is None
    
    def test_error_with_file_path(self):
        """测试带文件路径的错误"""
        error = Mf4Error("Test error", file_path="test.mf4")
        assert error.file_path == "test.mf4"
        assert "test.mf4" in repr(error)
    
    def test_error_with_details(self):
        """测试带详细信息的错误"""
        error = Mf4Error("Test error", details=["detail1", "detail2"])
        assert len(error.details) == 2
        assert "detail1" in str(error)


class TestMf4FileNotFoundError:
    """测试文件未找到异常"""
    
    def test_file_not_found(self):
        """测试文件未找到"""
        error = Mf4FileNotFoundError("missing.mf4")
        assert error.file_path == "missing.mf4"
        assert "not found" in error.message


class TestMf4CorruptedFileError:
    """测试文件损坏异常"""
    
    def test_corrupted_file(self):
        """测试文件损坏"""
        error = Mf4CorruptedFileError(
            "Invalid block",
            file_path="corrupted.mf4",
            block_type="HD",
            offset=100
        )
        assert error.block_type == "HD"
        assert error.offset == 100
        assert error.file_path == "corrupted.mf4"


class TestMf4UnsupportedVersionError:
    """测试版本不支持异常"""
    
    def test_unsupported_version(self):
        """测试版本不支持"""
        error = Mf4UnsupportedVersionError("3.0")
        assert error.version == "3.0"
        assert len(error.supported_versions) > 0


class TestMf4ChannelNotFoundError:
    """测试通道未找到异常"""
    
    def test_channel_not_found(self):
        """测试通道未找到"""
        error = Mf4ChannelNotFoundError(
            "Missing_Channel",
            available_channels=["Channel1", "Channel2"]
        )
        assert error.channel_name == "Missing_Channel"
        assert len(error.available_channels) == 2


class TestMf4ValidationError:
    """测试验证异常"""
    
    def test_validation_error(self):
        """测试验证失败"""
        error = Mf4ValidationError(
            "Data validation failed",
            validation_errors=["Error 1", "Error 2"]
        )
        assert len(error.validation_errors) == 2
        assert "Error 1" in str(error)


class TestMf4ParseError:
    """测试解析异常"""
    
    def test_parse_error(self):
        """测试解析失败"""
        error = Mf4ParseError(
            "Parse failed",
            block_type="CN",
            offset=0x1000
        )
        assert error.block_type == "CN"
        assert error.offset == 0x1000