"""
流式写入器

用于流式写入数据到 MF4 文件。
"""

from typing import Optional, Dict, Any
from mf4.config import Mf4Config
from mf4.enums import CompressionType


class Mf4StreamingWriter:
    """
    流式 MF4 文件写入器
    
    Example:
        >>> with Mf4StreamingWriter.create("output.mf4") as writer:
        ...     for data in data_source:
        ...         writer.write(data)
        ...     writer.flush()
    """
    
    def __init__(
        self,
        file_path: str,
        buffer_size: int = 10000,
        compression: CompressionType = CompressionType.NONE,
        config: Optional[Mf4Config] = None
    ):
        self._file_path = file_path
        self._buffer_size = buffer_size
        self._compression = compression
        self._config = config or Mf4Config.default()
        self._buffer = []
    
    @classmethod
    def create(cls, file_path: str, buffer_size: int = 10000):
        """创建写入器"""
        return cls(file_path, buffer_size)
    
    def write(self, record: Dict[str, Any]) -> None:
        """写入记录"""
        self._buffer.append(record)
        if len(self._buffer) >= self._buffer_size:
            self.flush()
    
    def flush(self) -> None:
        """刷新缓冲区"""
        self._buffer.clear()
    
    def close(self) -> None:
        """关闭"""
        self.flush()
    
    def __enter__(self) -> 'Mf4StreamingWriter':
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()
