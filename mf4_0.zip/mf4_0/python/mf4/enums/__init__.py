"""
枚举类型定义模块

定义 MF4 文件格式中使用的各种枚举类型，包括：
- 数据类型（整数、浮点、字符串等）
- 通道类型（数据通道、时间轴等）
- 转换类型（线性、有理、表格等）
- 压缩类型（无压缩、Deflate、LZ4等）

这些枚举类型用于确保数据类型的一致性和可读性。
"""

from enum import Enum, IntEnum
from typing import Dict, Any


class DataType(IntEnum):
    """
    数据类型枚举
    
    定义 MF4 文件中支持的各种数据类型，包括整数、浮点数、字符串和布尔值等。
    每种数据类型对应一个特定的数值编码，符合 ASAM MDF 规范。
    
    Attributes:
        UINT8: 无符号8位整数 (0-255)
        UINT16: 无符号16位整数 (0-65535)
        UINT32: 无符号32位整数 (0-4294967295)
        UINT64: 无符号64位整数
        INT8: 有符号8位整数 (-128 to 127)
        INT16: 有符号16位整数 (-32768 to 32767)
        INT32: 有符号32位整数
        INT64: 有符号64位整数
        FLOAT32: 32位单精度浮点数
        FLOAT64: 64位双精度浮点数
        STRING_UTF8: UTF-8编码字符串
        STRING_UTF16: UTF-16编码字符串
        STRING_LATIN1: Latin-1编码字符串
        BYTE_ARRAY: 字节数组
        BOOL: 布尔类型
    
    Example:
        >>> DataType.FLOAT64
        DataType.FLOAT64
        >>> DataType.FLOAT64.value
        9
        >>> DataType.from_mdf_code(1)
        DataType.UINT16
    """
    
    UINT8 = 0       # 无符号8位整数
    UINT16 = 1      # 无符号16位整数
    UINT32 = 2      # 无符号32位整数
    UINT64 = 3      # 无符号64位整数
    INT8 = 4        # 有符号8位整数
    INT16 = 5       # 有符号16位整数
    INT32 = 6       # 有符号32位整数
    INT64 = 7       # 有符号64位整数
    FLOAT32 = 8     # 32位单精度浮点数
    FLOAT64 = 9     # 64位双精度浮点数
    STRING_UTF8 = 10    # UTF-8编码字符串
    STRING_UTF16 = 11   # UTF-16编码字符串
    STRING_LATIN1 = 12  # Latin-1编码字符串
    BYTE_ARRAY = 13     # 字节数组
    BOOL = 14           # 布尔类型
    
    @classmethod
    def from_mdf_code(cls, code: int) -> 'DataType':
        """
        从 MDF 规范的数值编码创建 DataType
        
        Args:
            code: MDF 规范中定义的数据类型编码
            
        Returns:
            对应的 DataType 枚举值
            
        Raises:
            ValueError: 如果编码不存在对应的数据类型
            
        Example:
            >>> DataType.from_mdf_code(9)
            DataType.FLOAT64
        """
        try:
            return cls(code)
        except ValueError:
            raise ValueError(f"Unknown MDF data type code: {code}")
    
    def to_numpy_dtype(self) -> str:
        """
        将 DataType 转换为 NumPy 数据类型字符串
        
        用于在使用 NumPy 处理数据时确定正确的数据类型。
        
        Returns:
            NumPy 数据类型字符串
            
        Example:
            >>> DataType.FLOAT64.to_numpy_dtype()
            'float64'
            >>> DataType.INT32.to_numpy_dtype()
            'int32'
        """
        mapping: Dict[DataType, str] = {
            DataType.UINT8: 'uint8',
            DataType.UINT16: 'uint16',
            DataType.UINT32: 'uint32',
            DataType.UINT64: 'uint64',
            DataType.INT8: 'int8',
            DataType.INT16: 'int16',
            DataType.INT32: 'int32',
            DataType.INT64: 'int64',
            DataType.FLOAT32: 'float32',
            DataType.FLOAT64: 'float64',
            DataType.STRING_UTF8: 'object',
            DataType.STRING_UTF16: 'object',
            DataType.STRING_LATIN1: 'object',
            DataType.BYTE_ARRAY: 'object',
            DataType.BOOL: 'bool',
        }
        return mapping[self]
    
    def get_byte_size(self) -> int:
        """
        获取该数据类型的字节大小
        
        Returns:
            数据类型的字节大小
            
        Example:
            >>> DataType.FLOAT64.get_byte_size()
            8
            >>> DataType.INT32.get_byte_size()
            4
        """
        mapping: Dict[DataType, int] = {
            DataType.UINT8: 1,
            DataType.UINT16: 2,
            DataType.UINT32: 4,
            DataType.UINT64: 8,
            DataType.INT8: 1,
            DataType.INT16: 2,
            DataType.INT32: 4,
            DataType.INT64: 8,
            DataType.FLOAT32: 4,
            DataType.FLOAT64: 8,
            DataType.STRING_UTF8: 0,  # 字符串大小可变
            DataType.STRING_UTF16: 0,
            DataType.STRING_LATIN1: 0,
            DataType.BYTE_ARRAY: 0,   # 字节数组大小可变
            DataType.BOOL: 1,
        }
        return mapping[self]


class ChannelType(IntEnum):
    """
    通道类型枚举
    
    定义 MF4 文件中通道的功能类型，用于区分数据通道和时间轴通道。
    
    Attributes:
        VALUE: 数据通道，存储实际测量数据
        MASTER: 主通道，通常是时间轴通道
        VIRTUAL_MASTER: 虚拟主通道，通过计算生成时间轴
        SYNC: 同步通道，用于同步多个数据源
    
    Example:
        >>> channel.type = ChannelType.MASTER  # 设置为时间轴通道
    """
    
    VALUE = 0           # 数据通道
    MASTER = 1          # 主通道（时间轴）
    VIRTUAL_MASTER = 2  # 虚拟主通道
    SYNC = 3            # 同步通道


class ConversionType(IntEnum):
    """
    转换类型枚举
    
    定义数据值转换的各种方式，用于将原始数据转换为物理值。
    
    Attributes:
        NONE: 无转换，直接使用原始值
        LINEAR: 线性转换，公式: y = a * x + b
        RATIONAL: 有理转换，公式: y = (a*x + b) / (c*x + d)
        ALGEBRAIC: 代数转换，使用公式字符串
        TABULAR: 表格转换，使用查找表
        TEXT: 文本转换，将数值映射为文本
        DATE: 日期转换，将数值转换为日期时间
    
    Example:
        >>> # 线性转换示例
        >>> conversion.type = ConversionType.LINEAR
        >>> conversion.a = 0.5
        >>> conversion.b = 10.0
        >>> # 转换公式: y = 0.5 * x + 10.0
    """
    
    NONE = 0        # 无转换
    LINEAR = 1      # 线性转换: y = a*x + b
    RATIONAL = 2    # 有理转换: y = (a*x + b) / (c*x + d)
    ALGEBRAIC = 3   # 代数转换（公式字符串）
    TABULAR = 4     # 表格转换（查找表）
    TEXT = 5        # 文本转换
    DATE = 6        # 日期转换


class CompressionType(Enum):
    """
    压缩类型枚举
    
    定义数据记录的压缩方式，用于减小文件大小和提高存储效率。
    
    Attributes:
        NONE: 无压缩，原始数据直接存储
        DEFLATE: Deflate 压缩算法，通用压缩方式
        LZ4: LZ4 压缩算法，高速压缩方式
    
    Example:
        >>> # 创建带压缩的写入器
        >>> writer = Mf4Writer.create("output.mf4", 
        ...                            compression=CompressionType.DEFLATE)
    """
    
    NONE = "none"       # 无压缩
    DEFLATE = "deflate" # Deflate压缩
    LZ4 = "lz4"         # LZ4高速压缩


class SourceType(Enum):
    """
    数据源类型枚举
    
    定义测量数据的来源类型。
    
    Attributes:
        SENSOR: 传感器直接测量
        CALCULATED: 通过计算得到
        IMPORTED: 从外部数据源导入
        SIMULATED: 仿真数据
    """
    
    SENSOR = "sensor"       # 传感器测量
    CALCULATED = "calculated"  # 计算值
    IMPORTED = "imported"   # 导入数据
    SIMULATED = "simulated"  # 仿真数据


class BlockType(Enum):
    """
    MF4 块类型枚举
    
    定义 MF4 文件中的各种块类型标识符。
    
    Attributes:
        ID: 身份识别块
        HD: 文件头块
        DG: 数据组块
        CG: 通道组块
        CN: 通道块
        CC: 通道转换块
        TX: 文本块
        SR: 样本缩减块
        AT: 附件块
    """
    
    ID = "ID"   # 身份识别块
    HD = "HD"   # 文件头块
    DG = "DG"   # 数据组块
    CG = "CG"   # 通道组块
    CN = "CN"   # 通道块
    CC = "CC"   # 通道转换块
    TX = "TX"   # 文本块
    SR = "SR"   # 样本缩减块
    AT = "AT"   # 附件块