"""
元数据模型

Metadata 用于存储自定义的键值对元信息。
"""

from dataclasses import dataclass, field
from typing import Dict, Any


@dataclass
class Metadata:
    """
    元数据
    
    存储自定义键值对，用于扩展信息存储。
    
    Example:
        >>> metadata = Metadata()
        >>> metadata.add("Vehicle_ID", "CAR001")
        >>> metadata.add("Test_Type", "Engine")
        >>> metadata.get("Vehicle_ID")  # "CAR001"
    """
    
    fields: Dict[str, Any] = field(default_factory=dict)
    
    def add(self, key: str, value: Any) -> None:
        """添加元数据"""
        self.fields[key] = value
    
    def get(self, key: str, default: Any = None) -> Any:
        """获取元数据"""
        return self.fields.get(key, default)
    
    def remove(self, key: str) -> bool:
        """删除元数据"""
        if key in self.fields:
            del self.fields[key]
            return True
        return False
    
    def keys(self) -> list:
        """获取所有键"""
        return list(self.fields.keys())
    
    def to_dict(self) -> dict:
        """转换为字典"""
        return self.fields.copy()
    
    def __str__(self) -> str:
        return f"Metadata(fields={len(self.fields)})"
