"""
数据组模型

DataGroup 是 MF4 文件中的顶层容器，包含一个或多个通道组。
"""

from dataclasses import dataclass, field
from typing import List


@dataclass
class DataGroup:
    """
    数据组
    
    MF4 文件的顶层容器，包含一个或多个通道组及其数据。
    
    Attributes:
        id: 数据组ID
        channel_groups: 通道组列表
        record_count: 记录总数
        data_offset: 数据区偏移量
    
    Example:
        >>> dg = DataGroup(id=1)
        >>> dg.add_channel_group(ChannelGroup(name="Measurements"))
    """
    
    id: int = 0
    channel_groups: List = field(default_factory=list)
    record_count: int = 0
    data_offset: int = 0
    
    def add_channel_group(self, cg) -> None:
        """添加通道组"""
        cg.data_group_id = self.id
        self.channel_groups.append(cg)
    
    def get_all_channels(self) -> list:
        """获取所有通道"""
        channels = []
        for cg in self.channel_groups:
            channels.extend(cg.channels)
        return channels
    
    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "id": self.id,
            "channel_groups": [cg.to_dict() for cg in self.channel_groups],
            "record_count": self.record_count,
            "data_offset": self.data_offset,
        }
    
    def __str__(self) -> str:
        return f"DataGroup(id={self.id}, groups={len(self.channel_groups)})"
