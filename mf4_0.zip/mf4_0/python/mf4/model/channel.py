"""
通道数据模型

Channel 是 MF4 文件中最核心的数据结构，代表一个测量通道。
每个通道包含名称、单位、数据类型、字节偏移等信息。
"""

from dataclasses import dataclass, field
from typing import Optional, TYPE_CHECKING
from mf4.enums import DataType, ChannelType

if TYPE_CHECKING:
    from mf4.model.channel_conversion import ChannelConversion


@dataclass
class Channel:
    """
    测量通道
    
    代表 MF4 文件中的一个测量通道，存储通道的元数据和数据位置信息。
    
    Attributes:
        id: 通道唯一标识符
        name: 通道名称（通常是信号名）
        unit: 物理单位（如 rpm, km/h, V）
        comment: 通道描述/注释
        type: 通道类型（数据通道或时间轴）
        data_type: 数据类型（整数、浮点等）
        bit_offset: 位偏移量（0-7）
        byte_offset: 字节偏移量（相对于记录起始）
        bit_count: 数据位数
        channel_group_id: 所属通道组ID
        conversion: 数据转换规则（可选）
        source_name: 数据源名称（可选）
        source_path: 数据源路径（可选）
        source_comment: 数据源注释（可选）
        custom_fields: 自定义字段
    
    Example:
        >>> channel = Channel(
        ...     name="Engine_Speed",
        ...     unit="rpm",
        ...     data_type=DataType.FLOAT64,
        ...     type=ChannelType.VALUE
        ... )
        >>> channel.byte_offset = 0
        >>> channel.bit_count = 64
    """
    
    # 通道标识符（在文件范围内唯一）
    id: int = 0
    
    # 通道名称（必需）
    # 建议使用下划线分隔，如 "Engine_Speed"
    name: str = ""
    
    # 物理单位
    # 如：rpm, km/h, V, A, °C, bar
    unit: str = ""
    
    # 通道描述/注释
    comment: str = ""
    
    # 通道类型（数据通道或时间轴）
    type: ChannelType = ChannelType.VALUE
    
    # 数据类型（整数、浮点、字符串等）
    data_type: DataType = DataType.FLOAT64
    
    # 位偏移量（在字节内的偏移，0-7）
    # 用于位打包存储多个小数值
    bit_offset: int = 0
    
    # 字节偏移量（在记录中的位置）
    # 决定数据在记录中的读取位置
    byte_offset: int = 0
    
    # 数据位数
    # 例如：64位浮点数 bit_count=64
    bit_count: int = 64
    
    # 所属通道组ID
    channel_group_id: int = 0
    
    # 数据转换规则（可选）
    conversion: Optional['ChannelConversion'] = None
    
    # 数据源信息（可选）
    source_name: str = ""
    source_path: str = ""
    source_comment: str = ""
    
    # 自定义字段
    custom_fields: dict = field(default_factory=dict)
    
    def validate(self) -> list:
        """
        验证通道数据
        
        Returns:
            验证错误消息列表
        """
        errors = []
        
        # 验证名称
        if not self.name:
            errors.append("Channel name is required")
        
        # 验证位偏移
        if self.bit_offset < 0 or self.bit_offset > 7:
            errors.append(f"bit_offset must be 0-7, got {self.bit_offset}")
        
        # 验证字节数
        if self.byte_offset < 0:
            errors.append(f"byte_offset must be >= 0, got {self.byte_offset}")
        
        # 验证位数
        if self.bit_count < 1:
            errors.append(f"bit_count must be >= 1, got {self.bit_count}")
        
        return errors
    
    def get_byte_size(self) -> int:
        """
        获取通道数据的字节大小
        
        Returns:
            字节大小（向上取整）
        """
        return (self.bit_count + 7) // 8
    
    def get_numpy_dtype(self) -> str:
        """
        获取对应的 NumPy 数据类型
        
        Returns:
            NumPy 数据类型字符串
        """
        return self.data_type.to_numpy_dtype()
    
    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "id": self.id,
            "name": self.name,
            "unit": self.unit,
            "comment": self.comment,
            "type": self.type.name,
            "data_type": self.data_type.name,
            "bit_offset": self.bit_offset,
            "byte_offset": self.byte_offset,
            "bit_count": self.bit_count,
            "channel_group_id": self.channel_group_id,
            "source_name": self.source_name,
            "source_path": self.source_path,
            "source_comment": self.source_comment,
            "custom_fields": self.custom_fields.copy(),
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'Channel':
        """从字典创建 Channel"""
        return cls(
            id=data.get("id", 0),
            name=data.get("name", ""),
            unit=data.get("unit", ""),
            comment=data.get("comment", ""),
            type=ChannelType[data.get("type", "VALUE")],
            data_type=DataType[data.get("data_type", "FLOAT64")],
            bit_offset=data.get("bit_offset", 0),
            byte_offset=data.get("byte_offset", 0),
            bit_count=data.get("bit_count", 64),
            channel_group_id=data.get("channel_group_id", 0),
            source_name=data.get("source_name", ""),
            source_path=data.get("source_path", ""),
            source_comment=data.get("source_comment", ""),
            custom_fields=data.get("custom_fields", {}),
        )
    
    def __str__(self) -> str:
        return f"Channel(name='{self.name}', unit='{self.unit}')"
    
    def __repr__(self) -> str:
        return f"Channel(id={self.id}, name='{self.name}', type={self.type.name})"
