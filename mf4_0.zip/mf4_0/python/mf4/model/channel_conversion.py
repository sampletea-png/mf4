"""
通道转换规则模型

定义通道数据的转换规则，用于将原始值转换为物理值。
支持线性转换、有理转换、表格转换等多种方式。
"""

from dataclasses import dataclass, field
from typing import Optional, List, Tuple
from mf4.enums import ConversionType


@dataclass
class ChannelConversion:
    """
    通道转换规则
    
    定义如何将原始数据值转换为物理值。
    
    Attributes:
        id: 转换规则ID
        type: 转换类型（线性、有理、表格等）
        name: 转换规则名称
        comment: 转换规则描述
        a, b, c, d: 转换参数
        coeffs: 转换系数列表（用于多项式等）
        table: 转换表格（用于表格转换）
        formula: 公式字符串（用于代数转换）
    
    Example:
        >>> # 线性转换: y = 0.5 * x + 10
        >>> conversion = ChannelConversion(
        ...     type=ConversionType.LINEAR,
        ...     a=0.5,
        ...     b=10.0
        ... )
        >>> converted = conversion.apply(100)  # 60.0
    """
    
    id: int = 0
    type: ConversionType = ConversionType.NONE
    name: str = ""
    comment: str = ""
    
    # 线性转换参数: y = a*x + b
    a: float = 1.0
    b: float = 0.0
    
    # 有理转换额外参数: y = (a*x + b) / (c*x + d)
    c: float = 0.0
    d: float = 1.0
    
    # 多项式系数
    coeffs: List[float] = field(default_factory=list)
    
    # 表格转换（原始值, 物理值）
    table: List[Tuple[float, float]] = field(default_factory=list)
    
    # 代数转换公式
    formula: str = ""
    
    def apply(self, value: float) -> float:
        """
        应用转换规则
        
        Args:
            value: 原始值
            
        Returns:
            转换后的物理值
            
        Raises:
            ValueError: 如果转换失败
            
        Example:
            >>> conversion = ChannelConversion(type=ConversionType.LINEAR, a=2.0, b=10.0)
            >>> conversion.apply(5.0)  # 2.0 * 5.0 + 10.0 = 20.0
            20.0
        """
        if self.type == ConversionType.NONE:
            return value
        
        elif self.type == ConversionType.LINEAR:
            return self.a * value + self.b
        
        elif self.type == ConversionType.RATIONAL:
            denominator = self.c * value + self.d
            if denominator == 0:
                raise ValueError("Division by zero in rational conversion")
            return (self.a * value + self.b) / denominator
        
        elif self.type == ConversionType.TABULAR:
            return self._interpolate_table(value)
        
        else:
            raise ValueError(f"Unsupported conversion type: {self.type}")
    
    def inverse(self, value: float) -> float:
        """
        逆转换
        
        将物理值转换回原始值。
        
        Args:
            value: 物理值
            
        Returns:
            原始值
        """
        if self.type == ConversionType.NONE:
            return value
        
        elif self.type == ConversionType.LINEAR:
            if self.a == 0:
                raise ValueError("Cannot inverse: coefficient 'a' is zero")
            return (value - self.b) / self.a
        
        elif self.type == ConversionType.RATIONAL:
            return (self.d * value - self.b) / (self.a - self.c * value)
        
        else:
            raise ValueError(f"Inverse not supported for type: {self.type}")
    
    def _interpolate_table(self, value: float) -> float:
        """表格插值"""
        if not self.table:
            return value
        
        # 按原始值排序
        sorted_table = sorted(self.table, key=lambda x: x[0])
        
        # 线性插值
        for i in range(len(sorted_table) - 1):
            x1, y1 = sorted_table[i]
            x2, y2 = sorted_table[i + 1]
            
            if x1 <= value <= x2:
                ratio = (value - x1) / (x2 - x1) if x2 != x1 else 0
                return y1 + ratio * (y2 - y1)
        
        # 超出范围，返回最近的边界值
        if value < sorted_table[0][0]:
            return sorted_table[0][1]
        return sorted_table[-1][1]
    
    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "id": self.id,
            "type": self.type.name,
            "name": self.name,
            "comment": self.comment,
            "a": self.a,
            "b": self.b,
            "c": self.c,
            "d": self.d,
            "coeffs": self.coeffs.copy(),
            "table": self.table.copy(),
            "formula": self.formula,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'ChannelConversion':
        """从字典创建"""
        return cls(
            id=data.get("id", 0),
            type=ConversionType[data.get("type", "NONE")],
            name=data.get("name", ""),
            comment=data.get("comment", ""),
            a=data.get("a", 1.0),
            b=data.get("b", 0.0),
            c=data.get("c", 0.0),
            d=data.get("d", 1.0),
            coeffs=data.get("coeffs", []),
            table=[tuple(x) for x in data.get("table", [])],
            formula=data.get("formula", ""),
        )
    
    def __str__(self) -> str:
        if self.type == ConversionType.LINEAR:
            return f"ChannelConversion(type=LINEAR, y={self.a}*x+{self.b})"
        return f"ChannelConversion(type={self.type.name})"
