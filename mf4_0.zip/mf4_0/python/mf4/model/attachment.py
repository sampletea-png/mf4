"""
附件模型

Attachment 用于存储与测量相关的附加文件，如配置文件、图片等。
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class Attachment:
    """
    附件
    
    存储与 MF4 文件相关的附加文件。
    
    Attributes:
        id: 附件ID
        filename: 文件名
        content: 文件内容（字节）
        mime_type: MIME类型
        comment: 描述
        create_time: 创建时间
    
    Example:
        >>> with open("config.json", "rb") as f:
        ...     attachment = Attachment(
        ...         filename="config.json",
        ...         content=f.read(),
        ...         mime_type="application/json"
        ...     )
    """
    
    id: int = 0
    filename: str = ""
    content: bytes = field(default_factory=bytes)
    mime_type: str = "application/octet-stream"
    comment: str = ""
    create_time: Optional[datetime] = None
    
    def save_to(self, path: str) -> None:
        """保存附件到文件"""
        with open(path, "wb") as f:
            f.write(self.content)
    
    def get_size(self) -> int:
        """获取附件大小"""
        return len(self.content)
    
    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "id": self.id,
            "filename": self.filename,
            "mime_type": self.mime_type,
            "comment": self.comment,
            "create_time": self.create_time.isoformat() if self.create_time else None,
            "size": self.get_size(),
        }
    
    def __str__(self) -> str:
        return f"Attachment(filename='{self.filename}', size={self.get_size()} bytes)"
