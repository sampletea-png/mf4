"""
文件头数据模型

FileHeader 存储 MF4 文件的元信息，包括：
- 版本号
- 作者信息
- 时间戳
- 项目描述
- 注释信息

这些信息存储在 MF4 文件的 HDBLOCK 中。
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional
import uuid


@dataclass
class FileHeader:
    """
    MF4 文件头信息
    
    存储文件的元数据信息，对应 MF4 规范中的 HDBLOCK。
    
    Attributes:
        version: MF4 文件版本号（如 "4.10", "4.11"）
        program_id: 创建文件的程序标识符
        author: 作者姓名
        organization: 所属组织
        project: 项目名称
        subject: 主题/对象
        comment: 注释描述
        start_time: 测量开始时间（UTC）
        end_time: 测量结束时间（UTC，可选）
        file_uuid: 文件唯一标识符
        custom_fields: 自定义字段字典
    
    Example:
        >>> header = FileHeader(
        ...     author="John Doe",
        ...     organization="Example Corp",
        ...     project="Engine Testing",
        ...     comment="Test measurement"
        ... )
        >>> header.version = "4.10"
        >>> print(header.author)  # "John Doe"
    """
    
    # 文件版本号（遵循 ASAM MDF 规范）
    # 常见值：4.00, 4.10, 4.11
    version: str = "4.10"
    
    # 创建文件的程序标识符
    # 通常包含程序名称和版本，如 "MF4SDK 1.0"
    program_id: str = "MF4SDK"
    
    # 作者信息
    author: str = ""
    
    # 所属组织
    organization: str = ""
    
    # 项目名称
    project: str = ""
    
    # 测量主题/对象
    subject: str = ""
    
    # 详细注释
    comment: str = ""
    
    # 测量开始时间（UTC时区）
    # 如果未设置，默认为创建时间
    start_time: Optional[datetime] = None
    
    # 测量结束时间（UTC时区）
    # 如果测量仍在进行，可以为 None
    end_time: Optional[datetime] = None
    
    # 文件唯一标识符
    # 使用 UUID v4 格式，用于文件追踪和关联
    file_uuid: str = field(default_factory=lambda: str(uuid.uuid4()))
    
    # 自定义字段（用于存储扩展信息）
    # 键值对形式，值可以是任意 JSON 可序列化的类型
    custom_fields: dict = field(default_factory=dict)
    
    def __post_init__(self):
        """
        初始化后处理
        
        如果未设置开始时间，使用当前时间作为默认值。
        """
        if self.start_time is None:
            from datetime import timezone
            self.start_time = datetime.now(timezone.utc)
    
    def validate(self) -> list:
        """
        验证文件头数据
        
        检查所有必需字段是否已设置，以及数据格式是否正确。
        
        Returns:
            验证错误消息列表，空列表表示验证通过
            
        Example:
            >>> header = FileHeader()
            >>> errors = header.validate()
            >>> if errors:
            ...     print(f"Validation errors: {errors}")
        """
        errors = []
        
        # 验证版本号
        valid_versions = ("4.00", "4.10", "4.11", "4.20")
        if self.version not in valid_versions:
            errors.append(f"Invalid version: {self.version}, must be one of {valid_versions}")
        
        # 验证时间顺序
        if self.end_time and self.start_time:
            if self.end_time < self.start_time:
                errors.append("end_time must be greater than or equal to start_time")
        
        # 验证 UUID 格式
        try:
            uuid.UUID(self.file_uuid)
        except ValueError:
            errors.append(f"Invalid UUID format: {self.file_uuid}")
        
        return errors
    
    def to_dict(self) -> dict:
        """
        转换为字典格式
        
        用于序列化和导出文件头信息。
        
        Returns:
            包含所有文件头信息的字典
            
        Example:
            >>> header = FileHeader(author="Test")
            >>> header_dict = header.to_dict()
            >>> print(header_dict["author"])  # "Test"
        """
        return {
            "version": self.version,
            "program_id": self.program_id,
            "author": self.author,
            "organization": self.organization,
            "project": self.project,
            "subject": self.subject,
            "comment": self.comment,
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "file_uuid": self.file_uuid,
            "custom_fields": self.custom_fields.copy(),
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'FileHeader':
        """
        从字典创建 FileHeader
        
        Args:
            data: 包含文件头信息的字典
            
        Returns:
            新创建的 FileHeader 实例
            
        Example:
            >>> data = {"author": "Test", "version": "4.10"}
            >>> header = FileHeader.from_dict(data)
        """
        start_time = data.get("start_time")
        if start_time and isinstance(start_time, str):
            start_time = datetime.fromisoformat(start_time)
        
        end_time = data.get("end_time")
        if end_time and isinstance(end_time, str):
            end_time = datetime.fromisoformat(end_time)
        
        return cls(
            version=data.get("version", "4.10"),
            program_id=data.get("program_id", "MF4SDK"),
            author=data.get("author", ""),
            organization=data.get("organization", ""),
            project=data.get("project", ""),
            subject=data.get("subject", ""),
            comment=data.get("comment", ""),
            start_time=start_time,
            end_time=end_time,
            file_uuid=data.get("file_uuid", str(uuid.uuid4())),
            custom_fields=data.get("custom_fields", {}),
        )
    
    def __str__(self) -> str:
        """返回简短描述"""
        return f"FileHeader(version={self.version}, author={self.author})"
    
    def __repr__(self) -> str:
        """返回详细表示"""
        return (
            f"FileHeader(version='{self.version}', author='{self.author}', "
            f"organization='{self.organization}', project='{self.project}')"
        )
