"""
数据模型模块

定义 MF4 文件的核心数据结构，包括：
- FileHeader: 文件头信息
- DataGroup: 数据组
- ChannelGroup: 通道组
- Channel: 测量通道
- ChannelConversion: 通道转换规则
- Signal: 信号数据
- Attachment: 附件
- Metadata: 元数据

这些数据模型遵循 ASAM MDF 4.x 规范。
"""

from mf4.model.file_header import FileHeader
from mf4.model.data_group import DataGroup
from mf4.model.channel_group import ChannelGroup
from mf4.model.channel import Channel
from mf4.model.channel_conversion import ChannelConversion
from mf4.model.signal import Signal
from mf4.model.attachment import Attachment
from mf4.model.metadata import Metadata

__all__ = [
    "FileHeader",
    "DataGroup",
    "ChannelGroup",
    "Channel",
    "ChannelConversion",
    "Signal",
    "Attachment",
    "Metadata",
]
