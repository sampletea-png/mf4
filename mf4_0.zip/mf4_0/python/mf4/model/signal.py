"""
信号数据模型

Signal 是测量数据的完整表示，包含时间戳、数值和元信息。
"""

from dataclasses import dataclass, field
from typing import Optional, List, Any
import numpy as np


@dataclass
class Signal:
    """
    信号数据
    
    包含完整的测量信号，包括时间轴、数值和元信息。
    
    Attributes:
        name: 信号名称
        timestamps: 时间戳数组
        values: 数值数组
        unit: 单位
        comment: 描述
        source: 数据源信息
    
    Example:
        >>> import numpy as np
        >>> signal = Signal(
        ...     name="Engine_Speed",
        ...     timestamps=np.linspace(0, 10, 100),
        ...     values=np.random.uniform(1000, 6000, 100),
        ...     unit="rpm"
        ... )
    """
    
    name: str
    timestamps: np.ndarray
    values: np.ndarray
    unit: str = ""
    comment: str = ""
    source: str = ""
    
    def __len__(self) -> int:
        """返回数据点数量"""
        return len(self.values)
    
    def __getitem__(self, index):
        """获取指定索引的数据"""
        return (self.timestamps[index], self.values[index])
    
    def get_sample_rate(self) -> float:
        """计算平均采样率"""
        if len(self.timestamps) < 2:
            return 0.0
        duration = self.timestamps[-1] - self.timestamps[0]
        if duration == 0:
            return 0.0
        return len(self.timestamps) / duration
    
    def get_statistics(self) -> dict:
        """计算统计信息"""
        return {
            "min": float(np.min(self.values)),
            "max": float(np.max(self.values)),
            "mean": float(np.mean(self.values)),
            "std": float(np.std(self.values)),
            "count": len(self.values),
        }
    
    def get_value_at_time(self, time: float) -> float:
        """获取指定时间的值（线性插值）"""
        idx = np.searchsorted(self.timestamps, time)
        if idx == 0:
            return float(self.values[0])
        if idx >= len(self.timestamps):
            return float(self.values[-1])
        
        # 线性插值
        t1, t2 = self.timestamps[idx-1], self.timestamps[idx]
        v1, v2 = self.values[idx-1], self.values[idx]
        ratio = (time - t1) / (t2 - t1)
        return float(v1 + ratio * (v2 - v1))
    
    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "name": self.name,
            "timestamps": self.timestamps.tolist(),
            "values": self.values.tolist(),
            "unit": self.unit,
            "comment": self.comment,
            "source": self.source,
            "statistics": self.get_statistics(),
        }
    
    def __str__(self) -> str:
        return f"Signal(name='{self.name}', samples={len(self.values)})"
