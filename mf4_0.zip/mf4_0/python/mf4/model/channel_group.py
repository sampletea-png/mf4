"""
通道组数据模型

ChannelGroup 是一组相关通道的集合，所有通道共享相同的采样率。
"""

from dataclasses import dataclass, field
from typing import List, TYPE_CHECKING

if TYPE_CHECKING:
    from mf4.model.channel import Channel


@dataclass
class ChannelGroup:
    """
    通道组
    
    一组共享相同时间轴和采样率的测量通道集合。
    
    Attributes:
        id: 通道组ID
        name: 通道组名称
        comment: 描述注释
        channels: 通道列表
        data_group_id: 所属数据组ID
        record_id: 记录ID（用于数据记录索引）
        cycle_count: 周期数（记录数量）
        data_section_offset: 数据区偏移量
        record_size: 单条记录大小（字节）
    
    Example:
        >>> cg = ChannelGroup(name="Engine_Data")
        >>> cg.add_channel(Channel(name="Engine_Speed", unit="rpm"))
        >>> cg.add_channel(Channel(name="Throttle", unit="%"))
    """
    
    id: int = 0
    name: str = ""
    comment: str = ""
    
    # 通道列表
    channels: List['Channel'] = field(default_factory=list)
    
    # 所属数据组ID
    data_group_id: int = 0
    
    # 记录ID（用于多通道组时的标识）
    record_id: int = 0
    
    # 数据记录数量
    cycle_count: int = 0
    
    # 数据区起始位置
    data_section_offset: int = 0
    
    # 单条记录大小（字节）
    record_size: int = 0
    
    def add_channel(self, channel: 'Channel') -> None:
        """添加通道"""
        channel.channel_group_id = self.id
        self.channels.append(channel)
        self._update_record_size()
    
    def get_channel(self, name: str) -> 'Channel':
        """获取通道"""
        for ch in self.channels:
            if ch.name == name:
                return ch
        raise ValueError(f"Channel not found: {name}")
    
    def get_time_channel(self) -> 'Channel':
        """获取时间轴通道"""
        from mf4.enums import ChannelType
        for ch in self.channels:
            if ch.type == ChannelType.MASTER:
                return ch
        return None
    
    def _update_record_size(self) -> None:
        """更新记录大小"""
        total_bits = sum(ch.bit_count for ch in self.channels)
        self.record_size = (total_bits + 7) // 8
    
    def validate(self) -> list:
        """验证"""
        errors = []
        if not self.name:
            errors.append("ChannelGroup name is required")
        if self.record_size < 0:
            errors.append(f"Invalid record_size: {self.record_size}")
        return errors
    
    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "id": self.id,
            "name": self.name,
            "comment": self.comment,
            "channels": [ch.to_dict() for ch in self.channels],
            "data_group_id": self.data_group_id,
            "record_id": self.record_id,
            "cycle_count": self.cycle_count,
            "data_section_offset": self.data_section_offset,
            "record_size": self.record_size,
        }
    
    def __str__(self) -> str:
        return f"ChannelGroup(name='{self.name}', channels={len(self.channels)})"