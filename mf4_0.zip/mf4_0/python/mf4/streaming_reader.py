"""
MF4 流式读取器

用于处理大型 MF4 文件，避免一次性加载所有数据到内存。
支持逐批读取、随机访问、进度监控等功能。

使用场景:
- 处理超过内存容量的大型文件
- 实时数据流处理
- 后台数据导入

使用示例:
    # 逐批读取
    with Mf4StreamingReader.open("large.mf4", channels=["Engine_Speed"]) as reader:
        for batch in reader.read_batches(batch_size=10000):
            process(batch)
    
    # 迭代读取
    with Mf4StreamingReader.open("large.mf4") as reader:
        for signal in reader.iter_signals():
            print(f"{signal.name}: {len(signal)} samples")
"""

from typing import Optional, List, Dict, Iterator, Any
import warnings

import numpy as np
from asammdf import MDF

from mf4.config import Mf4Config
from mf4.model import Signal
from mf4.exceptions import Mf4Error, Mf4FileNotFoundError


class Mf4StreamingReader:
    """
    MF4 流式读取器
    
    支持大文件的分批处理，避免内存溢出。
    
    特点:
    - 支持指定通道列表
    - 支持时间范围截取
    - 支持进度回调
    - 支持随机访问
    
    Example:
        >>> with Mf4StreamingReader.open("large.mf4") as reader:
        ...     for batch in reader.read_batches(batch_size=5000):
        ...         # 处理每批数据
        ...         for name, data in batch.items():
        ...             print(f"{name}: mean={data.mean():.2f}")
    """
    
    def __init__(
        self,
        file_path: str,
        channels: Optional[List[str]] = None,
        buffer_size: int = 10000,
        config: Optional[Mf4Config] = None
    ):
        """
        初始化流式读取器
        
        Args:
            file_path: MF4 文件路径
            channels: 要读取的通道列表，None 表示读取所有通道
            buffer_size: 缓冲区大小（记录数）
            config: 配置实例
        """
        self._file_path = file_path
        self._channels = channels
        self._buffer_size = buffer_size
        self._config = config or Mf4Config.default()
        
        # asammdf MDF 实例
        self._mdf: Optional[MDF] = None
        
        # 当前读取位置
        self._current_position = 0
        
        # 总记录数
        self._total_records = 0
        
        # 是否已打开
        self._is_open = False
    
    @classmethod
    def open(
        cls,
        file_path: str,
        channels: Optional[List[str]] = None,
        buffer_size: int = 10000,
        config: Optional[Mf4Config] = None
    ):
        """
        上下文管理器方式打开文件
        
        Args:
            file_path: MF4 文件路径
            channels: 通道列表
            buffer_size: 缓冲区大小
            config: 配置实例
            
        Yields:
            Mf4StreamingReader: 流式读取器实例
        """
        reader = cls(file_path, channels, buffer_size, config)
        reader._open()
        return reader
    
    def _open(self) -> None:
        """打开文件"""
        if self._is_open:
            return
        
        import os
        if not os.path.exists(self._file_path):
            raise Mf4FileNotFoundError(self._file_path)
        
        try:
            # 使用最小化读取模式打开
            self._mdf = MDF(self._file_path, read_minimum=True)
            self._is_open = True
            
            # 如果没有指定通道，获取所有通道
            if self._channels is None:
                self._channels = list(self._mdf.channels_db.keys())
                # 过滤掉时间通道
                self._channels = [
                    ch for ch in self._channels 
                    if not ch.lower().startswith('time') or len(ch) > 10
                ]
                
        except Exception as e:
            raise Mf4Error(f"Failed to open file: {e}", file_path=self._file_path)
    
    def read_batches(
        self,
        batch_size: int = 10000,
        start_time: Optional[float] = None,
        end_time: Optional[float] = None
    ) -> Iterator[Dict[str, np.ndarray]]:
        """
        按批次读取数据
        
        每次返回一批数据，适合迭代处理大文件。
        
        Args:
            batch_size: 每批记录数
            start_time: 起始时间（秒）
            end_time: 结束时间（秒）
            
        Yields:
            Dict[str, np.ndarray]: 通道名到数据数组的映射
            
        Example:
            >>> for batch in reader.read_batches(batch_size=5000):
            ...     for name, data in batch.items():
            ...         print(f"Processing {name}: {len(data)} samples")
        """
        if self._mdf is None:
            self._open()
        
        # 获取第一个通道来确定总长度
        if not self._channels:
            return
        
        first_channel = self._channels[0]
        full_signal = self._mdf.get(first_channel, samples_only=False)
        total_samples = len(full_signal.samples)
        
        # 计算时间范围
        if start_time is not None or end_time is not None:
            timestamps = full_signal.timestamps
            start_idx = 0
            end_idx = total_samples
            
            if start_time is not None:
                start_idx = np.searchsorted(timestamps, start_time)
            if end_time is not None:
                end_idx = np.searchsorted(timestamps, end_time)
            
            total_samples = end_idx - start_idx
        
        # 分批读取
        offset = start_idx if start_time else 0
        
        while offset < (end_idx if end_time else total_samples):
            batch_end = min(offset + batch_size, end_idx if end_time else total_samples)
            
            batch = {}
            for channel_name in self._channels:
                # 读取指定范围的信号
                signal = self._mdf.get(
                    channel_name,
                    samples_only=False,
                    raw=False
                )
                
                # 截取批次数据
                batch[channel_name] = signal.samples[offset:batch_end]
            
            yield batch
            offset = batch_end
    
    def iter_signals(
        self,
        start_time: Optional[float] = None,
        end_time: Optional[float] = None
    ) -> Iterator[Signal]:
        """
        迭代读取信号
        
        逐个返回信号对象，适合需要完整元数据的场景。
        
        Args:
            start_time: 起始时间
            end_time: 结束时间
            
        Yields:
            Signal: 信号对象
        """
        if self._mdf is None:
            self._open()
        
        for channel_name in (self._channels or []):
            try:
                # 读取信号
                asam_signal = self._mdf.get(channel_name, samples_only=False)
                
                timestamps = asam_signal.timestamps
                values = asam_signal.samples
                
                # 应用时间范围过滤
                if start_time is not None or end_time is not None:
                    mask = np.ones(len(timestamps), dtype=bool)
                    if start_time is not None:
                        mask &= (timestamps >= start_time)
                    if end_time is not None:
                        mask &= (timestamps <= end_time)
                    timestamps = timestamps[mask]
                    values = values[mask]
                
                # 创建 Signal 对象
                signal = Signal(
                    name=channel_name,
                    timestamps=timestamps,
                    values=values,
                    unit=str(asam_signal.unit) if asam_signal.unit else '',
                )
                
                yield signal
                
            except Exception as e:
                warnings.warn(f"Failed to read channel {channel_name}: {e}")
    
    def get_progress(self) -> float:
        """
        获取读取进度
        
        Returns:
            float: 进度百分比 (0.0 - 1.0)
        """
        if self._total_records == 0:
            return 0.0
        return min(1.0, self._current_position / self._total_records)
    
    def close(self) -> None:
        """关闭文件"""
        if self._mdf is not None:
            try:
                self._mdf.close()
            except Exception:
                pass
            self._mdf = None
        
        self._is_open = False
    
    def __enter__(self) -> 'Mf4StreamingReader':
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()
    
    def __iter__(self) -> Iterator[Signal]:
        """支持迭代"""
        return self.iter_signals()
    
    def __del__(self):
        self.close()
    
    def __repr__(self) -> str:
        status = "open" if self._is_open else "closed"
        return f"Mf4StreamingReader(file='{self._file_path}', status='{status}')"