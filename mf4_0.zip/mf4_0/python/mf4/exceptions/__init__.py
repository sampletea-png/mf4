"""
异常定义模块

定义 MF4 SDK 中使用的各种异常类型，提供清晰的错误信息和层次结构。

异常层次结构:
    Mf4Error (基类)
    ├── Mf4FileNotFoundError - 文件未找到
    ├── Mf4CorruptedFileError - 文件损坏
    ├── Mf4UnsupportedVersionError - 版本不支持
    ├── Mf4PermissionError - 权限错误
    ├── Mf4ChannelNotFoundError - 通道未找到
    ├── Mf4DataGroupNotFoundError - 数据组未找到
    ├── Mf4ValidationError - 数据验证失败
    ├── Mf4ParseError - 解析错误
    └── Mf4WriteError - 写入错误
"""

from typing import Optional, List, Any


class Mf4Error(Exception):
    """
    MF4 SDK 基础异常类
    
    所有 MF4 相关异常的基类，提供统一的异常处理接口。
    
    Attributes:
        message: 错误消息
        file_path: 相关文件路径（可选）
        details: 详细错误信息列表（可选）
    
    Example:
        >>> try:
        ...     raise Mf4Error("操作失败", file_path="test.mf4")
        ... except Mf4Error as e:
        ...     print(f"Error: {e.message} in {e.file_path}")
    """
    
    def __init__(
        self,
        message: str,
        file_path: Optional[str] = None,
        details: Optional[List[str]] = None
    ):
        """
        初始化异常
        
        Args:
            message: 错误消息
            file_path: 相关文件路径（可选）
            details: 详细错误信息列表（可选）
        """
        self.message = message
        self.file_path = file_path
        self.details = details or []
        
        # 构建完整错误消息
        full_message = message
        if file_path:
            full_message = f"{message} (file: {file_path})"
        if details:
            full_message += f"\nDetails: {', '.join(details)}"
        
        super().__init__(full_message)
    
    def __str__(self) -> str:
        """返回错误消息字符串"""
        result = self.message
        if self.details:
            result += f" (details: {', '.join(self.details)})"
        return result
    
    def __repr__(self) -> str:
        """返回异常的详细表示"""
        return f"{self.__class__.__name__}(message='{self.message}', file_path='{self.file_path}')"


class Mf4FileNotFoundError(Mf4Error):
    """
    文件未找到异常
    
    当指定的 MF4 文件不存在时抛出。
    
    Example:
        >>> try:
        ...     reader = Mf4Reader.open("nonexistent.mf4")
        ... except Mf4FileNotFoundError as e:
        ...     print(f"文件不存在: {e.file_path}")
    """
    
    def __init__(self, file_path: str):
        """
        初始化异常
        
        Args:
            file_path: 未找到的文件路径
        """
        super().__init__(
            message=f"MF4 file not found: {file_path}",
            file_path=file_path
        )


class Mf4CorruptedFileError(Mf4Error):
    """
    文件损坏异常
    
    当 MF4 文件结构损坏或数据不完整时抛出。
    
    Attributes:
        block_type: 损坏的块类型（可选）
        offset: 损坏位置的偏移量（可选）
    
    Example:
        >>> try:
        ...     reader = Mf4Reader.open("corrupted.mf4")
        ... except Mf4CorruptedFileError as e:
        ...     print(f"文件损坏: {e.message}, 块类型: {e.block_type}")
    """
    
    def __init__(
        self,
        message: str,
        file_path: Optional[str] = None,
        block_type: Optional[str] = None,
        offset: Optional[int] = None
    ):
        """
        初始化异常
        
        Args:
            message: 错误消息
            file_path: 文件路径（可选）
            block_type: 损坏的块类型（可选）
            offset: 损坏位置的偏移量（可选）
        """
        self.block_type = block_type
        self.offset = offset
        
        details = []
        if block_type:
            details.append(f"block_type={block_type}")
        if offset:
            details.append(f"offset={offset}")
        
        super().__init__(message, file_path, details)


class Mf4UnsupportedVersionError(Mf4Error):
    """
    版本不支持异常
    
    当尝试读取不支持的 MF4 版本时抛出。
    
    Attributes:
        version: 不支持的版本号
    
    Example:
        >>> try:
        ...     reader = Mf4Reader.open("old_version.mf4")
        ... except Mf4UnsupportedVersionError as e:
        ...     print(f"不支持版本: {e.version}")
    """
    
    def __init__(
        self,
        version: str,
        file_path: Optional[str] = None,
        supported_versions: Optional[List[str]] = None
    ):
        """
        初始化异常
        
        Args:
            version: 不支持的版本号
            file_path: 文件路径（可选）
            supported_versions: 支持的版本列表（可选）
        """
        self.version = version
        self.supported_versions = supported_versions or ["4.10", "4.11"]
        
        message = f"Unsupported MF4 version: {version}"
        details = [f"supported_versions={','.join(self.supported_versions)}"]
        
        super().__init__(message, file_path, details)


class Mf4PermissionError(Mf4Error):
    """
    权限错误异常
    
    当缺少读取或写入文件的权限时抛出。
    
    Example:
        >>> try:
        ...     writer = Mf4Writer.create("/protected/path.mf4")
        ... except Mf4PermissionError as e:
        ...     print(f"权限不足: {e.file_path}")
    """
    
    def __init__(
        self,
        file_path: str,
        operation: str = "read"
    ):
        """
        初始化异常
        
        Args:
            file_path: 文件路径
            operation: 操作类型 ("read" 或 "write")
        """
        self.operation = operation
        
        super().__init__(
            message=f"Permission denied for {operation} operation",
            file_path=file_path,
            details=[f"operation={operation}"]
        )


class Mf4ChannelNotFoundError(Mf4Error):
    """
    通道未找到异常
    
    当请求的通道在 MF4 文件中不存在时抛出。
    
    Attributes:
        channel_name: 未找到的通道名称
    
    Example:
        >>> try:
        ...     signal = reader.read_channel("Nonexistent_Channel")
        ... except Mf4ChannelNotFoundError as e:
        ...     print(f"通道不存在: {e.channel_name}")
    """
    
    def __init__(
        self,
        channel_name: str,
        file_path: Optional[str] = None,
        available_channels: Optional[List[str]] = None
    ):
        """
        初始化异常
        
        Args:
            channel_name: 未找到的通道名称
            file_path: 文件路径（可选）
            available_channels: 可用通道列表（可选）
        """
        self.channel_name = channel_name
        self.available_channels = available_channels
        
        message = f"Channel not found: '{channel_name}'"
        details = []
        if available_channels:
            details.append(f"available_channels count={len(available_channels)}")
        
        super().__init__(message, file_path, details)


class Mf4DataGroupNotFoundError(Mf4Error):
    """
    数据组未找到异常
    
    当请求的数据组不存在时抛出。
    
    Attributes:
        data_group_id: 未找到的数据组ID
    
    Example:
        >>> try:
        ...     dg = reader.get_data_group(999)
        ... except Mf4DataGroupNotFoundError as e:
        ...     print(f"数据组不存在: ID={e.data_group_id}")
    """
    
    def __init__(
        self,
        data_group_id: int,
        file_path: Optional[str] = None
    ):
        """
        初始化异常
        
        Args:
            data_group_id: 未找到的数据组ID
            file_path: 文件路径（可选）
        """
        self.data_group_id = data_group_id
        
        super().__init__(
            message=f"Data group not found: ID={data_group_id}",
            file_path=file_path
        )


class Mf4ValidationError(Mf4Error):
    """
    数据验证失败异常
    
    当数据验证失败时抛出，包含详细的验证错误信息。
    
    Attributes:
        validation_errors: 验证错误列表
    
    Example:
        >>> try:
        ...     writer.write_data(cg_id, data)
        ... except Mf4ValidationError as e:
        ...     for error in e.validation_errors:
        ...         print(f"验证错误: {error}")
    """
    
    def __init__(
        self,
        message: str,
        validation_errors: Optional[List[str]] = None,
        file_path: Optional[str] = None
    ):
        """
        初始化异常
        
        Args:
            message: 错误消息
            validation_errors: 验证错误列表（可选）
            file_path: 文件路径（可选）
        """
        self.validation_errors = validation_errors or []
        
        super().__init__(
            message=message,
            file_path=file_path,
            details=self.validation_errors
        )


class Mf4ParseError(Mf4Error):
    """
    解析错误异常
    
    当解析 MF4 文件块时发生错误时抛出。
    
    Attributes:
        block_type: 解析失败的块类型
        offset: 解析位置的偏移量
    
    Example:
        >>> try:
        ...     parser.parse_block(offset=100)
        ... except Mf4ParseError as e:
        ...     print(f"解析失败: {e.block_type} at {e.offset}")
    """
    
    def __init__(
        self,
        message: str,
        block_type: Optional[str] = None,
        offset: Optional[int] = None,
        file_path: Optional[str] = None
    ):
        """
        初始化异常
        
        Args:
            message: 错误消息
            block_type: 块类型（可选）
            offset: 块偏移量（可选）
            file_path: 文件路径（可选）
        """
        self.block_type = block_type
        self.offset = offset
        
        details = []
        if block_type:
            details.append(f"block_type={block_type}")
        if offset:
            details.append(f"offset={offset:#x}")
        
        super().__init__(message, file_path, details)


class Mf4WriteError(Mf4Error):
    """
    写入错误异常
    
    当写入 MF4 文件时发生错误时抛出。
    
    Example:
        >>> try:
        ...     writer.save()
        ... except Mf4WriteError as e:
        ...     print(f"写入失败: {e.message}")
    """
    
    def __init__(
        self,
        message: str,
        file_path: Optional[str] = None
    ):
        """
        初始化异常
        
        Args:
            message: 错误消息
            file_path: 文件路径（可选）
        """
        super().__init__(message, file_path)


class Mf4ConversionError(Mf4Error):
    """
    数据转换错误异常
    
    当数据转换失败时抛出。
    
    Attributes:
        conversion_type: 转换类型
        raw_value: 原始值
    
    Example:
        >>> try:
        ...     converted = conversion.apply(value)
        ... except Mf4ConversionError as e:
        ...     print(f"转换失败: {e.raw_value}")
    """
    
    def __init__(
        self,
        message: str,
        conversion_type: Optional[str] = None,
        raw_value: Optional[Any] = None
    ):
        """
        初始化异常
        
        Args:
            message: 错误消息
            conversion_type: 转换类型（可选）
            raw_value: 原始值（可选）
        """
        self.conversion_type = conversion_type
        self.raw_value = raw_value
        
        details = []
        if conversion_type:
            details.append(f"conversion_type={conversion_type}")
        if raw_value is not None:
            details.append(f"raw_value={raw_value}")
        
        super().__init__(message, details=details)