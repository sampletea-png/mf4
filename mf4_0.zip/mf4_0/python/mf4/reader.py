"""
MF4 文件读取器

基于 asammdf 库实现的 MF4 文件读取功能。
提供完整的文件解析、通道读取、数据查询等功能。

asammdf 库核心概念:
- MDF: 主类，表示一个 MDF 文件
- Signal: 信号数据，包含时间戳、数值和元信息
- Channel: 通道元数据

使用示例:
    # 基本读取
    with Mf4Reader.open("measurement.mf4") as reader:
        signal = reader.read_channel("Engine_Speed")
        print(f"平均转速: {signal.values.mean()} rpm")
    
    # 批量读取
    with Mf4Reader.open("measurement.mf4") as reader:
        signals = reader.read_channels(["Engine_Speed", "Vehicle_Speed"])
        for name, signal in signals.items():
            print(f"{name}: {len(signal)} 个数据点")
"""

from typing import Optional, List, Dict, Any, Iterator, Union
from contextlib import contextmanager
import os
import warnings

# 第三方库
import numpy as np
from asammdf import MDF
from asammdf.blocks.utils import MdfException as AsamMdfException

# 本地模块
from mf4.config import Mf4Config
from mf4.model import (
    FileHeader, DataGroup, ChannelGroup, Channel,
    ChannelConversion, Signal, Attachment, Metadata
)
from mf4.enums import DataType, ChannelType, ConversionType
from mf4.exceptions import (
    Mf4Error, Mf4FileNotFoundError, Mf4CorruptedFileError,
    Mf4UnsupportedVersionError, Mf4ChannelNotFoundError
)


class Mf4Reader:
    """
    MF4 文件读取器
    
    提供完整的 MF4 文件读取功能，包括：
    - 文件头元数据读取
    - 通道列表获取
    - 单个/批量通道数据读取
    - 数据过滤和查询
    - 转换为其他格式
    
    属性:
        file_path: MF4 文件路径
        config: 配置实例
        header: 文件头信息（惰性加载）
        
    Example:
        >>> with Mf4Reader.open("test.mf4") as reader:
        ...     # 获取文件信息
        ...     print(f"版本: {reader.header.version}")
        ...     print(f"作者: {reader.header.author}")
        ...     
        ...     # 获取通道列表
        ...     channels = reader.get_channels()
        ...     print(f"通道数量: {len(channels)}")
        ...     
        ...     # 读取数据
        ...     signal = reader.read_channel("Engine_Speed")
        ...     stats = signal.get_statistics()
        ...     print(f"平均值: {stats['mean']:.2f}")
    
    Note:
        - 使用 context manager 确保资源正确释放
        - 大文件建议使用 Mf4StreamingReader
        - 默认缓存元数据以提高重复访问性能
    """
    
    def __init__(self, file_path: str, config: Optional[Mf4Config] = None):
        """
        初始化读取器
        
        Args:
            file_path: MF4 文件路径，支持相对路径和绝对路径
            config: 配置实例，可选。不提供时使用默认配置。
            
        Raises:
            Mf4FileNotFoundError: 文件不存在
            Mf4Error: 文件不可读
            
        Example:
            >>> reader = Mf4Reader("measurement.mf4")
            >>> reader.close()
        """
        self._file_path = os.path.abspath(file_path)
        self._config = config or Mf4Config.default()
        
        # asammdf MDF 实例（核心对象）
        self._mdf: Optional[MDF] = None
        
        # 文件是否已打开
        self._is_open = False
        
        # 缓存的元数据（惰性加载）
        self._header: Optional[FileHeader] = None
        self._channels_cache: Optional[Dict[str, Channel]] = None
        self._groups_cache: Optional[List[ChannelGroup]] = None
        
        # 验证文件
        self._validate_file()
    
    def _validate_file(self) -> None:
        """
        验证文件存在性和可读性
        
        检查项目:
        1. 文件是否存在
        2. 是否为普通文件（非目录）
        3. 是否具有读取权限
        4. 文件大小是否超过限制
        
        Raises:
            Mf4FileNotFoundError: 文件不存在
            Mf4Error: 文件不可读或超过大小限制
        """
        # 检查文件存在
        if not os.path.exists(self._file_path):
            raise Mf4FileNotFoundError(self._file_path)
        
        # 检查是否为文件
        if not os.path.isfile(self._file_path):
            raise Mf4Error(f"Path is not a file: {self._file_path}")
        
        # 检查读取权限
        if not os.access(self._file_path, os.R_OK):
            raise Mf4Error(f"Cannot read file: {self._file_path}")
        
        # 检查文件大小限制
        file_size = os.path.getsize(self._file_path)
        max_size = int(self._config.max_file_size_gb * 1024 * 1024 * 1024)
        if file_size > max_size:
            raise Mf4Error(
                f"File too large: {file_size / (1024**3):.2f} GB "
                f"(max: {self._config.max_file_size_gb} GB)"
            )
    
    @classmethod
    @contextmanager
    def open(cls, file_path: str, config: Optional[Mf4Config] = None):
        """
        上下文管理器方式打开文件（推荐方式）
        
        自动管理文件句柄的生命周期，确保资源正确释放。
        这是使用 Mf4Reader 的推荐方式。
        
        Args:
            file_path: MF4 文件路径
            config: 配置实例（可选）
            
        Yields:
            Mf4Reader: 已打开的读取器实例
            
        Example:
            >>> with Mf4Reader.open("measurement.mf4") as reader:
            ...     signal = reader.read_channel("Engine_Speed")
            ...     print(signal.values.mean())
        """
        reader = cls(file_path, config)
        try:
            reader._open()
            yield reader
        finally:
            reader.close()
    
    def _open(self) -> None:
        """
        打开文件并初始化 asammdf MDF 对象
        
        使用 asammdf 的 MDF 类打开文件，设置相关参数。
        
        Raises:
            Mf4Error: 打开文件失败
        """
        if self._is_open:
            return
        
        try:
            # 使用 asammdf 打开 MDF 文件
            # read_minimum: 只读取最小元数据，提高大文件打开速度
            self._mdf = MDF(
                self._file_path,
                read_minimum=True,  # 最小化读取，惰性加载
            )
            self._is_open = True
            
            # 如果配置了验证，则验证文件结构
            if self._config.validate_on_read:
                self._validate_structure()
                
        except Exception as e:
            # 捕获并转换异常
            raise Mf4Error(
                f"Failed to open MF4 file: {e}",
                file_path=self._file_path
            )
    
    def _validate_structure(self) -> None:
        """
        验证 MDF 文件结构完整性
        
        检查文件版本是否支持，以及基本结构是否正确。
        
        Raises:
            Mf4UnsupportedVersionError: 版本不支持
            Mf4CorruptedFileError: 文件结构损坏
        """
        if self._mdf is None:
            return
        
        # 检查版本
        version = self._mdf.version
        
        # 支持的版本列表（MDF 4.x）
        supported_versions = ('4.00', '4.10', '4.11', '4.20')
        if version and not version.startswith('4'):
            raise Mf4UnsupportedVersionError(
                version=version or 'unknown',
                file_path=self._file_path,
                supported_versions=list(supported_versions)
            )
    
    @property
    def header(self) -> FileHeader:
        """
        获取文件头信息（惰性加载）
        
        文件头包含：
        - 版本信息
        - 作者、组织、项目信息
        - 开始和结束时间
        - 其他元数据
        
        Returns:
            FileHeader: 文件头实例
            
        Example:
            >>> header = reader.header
            >>> print(f"版本: {header.version}")
            >>> print(f"作者: {header.author}")
            >>> print(f"开始时间: {header.start_time}")
        """
        if self._header is None:
            self._header = self._load_header()
        return self._header
    
    def _load_header(self) -> FileHeader:
        """
        从 MDF 文件加载文件头信息
        
        asammdf 中文件头信息存储在 MDF 对象的属性中。
        
        Returns:
            FileHeader: 文件头实例
        """
        if self._mdf is None:
            self._open()
        
        # 从 MDF 对象提取头信息
        # asammdf 存储格式可能因版本不同有差异
        header = FileHeader()
        
        try:
            # 尝试获取版本信息
            if hasattr(self._mdf, 'version'):
                header.version = self._mdf.version or '4.10'
            
            # 尝试获取作者信息（asammdf 中可能存储在不同位置）
            if hasattr(self._mdf, 'author'):
                header.author = str(self._mdf.author) if self._mdf.author else ''
            
            if hasattr(self._mdf, 'organization'):
                header.organization = str(self._mdf.organization) if self._mdf.organization else ''
            
            if hasattr(self._mdf, 'project'):
                header.project = str(self._mdf.project) if self._mdf.project else ''
                
        except Exception:
            # 如果获取失败，使用默认值
            pass
        
        return header
    
    def get_channels(self) -> List[Channel]:
        """
        获取文件中所有通道的列表
        
        遍历所有通道组，提取每个通道的元数据。
        
        Returns:
            List[Channel]: 通道对象列表
            
        Example:
            >>> channels = reader.get_channels()
            >>> for ch in channels:
            ...     print(f"{ch.name}: {ch.unit}")
        """
        if self._channels_cache is None:
            self._channels_cache = self._load_channels()
        return list(self._channels_cache.values())
    
    def _load_channels(self) -> Dict[str, Channel]:
        """
        从 MDF 文件加载所有通道元数据
        
        asammdf 提供了 channels_db 属性获取通道列表。
        
        Returns:
            Dict[str, Channel]: 通道名到 Channel 对象的映射
        """
        if self._mdf is None:
            self._open()
        
        channels = {}
        
        # asammdf 使用 channels_db 存储通道信息
        # channels_db 是一个字典，键为通道名
        if hasattr(self._mdf, 'channels_db'):
            for name, info in self._mdf.channels_db.items():
                # 跳过时间通道（以 'time' 开头的通常是时间轴）
                if name.lower().startswith('time') and len(name) < 10:
                    continue
                
                channel = Channel(
                    name=name,
                    unit=self._get_channel_unit(name),
                    comment=self._get_channel_comment(name),
                )
                channels[name] = channel
        
        return channels
    
    def _get_channel_unit(self, name: str) -> str:
        """
        获取通道的物理单位
        
        Args:
            name: 通道名称
            
        Returns:
            str: 单位字符串
        """
        try:
            if self._mdf is None:
                return ''
            
            # 尝试通过 get_channel_unit 获取
            unit = self._mdf.get_channel_unit(name)
            return str(unit) if unit else ''
        except Exception:
            return ''
    
    def _get_channel_comment(self, name: str) -> str:
        """
        获取通道的注释/描述
        
        Args:
            name: 通道名称
            
        Returns:
            str: 注释字符串
        """
        try:
            if self._mdf is None:
                return ''
            
            # 尝试获取注释
            comment = self._mdf.get_channel_comment(name)
            return str(comment) if comment else ''
        except Exception:
            return ''
    
    def get_channel(self, name: str) -> Channel:
        """
        获取指定名称的通道元数据
        
        Args:
            name: 通道名称
            
        Returns:
            Channel: 通道对象
            
        Raises:
            Mf4ChannelNotFoundError: 通道不存在
            
        Example:
            >>> channel = reader.get_channel("Engine_Speed")
            >>> print(f"单位: {channel.unit}")
        """
        channels = self.get_channels()
        
        for ch in channels:
            if ch.name == name:
                return ch
        
        # 通道不存在，抛出异常
        available = [ch.name for ch in channels[:10]]  # 只显示前10个
        raise Mf4ChannelNotFoundError(
            name,
            file_path=self._file_path,
            available_channels=available
        )
    
    def read_channel(
        self,
        name: str,
        start_time: Optional[float] = None,
        end_time: Optional[float] = None
    ) -> Signal:
        """
        读取指定通道的完整数据
        
        使用 asammdf 的 get_channel 方法读取信号数据。
        
        Args:
            name: 通道名称
            start_time: 起始时间（秒），可选。用于截取时间范围
            end_time: 结束时间（秒），可选
            
        Returns:
            Signal: 信号对象，包含时间戳和数值
            
        Raises:
            Mf4ChannelNotFoundError: 通道不存在
            
        Example:
            >>> # 读取完整数据
            >>> signal = reader.read_channel("Engine_Speed")
            >>> print(f"数据点: {len(signal)}")
            
            >>> # 读取指定时间范围
            >>> signal = reader.read_channel("Engine_Speed", 
            ...                               start_time=10.0,
            ...                               end_time=20.0)
        """
        if self._mdf is None:
            self._open()
        
        try:
            # 使用 asammdf 的 get 方法获取信号
            # get 方法返回一个 Signal 对象
            asam_signal = self._mdf.get(
                name,
                samples_only=False,  # 返回完整信号对象
            )
            
            if asam_signal is None:
                raise Mf4ChannelNotFoundError(name, file_path=self._file_path)
            
            # 提取时间戳和数值
            timestamps = asam_signal.timestamps
            values = asam_signal.samples
            
            # 应用时间范围过滤
            if start_time is not None or end_time is not None:
                mask = np.ones(len(timestamps), dtype=bool)
                if start_time is not None:
                    mask &= (timestamps >= start_time)
                if end_time is not None:
                    mask &= (timestamps <= end_time)
                timestamps = timestamps[mask]
                values = values[mask]
            
            # 创建 Signal 对象
            signal = Signal(
                name=name,
                timestamps=timestamps,
                values=values,
                unit=str(asam_signal.unit) if asam_signal.unit else '',
                comment=str(asam_signal.comment) if asam_signal.comment else '',
            )
            
            return signal
            
        except (KeyError, AsamMdfException):
            # asammdf 抛出 KeyError 或 MdfException 表示通道不存在
            raise Mf4ChannelNotFoundError(name, file_path=self._file_path)
    
    def read_channels(
        self,
        names: List[str],
        start_time: Optional[float] = None,
        end_time: Optional[float] = None
    ) -> Dict[str, Signal]:
        """
        批量读取多个通道的数据
        
        Args:
            names: 通道名称列表
            start_time: 起始时间（秒），可选
            end_time: 结束时间（秒），可选
            
        Returns:
            Dict[str, Signal]: 通道名到 Signal 对象的映射
            
        Example:
            >>> signals = reader.read_channels(["Engine_Speed", "Vehicle_Speed"])
            >>> for name, signal in signals.items():
            ...     print(f"{name}: {len(signal)} 点")
        """
        signals = {}
        for name in names:
            try:
                signals[name] = self.read_channel(name, start_time, end_time)
            except Mf4ChannelNotFoundError:
                warnings.warn(f"Channel not found: {name}")
        return signals
    
    def get_channel_groups(self) -> List[ChannelGroup]:
        """
        获取所有通道组
        
        Returns:
            List[ChannelGroup]: 通道组列表
        """
        if self._groups_cache is None:
            self._groups_cache = self._load_channel_groups()
        return self._groups_cache
    
    def _load_channel_groups(self) -> List[ChannelGroup]:
        """加载通道组信息"""
        if self._mdf is None:
            self._open()
        
        groups = []
        
        # asammdf 使用 groups 属性存储通道组
        for i, group in enumerate(self._mdf.groups):
            cg = ChannelGroup(
                id=i,
                name=f"Group_{i}",
            )
            groups.append(cg)
        
        return groups
    
    def filter_channels(
        self,
        name_pattern: Optional[str] = None,
        unit: Optional[str] = None,
        data_type: Optional[DataType] = None
    ) -> List[Channel]:
        """
        按条件过滤通道
        
        Args:
            name_pattern: 通道名称模式（支持通配符 *）
            unit: 物理单位
            data_type: 数据类型
            
        Returns:
            List[Channel]: 符合条件的通道列表
            
        Example:
            >>> # 查找所有以 Engine 开头的通道
            >>> channels = reader.filter_channels(name_pattern="Engine_*")
            
            >>> # 查找所有单位为 rpm 的通道
            >>> channels = reader.filter_channels(unit="rpm")
        """
        import fnmatch
        
        channels = self.get_channels()
        result = []
        
        for ch in channels:
            # 名称模式匹配
            if name_pattern:
                if not fnmatch.fnmatch(ch.name, name_pattern):
                    continue
            
            # 单位匹配
            if unit and ch.unit != unit:
                continue
            
            # 数据类型匹配
            if data_type and ch.data_type != data_type:
                continue
            
            result.append(ch)
        
        return result
    
    def to_dataframe(
        self,
        channels: Optional[List[str]] = None,
        start_time: Optional[float] = None,
        end_time: Optional[float] = None
    ):
        """
        导出为 pandas DataFrame
        
        Args:
            channels: 要导出的通道列表，可选。默认导出所有通道
            start_time: 起始时间，可选
            end_time: 结束时间，可选
            
        Returns:
            pandas.DataFrame: 包含时间戳和各通道数据的数据框
            
        Example:
            >>> df = reader.to_dataframe(["Engine_Speed", "Vehicle_Speed"])
            >>> print(df.head())
        """
        try:
            import pandas as pd
        except ImportError:
            raise ImportError("pandas is required. Install with: pip install pandas")
        
        if channels is None:
            channels = [ch.name for ch in self.get_channels()]
        
        # 读取第一个通道获取时间戳
        first_signal = self.read_channel(channels[0], start_time, end_time)
        data = {'timestamp': first_signal.timestamps}
        
        # 读取所有通道数据
        for name in channels:
            signal = self.read_channel(name, start_time, end_time)
            data[name] = signal.values
        
        return pd.DataFrame(data)
    
    def close(self) -> None:
        """
        关闭文件并释放资源
        
        显式关闭文件，释放文件句柄和内存。
        如果使用 context manager，会自动调用此方法。
        
        Example:
            >>> reader = Mf4Reader("test.mf4")
            >>> reader._open()
            >>> # 使用完毕后关闭
            >>> reader.close()
        """
        if self._mdf is not None:
            try:
                self._mdf.close()
            except Exception:
                pass
            self._mdf = None
        
        self._is_open = False
    
    def __enter__(self) -> 'Mf4Reader':
        """上下文管理器入口"""
        self._open()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """上下文管理器出口，自动关闭文件"""
        self.close()
    
    def __del__(self):
        """析构函数，确保资源释放"""
        self.close()
    
    def __repr__(self) -> str:
        """返回对象的字符串表示"""
        status = "open" if self._is_open else "closed"
        return f"Mf4Reader(file_path='{self._file_path}', status='{status}')"
    
    def __str__(self) -> str:
        """返回简要描述"""
        return f"MF4 Reader: {os.path.basename(self._file_path)}"