"""
MF4 格式转换器

将 MF4 文件转换为其他格式，支持：
- CSV: 逗号分隔值文件
- Parquet: Apache Parquet 列式存储
- HDF5: 层次数据格式
- Excel: Microsoft Excel 格式
- JSON: JSON 数据格式

使用示例:
    from mf4 import Mf4Converter
    
    # 转换为 CSV
    converter = Mf4Converter("input.mf4")
    converter.to_csv("output.csv")
    
    # 只转换指定通道
    converter.to_csv("output.csv", channels=["Engine_Speed", "Vehicle_Speed"])
    
    # 转换为 Parquet
    converter.to_parquet("output.parquet")
"""

from typing import Optional, List, Dict, Any
import os
import warnings

import numpy as np
from asammdf import MDF

from mf4.reader import Mf4Reader
from mf4.config import Mf4Config
from mf4.exceptions import Mf4Error


class Mf4Converter:
    """
    MF4 格式转换器
    
    提供多种格式转换功能，支持选择性导出和数据过滤。
    
    Example:
        >>> converter = Mf4Converter("measurement.mf4")
        >>> 
        >>> # 导出所有通道到 CSV
        >>> converter.to_csv("output.csv")
        >>> 
        >>> # 只导出特定通道
        >>> converter.to_csv(
        ...     "output.csv",
        ...     channels=["Engine_Speed", "Vehicle_Speed"]
        ... )
        >>> 
        >>> # 导出到 Parquet
        >>> converter.to_parquet("output.parquet")
        >>> 
        >>> converter.close()
    
    Note:
        - 大文件转换建议使用较小的批次大小
        - Parquet 和 HDF5 需要额外安装依赖库
    """
    
    def __init__(self, file_path: str, config: Optional[Mf4Config] = None):
        """
        初始化转换器
        
        Args:
            file_path: 输入的 MF4 文件路径
            config: 配置实例（可选）
        """
        self._file_path = file_path
        self._config = config or Mf4Config.default()
        
        # asammdf MDF 实例
        self._mdf: Optional[MDF] = None
        
        # Mf4Reader 实例（复用读取功能）
        self._reader: Optional[Mf4Reader] = None
    
    def _get_mdf(self) -> MDF:
        """获取或打开 MDF 实例"""
        if self._mdf is None:
            self._mdf = MDF(self._file_path, read_minimum=True)
        return self._mdf
    
    def _get_reader(self) -> Mf4Reader:
        """获取或打开 Reader 实例"""
        if self._reader is None:
            self._reader = Mf4Reader(self._file_path, self._config)
            self._reader._open()
        return self._reader
    
    def to_csv(
        self,
        output_path: str,
        channels: Optional[List[str]] = None,
        delimiter: str = ",",
        include_timestamp: bool = True,
        time_column: str = "timestamp",
        start_time: Optional[float] = None,
        end_time: Optional[float] = None,
        max_rows: Optional[int] = None
    ) -> None:
        """
        转换为 CSV 文件
        
        CSV 是最通用的数据交换格式，适合：
        - 数据导入到其他工具
        - 快速数据查看
        - 电子表格处理
        
        Args:
            output_path: 输出 CSV 文件路径
            channels: 要导出的通道列表，None 表示全部
            delimiter: 分隔符，默认逗号
            include_timestamp: 是否包含时间戳列
            time_column: 时间戳列名
            start_time: 起始时间（秒）
            end_time: 结束时间（秒）
            max_rows: 最大导出行数
            
        Example:
            >>> converter.to_csv("output.csv")
            
            >>> # 自定义选项
            >>> converter.to_csv(
            ...     "output.csv",
            ...     channels=["Engine_Speed"],
            ...     delimiter=";",
            ...     start_time=10.0,
            ...     end_time=20.0
            ... )
        """
        mdf = self._get_mdf()
        
        # 获取通道列表
        if channels is None:
            channels = [
                ch for ch in mdf.channels_db.keys()
                if not ch.lower().startswith('time') or len(ch) > 10
            ]
        
        if not channels:
            raise Mf4Error("No channels to export")
        
        # 读取第一个通道获取时间戳
        first_signal = mdf.get(channels[0], samples_only=False)
        timestamps = first_signal.timestamps
        total_samples = len(timestamps)
        
        # 应用时间范围过滤
        start_idx = 0
        end_idx = total_samples
        
        if start_time is not None:
            start_idx = np.searchsorted(timestamps, start_time)
        if end_time is not None:
            end_idx = np.searchsorted(timestamps, end_time)
        
        # 应用最大行数限制
        if max_rows is not None and (end_idx - start_idx) > max_rows:
            end_idx = start_idx + max_rows
        
        timestamps = timestamps[start_idx:end_idx]
        
        # 读取所有通道数据
        data = {}
        for channel_name in channels:
            try:
                signal = mdf.get(channel_name, samples_only=False)
                data[channel_name] = signal.samples[start_idx:end_idx]
            except Exception as e:
                warnings.warn(f"Failed to read channel {channel_name}: {e}")
        
        # 写入 CSV
        with open(output_path, 'w', encoding='utf-8') as f:
            # 写入表头
            headers = []
            if include_timestamp:
                headers.append(time_column)
            headers.extend(data.keys())
            f.write(delimiter.join(headers) + '\n')
            
            # 写入数据
            for i in range(len(timestamps)):
                row = []
                if include_timestamp:
                    row.append(f"{timestamps[i]:.6f}")
                for channel_name in data.keys():
                    value = data[channel_name][i]
                    if np.isnan(value):
                        row.append("")
                    else:
                        row.append(f"{value}")
                f.write(delimiter.join(row) + '\n')
        
        print(f"Exported {len(timestamps)} rows to {output_path}")
    
    def to_parquet(
        self,
        output_path: str,
        channels: Optional[List[str]] = None,
        compression: str = "snappy",
        start_time: Optional[float] = None,
        end_time: Optional[float] = None
    ) -> None:
        """
        转换为 Parquet 文件
        
        Parquet 是高效的列式存储格式，适合：
        - 大数据分析和处理
        - 与 Spark、Pandas 等工具集成
        - 高效压缩存储
        
        Args:
            output_path: 输出 Parquet 文件路径
            channels: 要导出的通道列表
            compression: 压缩算法 (snappy, gzip, brotli, none)
            start_time: 起始时间
            end_time: 结束时间
            
        Raises:
            ImportError: 未安装 pyarrow 或 pandas
            
        Example:
            >>> converter.to_parquet("output.parquet", compression="gzip")
        """
        try:
            import pandas as pd
            import pyarrow as pa
            import pyarrow.parquet as pq
        except ImportError:
            raise ImportError(
                "pyarrow and pandas are required for Parquet export. "
                "Install with: pip install pyarrow pandas"
            )
        
        # 使用 to_dataframe 方法获取数据
        reader = self._get_reader()
        df = reader.to_dataframe(channels, start_time, end_time)
        
        # 保存为 Parquet
        df.to_parquet(
            output_path,
            compression=compression,
            index=False
        )
        
        print(f"Exported {len(df)} rows to {output_path}")
    
    def to_hdf5(
        self,
        output_path: str,
        channels: Optional[List[str]] = None,
        group_path: str = "/measurement",
        compression: str = "gzip",
        start_time: Optional[float] = None,
        end_time: Optional[float] = None
    ) -> None:
        """
        转换为 HDF5 文件
        
        HDF5 是科学计算的常用格式，适合：
        - 数值数据分析
        - Python/Matlab 互操作
        - 层次化数据组织
        
        Args:
            output_path: 输出 HDF5 文件路径
            channels: 要导出的通道列表
            group_path: HDF5 组路径
            compression: 压缩算法 (gzip, lzf, none)
            start_time: 起始时间
            end_time: 结束时间
            
        Raises:
            ImportError: 未安装 h5py
            
        Example:
            >>> converter.to_hdf5("output.h5", group_path="/engine_test")
        """
        try:
            import h5py
        except ImportError:
            raise ImportError(
                "h5py is required for HDF5 export. "
                "Install with: pip install h5py"
            )
        
        mdf = self._get_mdf()
        
        # 获取通道列表
        if channels is None:
            channels = [
                ch for ch in mdf.channels_db.keys()
                if not ch.lower().startswith('time') or len(ch) > 10
            ]
        
        with h5py.File(output_path, 'w') as f:
            # 创建组
            grp = f.create_group(group_path.lstrip('/'))
            
            # 写入时间戳
            first_signal = mdf.get(channels[0], samples_only=False)
            timestamps = first_signal.timestamps
            
            if start_time is not None:
                start_idx = np.searchsorted(timestamps, start_time)
            else:
                start_idx = 0
            
            if end_time is not None:
                end_idx = np.searchsorted(timestamps, end_time)
            else:
                end_idx = len(timestamps)
            
            timestamps = timestamps[start_idx:end_idx]
            grp.create_dataset('timestamp', data=timestamps, compression=compression)
            
            # 写入各通道
            for channel_name in channels:
                try:
                    signal = mdf.get(channel_name, samples_only=False)
                    values = signal.samples[start_idx:end_idx]
                    
                    # 创建数据集
                    ds = grp.create_dataset(
                        channel_name,
                        data=values,
                        compression=compression
                    )
                    
                    # 添加元数据属性
                    ds.attrs['unit'] = str(signal.unit) if signal.unit else ''
                    ds.attrs['comment'] = str(signal.comment) if signal.comment else ''
                    
                except Exception as e:
                    warnings.warn(f"Failed to export channel {channel_name}: {e}")
        
        print(f"Exported {len(channels)} channels to {output_path}")
    
    def to_excel(
        self,
        output_path: str,
        channels: Optional[List[str]] = None,
        max_rows: int = 100000,
        start_time: Optional[float] = None,
        end_time: Optional[float] = None
    ) -> None:
        """
        转换为 Excel 文件
        
        适合小型数据集的可视化和分享。
        
        Args:
            output_path: 输出 Excel 文件路径
            channels: 要导出的通道列表
            max_rows: 最大导出行数（Excel 有限制）
            start_time: 起始时间
            end_time: 结束时间
            
        Raises:
            ImportError: 未安装 openpyxl 或 xlsxwriter
        """
        try:
            import pandas as pd
        except ImportError:
            raise ImportError(
                "pandas and openpyxl/xlsxwriter are required for Excel export. "
                "Install with: pip install pandas openpyxl"
            )
        
        # 使用 to_dataframe 获取数据
        reader = self._get_reader()
        df = reader.to_dataframe(channels, start_time, end_time)
        
        # 限制行数
        if len(df) > max_rows:
            df = df.head(max_rows)
            warnings.warn(f"Truncated to {max_rows} rows (Excel limit)")
        
        # 保存为 Excel
        df.to_excel(output_path, index=False, engine='openpyxl')
        
        print(f"Exported {len(df)} rows to {output_path}")
    
    def to_json(
        self,
        output_path: str,
        channels: Optional[List[str]] = None,
        orient: str = "records",
        start_time: Optional[float] = None,
        end_time: Optional[float] = None,
        max_rows: Optional[int] = None
    ) -> None:
        """
        转换为 JSON 文件
        
        适合 Web 应用和 API 数据交换。
        
        Args:
            output_path: 输出 JSON 文件路径
            channels: 要导出的通道列表
            orient: JSON 格式 (records, columns, values, index)
            start_time: 起始时间
            end_time: 结束时间
            max_rows: 最大导出行数
        """
        try:
            import pandas as pd
        except ImportError:
            raise ImportError(
                "pandas is required for JSON export. "
                "Install with: pip install pandas"
            )
        
        reader = self._get_reader()
        df = reader.to_dataframe(channels, start_time, end_time)
        
        if max_rows and len(df) > max_rows:
            df = df.head(max_rows)
        
        # 保存为 JSON
        df.to_json(output_path, orient=orient, indent=2)
        
        print(f"Exported {len(df)} rows to {output_path}")
    
    def get_info(self) -> Dict[str, Any]:
        """
        获取文件信息
        
        Returns:
            Dict: 包含文件版本、通道数量等信息的字典
        """
        mdf = self._get_mdf()
        
        info = {
            "file_path": self._file_path,
            "version": mdf.version,
            "channels_count": len(mdf.channels_db),
            "groups_count": len(mdf.groups),
        }
        
        return info
    
    def close(self) -> None:
        """关闭文件"""
        if self._mdf is not None:
            try:
                self._mdf.close()
            except Exception:
                pass
            self._mdf = None
        
        if self._reader is not None:
            try:
                self._reader.close()
            except Exception:
                pass
            self._reader = None
    
    def __enter__(self) -> 'Mf4Converter':
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()
    
    def __del__(self):
        self.close()
    
    def __repr__(self) -> str:
        return f"Mf4Converter(file_path='{self._file_path}')"