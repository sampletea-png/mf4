"""
MF4 文件读写 SDK

基于 asammdf 库实现的 MF4 文件读写功能。
支持大文件优化处理（分片存储、并行写入、异步写入）。

使用示例:
    # 标准读写
    from mf4 import Mf4Reader, Mf4Writer
    
    with Mf4Writer.create("output.mf4") as writer:
        writer.add_signal("Speed", timestamps, values, unit="rpm")
    
    with Mf4Reader.open("output.mf4") as reader:
        signal = reader.read_channel("Speed")
    
    # 大文件读写
    from mf4 import LargeFileWriter, LargeFileReader
    
    with LargeFileWriter.create("large.mf4") as writer:
        for batch in data_batches:
            writer.add_signals(batch["timestamps"], batch["signals"])
"""

__version__ = "1.0.0"
__author__ = "MF4 Development Team"

# 标准读写
from mf4.reader import Mf4Reader
from mf4.writer import Mf4Writer
from mf4.streaming_reader import Mf4StreamingReader
from mf4.converter import Mf4Converter

# 大文件读写
from mf4.large_file import (
    LargeFileWriter,
    LargeFileReader,
    LargeFileConfig,
    ShardIndex,
    FileIndex,
    create_large_writer,
    open_large_reader,
)

# 配置
from mf4.config import Mf4Config

# 统一存储接口
from mf4.storage import UnifiedWriter, UnifiedReader

# 枚举类型
from mf4.enums import DataType, ChannelType, ConversionType, CompressionType

# 数据模型
from mf4.model import (
    FileHeader,
    DataGroup,
    ChannelGroup,
    Channel,
    ChannelConversion,
    Signal,
    Attachment,
    Metadata
)

# 异常
from mf4.exceptions import (
    Mf4Error,
    Mf4FileNotFoundError,
    Mf4CorruptedFileError,
    Mf4UnsupportedVersionError,
    Mf4ChannelNotFoundError,
    Mf4ValidationError
)

__all__ = [
    # 标准读写
    "Mf4Reader",
    "Mf4Writer",
    "Mf4StreamingReader",
    "Mf4Converter",
    
    # 大文件读写
    "LargeFileWriter",
    "LargeFileReader",
    "LargeFileConfig",
    "ShardIndex",
    "FileIndex",
    "create_large_writer",
    "open_large_reader",
    
    # 配置
    "Mf4Config",
    
    # 统一存储接口
    "UnifiedWriter",
    "UnifiedReader",
    
    # 枚举
    "DataType",
    "ChannelType",
    "ConversionType",
    "CompressionType",
    
    # 数据模型
    "FileHeader",
    "DataGroup",
    "ChannelGroup",
    "Channel",
    "ChannelConversion",
    "Signal",
    "Attachment",
    "Metadata",
    
    # 异常
    "Mf4Error",
    "Mf4FileNotFoundError",
    "Mf4CorruptedFileError",
    "Mf4UnsupportedVersionError",
    "Mf4ChannelNotFoundError",
    "Mf4ValidationError",
]