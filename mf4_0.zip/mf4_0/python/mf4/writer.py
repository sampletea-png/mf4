"""
MF4 文件写入器

基于 asammdf 库实现的 MF4 文件写入功能。
提供完整的数据写入、通道定义、元数据设置等功能。

asammdf 写入流程:
1. 创建 MDF 对象（指定版本）
2. 添加信号（Signal 对象）
3. 保存文件

使用示例:
    # 基本写入
    with Mf4Writer.create("output.mf4") as writer:
        writer.set_header(author="Test", organization="MyOrg")
        
        # 添加数据
        import numpy as np
        timestamps = np.linspace(0, 10, 100)
        engine_speed = np.random.uniform(1000, 6000, 100)
        
        writer.add_signal("Engine_Speed", timestamps, engine_speed, unit="rpm")
    
    # 多通道写入
    with Mf4Writer.create("output.mf4") as writer:
        writer.set_header(project="Engine Test")
        
        timestamps = np.linspace(0, 100, 10000)
        signals = {
            "Engine_Speed": np.random.uniform(1000, 6000, 10000),
            "Vehicle_Speed": np.random.uniform(0, 180, 10000),
            "Throttle": np.random.uniform(0, 100, 10000),
        }
        writer.add_signals(timestamps, signals, units={"Engine_Speed": "rpm"})
"""

from typing import Optional, Dict, List, Any, Union
from datetime import datetime, timezone
from contextlib import contextmanager
import os
import warnings

# 第三方库
import numpy as np
from asammdf import MDF, Signal

# 本地模块
from mf4.config import Mf4Config
from mf4.model import (
    FileHeader, DataGroup, ChannelGroup, Channel,
    ChannelConversion, Signal as Mf4Signal, Attachment
)
from mf4.enums import DataType, ChannelType, ConversionType, CompressionType
from mf4.exceptions import (
    Mf4Error, Mf4ValidationError, Mf4WriteError
)


class Mf4Writer:
    """
    MF4 文件写入器
    
    提供完整的 MF4 文件写入功能，包括：
    - 文件头元数据设置
    - 通道组定义
    - 信号数据写入
    - 附件添加
    - 压缩支持
    
    Example:
        >>> with Mf4Writer.create("test.mf4", version="4.10") as writer:
        ...     # 设置文件信息
        ...     writer.set_header(
        ...         author="John Doe",
        ...         organization="ACME Corp",
        ...         project="Engine Testing",
        ...         comment="Test measurement"
        ...     )
        ...     
        ...     # 添加信号数据
        ...     timestamps = np.linspace(0, 10, 1000)
        ...     values = np.sin(timestamps)
        ...     writer.add_signal("Sine_Wave", timestamps, values, unit="V")
        
    Note:
        - 使用 context manager 确保资源正确释放
        - 大量数据建议分批添加
        - 支持 MF4 版本 4.00, 4.10, 4.11, 4.20
    """
    
    # 支持的 MF4 版本
    SUPPORTED_VERSIONS = ('4.00', '4.10', '4.11', '4.20')
    
    def __init__(
        self,
        file_path: str,
        version: str = "4.10",
        compression: bool = False,
        config: Optional[Mf4Config] = None
    ):
        """
        初始化写入器
        
        Args:
            file_path: 输出文件路径
            version: MF4 版本号，默认 4.10
            compression: 是否启用压缩，默认 False
            config: 配置实例，可选
            
        Example:
            >>> writer = Mf4Writer("output.mf4", version="4.11")
        """
        self._file_path = os.path.abspath(file_path)
        self._version = version
        self._compression = compression
        self._config = config or Mf4Config.default()
        
        # asammdf MDF 实例
        self._mdf: Optional[MDF] = None
        self._is_open = False
        
        # 文件头信息
        self._header: Optional[FileHeader] = None
        
        # 信号缓冲（用于批量写入）
        self._signals_buffer: List[Signal] = []
        
        # 附件列表
        self._attachments: List[Attachment] = []
        
        # 唯一ID计数器
        self._id_counter = 0
        
        # 通道信息（名称 -> 单位）
        self._channels_info: Dict[str, str] = {}
        
        # 追加模式标志
        self._is_append_mode = False
        
        # 验证版本
        if self._version not in self.SUPPORTED_VERSIONS:
            warnings.warn(
                f"Version {self._version} may not be fully supported. "
                f"Recommended versions: {self.SUPPORTED_VERSIONS}"
            )
    
    @classmethod
    @contextmanager
    def create(
        cls,
        file_path: str,
        version: str = "4.10",
        compression: bool = False,
        config: Optional[Mf4Config] = None
 ):
        """
        上下文管理器方式创建写入器（推荐方式）
        
        Args:
            file_path: 输出文件路径
            version: MF4 版本号
            compression: 是否启用压缩
            config: 配置实例
            
        Yields:
            Mf4Writer: 写入器实例
            
        Example:
            >>> with Mf4Writer.create("output.mf4") as writer:
            ...     writer.add_signal("Test", timestamps, values)
        """
        writer = cls(file_path, version, compression, config)
        try:
            writer._open()
            yield writer
        finally:
            writer.close()
    
    def _open(self) -> None:
        """
        打开/创建 MDF 文件
        
        创建一个新的 asammdf MDF 实例。
        注意：此时数据还在内存中，调用 save() 才会写入磁盘。
        
        Raises:
            Mf4WriteError: 创建失败
        """
        if self._is_open:
            return
        
        try:
            # 创建新的 MDF 实例
            # MDF() 创建空文件，指定版本
            self._mdf = MDF(version=self._version)
            self._is_open = True
            
        except Exception as e:
            raise Mf4WriteError(
                f"Failed to create MF4 file: {e}",
                file_path=self._file_path
            )
    
    def _next_id(self) -> int:
        """生成下一个唯一ID"""
        self._id_counter += 1
        return self._id_counter
    
    def set_header(self, **kwargs) -> None:
        """
        设置文件头信息
        
        可设置的字段：
        - author: 作者姓名
        - organization: 所属组织
        - project: 项目名称
        - subject: 测量主题
        - comment: 详细描述
        - start_time: 开始时间（datetime对象）
        - end_time: 结束时间（datetime对象）
        
        Args:
            **kwargs: 文件头字段
            
        Example:
            >>> writer.set_header(
            ...     author="John Doe",
            ...     organization="ACME Corp",
            ...     project="Engine Test",
            ...     comment="Measurement session"
            ... )
        """
        if self._header is None:
            self._header = FileHeader()
        
        # 更新字段
        for key, value in kwargs.items():
            if hasattr(self._header, key):
                setattr(self._header, key, value)
        
        # 如果 MDF 已打开，更新元数据
        if self._mdf is not None:
            self._apply_header_to_mdf()
    
    def _apply_header_to_mdf(self) -> None:
        """
        将文件头信息应用到 asammdf MDF 对象
        
        asammdf 使用属性存储元数据：
        - author
        - organization
        - project
        - subject
        - comment
        """
        if self._mdf is None or self._header is None:
            return
        
        # 设置作者
        if self._header.author:
            self._mdf.author = self._header.author
        
        # 设置组织
        if self._header.organization:
            self._mdf.organization = self._header.organization
        
        # 设置项目
        if self._header.project:
            self._mdf.project = self._header.project
        
        # 设置主题
        if self._header.subject:
            self._mdf.subject = self._header.subject
        
        # 设置注释
        if self._header.comment:
            self._mdf.comment = self._header.comment
    
    def add_channel_group(
        self,
        name: str,
        comment: str = ""
    ) -> int:
        """
        添加通道组
        
        在 MF4 中，通道组是一组共享相同时间轴的信号集合。
        注意：asammdf 不需要显式创建通道组，信号会自动分组。
        此方法主要用于内部管理。
        
        Args:
            name: 通道组名称
            comment: 描述注释
            
        Returns:
            int: 通道组ID
            
        Note:
            asammdf 会自动管理通道组，此方法主要用于兼容性。
        """
        cg_id = self._next_id()
        
        # 创建 ChannelGroup 记录（主要用于内部追踪）
        cg = ChannelGroup(
            id=cg_id,
            name=name,
            comment=comment
        )
        
        return cg_id
    
    def add_channel(
        self,
        cg_id: int,
        name: str,
        unit: str = "",
        data_type: DataType = DataType.FLOAT64,
        comment: str = "",
        channel_type: ChannelType = ChannelType.VALUE
    ) -> int:
        """
        添加通道定义
        
        此方法只定义通道元数据，不写入实际数据。
        通常建议使用 add_signal() 直接写入数据。
        
        Args:
            cg_id: 通道组ID
            name: 通道名称
            unit: 物理单位
            data_type: 数据类型
            comment: 描述注释
            channel_type: 通道类型
            
        Returns:
            int: 通道ID
        """
        ch_id = self._next_id()
        
        channel = Channel(
            id=ch_id,
            name=name,
            unit=unit,
            data_type=data_type,
            comment=comment,
            type=channel_type,
            channel_group_id=cg_id
        )
        
        return ch_id
    
    def add_signal(
        self,
        name: str,
        timestamps: np.ndarray,
        values: np.ndarray,
        unit: str = "",
        comment: str = "",
        master_name: str = "time"
    ) -> None:
        """
        添加单个信号
        
        使用 asammdf 的 append() 方法添加信号数据。
        每个信号包含时间戳和数值数组。
        
        Args:
            name: 信号名称（唯一标识）
            timestamps: 时间戳数组（单位：秒）
            values: 数值数组
            unit: 物理单位（如 rpm, km/h, V, A 等）
            comment: 信号描述
            master_name: 时间轴名称，默认 "time"
            
        Example:
            >>> import numpy as np
            >>> timestamps = np.linspace(0, 10, 100)
            >>> values = np.sin(timestamps)
            >>> writer.add_signal("Sine_Wave", timestamps, values, unit="V")
            
            >>> # 添加多通道
            >>> engine_speed = np.random.uniform(1000, 6000, 100)
            >>> writer.add_signal("Engine_Speed", timestamps, engine_speed, unit="rpm")
        """
        if self._mdf is None:
            self._open()
        
        # 数据验证
        if self._config.validate_on_write:
            errors = self._validate_signal(name, timestamps, values)
            if errors:
                raise Mf4ValidationError(
                    f"Signal validation failed: {name}",
                    validation_errors=errors,
                    file_path=self._file_path
                )
        
        try:
            # 创建 asammdf Signal 对象
            # Signal 构造函数参数：
            # - samples: 数值数组
            # - timestamps: 时间戳数组
            # - unit: 单位
            # - name: 信号名称
            # - comment: 注释
            signal = Signal(
                samples=values,
                timestamps=timestamps,
                unit=unit,
                name=name,
                comment=comment,
            )
            
            # 添加到 MDF 文件
            # append() 方法将信号写入下一个数据组
            self._mdf.append(signal, common_timebase=True)
            
        except Exception as e:
            raise Mf4WriteError(
                f"Failed to add signal '{name}': {e}",
                file_path=self._file_path
            )
    
    def add_signals(
        self,
        timestamps: np.ndarray,
        signals: Dict[str, np.ndarray],
        units: Optional[Dict[str, str]] = None,
        comments: Optional[Dict[str, str]] = None
    ) -> None:
        """
        批量添加多个信号
        
        一次性添加多个信号，它们共享相同的时间轴。
        这是高效写入大量数据的推荐方式。
        
        Args:
            timestamps: 共享的时间戳数组
            signals: 信号字典 {信号名: 数值数组}
            units: 单位字典（可选）
            comments: 注释字典（可选）
            
        Example:
            >>> timestamps = np.linspace(0, 100, 10000)
            >>> signals = {
            ...     "Engine_Speed": np.random.uniform(1000, 6000, 10000),
            ...     "Vehicle_Speed": np.random.uniform(0, 180, 10000),
            ...     "Throttle": np.random.uniform(0, 100, 10000),
            ... }
            >>> units = {"Engine_Speed": "rpm", "Vehicle_Speed": "km/h", "Throttle": "%"}
            >>> writer.add_signals(timestamps, signals, units)
        """
        units = units or {}
        comments = comments or {}
        
        for name, values in signals.items():
            unit = units.get(name, '')
            comment = comments.get(name, '')
            self.add_signal(name, timestamps, values, unit=unit, comment=comment)
    
    def write_data(
        self,
        channel_group_id: int,
        timestamps: np.ndarray,
        data: Dict[str, np.ndarray],
        units: Optional[Dict[str, str]] = None
    ) -> None:
        """
        写入数据到指定通道组
        
        这是 add_signals 的别名方法，提供与旧 API 的兼容性。
        
        Args:
            channel_group_id: 通道组ID（在 asammdf 中忽略，所有信号共享时间轴）
            timestamps: 时间戳数组
            data: 数据字典 {通道名: 数值数组}
            units: 单位字典（可选）
            
        Note:
            asammdf 不需要显式的通道组ID，所有信号自动共享时间轴。
            此方法主要用于 API 兼容性。
        """
        self.add_signals(timestamps, data, units=units)
    
    def add_attachment(
        self,
        filename: str,
        content: bytes,
        mime_type: str = "application/octet-stream",
        comment: str = ""
    ) -> int:
        """
        添加附件
        
        将外部文件嵌入到 MF4 文件中，如配置文件、图片等。
        
        Args:
            filename: 原始文件名
            content: 文件内容（字节）
            mime_type: MIME类型
            comment: 描述注释
            
        Returns:
            int: 附件ID
            
        Example:
            >>> with open("config.json", "rb") as f:
            ...     content = f.read()
            >>> writer.add_attachment("config.json", content, "application/json")
            
        Note:
            asammdf 的附件功能有限，大文件可能需要其他方式处理。
        """
        att_id = self._next_id()
        
        attachment = Attachment(
            id=att_id,
            filename=filename,
            content=content,
            mime_type=mime_type,
            comment=comment,
            create_time=datetime.now(timezone.utc)
        )
        
        self._attachments.append(attachment)
        
        # asammdf 添加附件的方式（如果支持）
        # 注意：不同版本的 asammdf 对附件的支持程度不同
        try:
            if hasattr(self._mdf, 'attachments'):
                self._mdf.attachments.append({
                    'filename': filename,
                    'data': content,
                    'mime_type': mime_type,
                    'comment': comment
                })
        except Exception:
            # 如果添加失败，附件仍保留在内存中
            warnings.warn(f"Could not add attachment: {filename}")
        
        return att_id
    
    def _validate_signal(
        self,
        name: str,
        timestamps: np.ndarray,
        values: np.ndarray
    ) -> List[str]:
        """
        验证信号数据
        
        检查项目：
        1. 名称非空
        2. 时间戳和数值长度一致
        3. 时间戳单调递增
        4. 数值类型有效
        
        Args:
            name: 信号名称
            timestamps: 时间戳数组
            values: 数值数组
            
        Returns:
            List[str]: 验证错误列表
        """
        errors = []
        
        # 检查名称
        if not name or not name.strip():
            errors.append("Signal name cannot be empty")
        
        # 检查数组长度
        if len(timestamps) != len(values):
            errors.append(
                f"Length mismatch: timestamps={len(timestamps)}, values={len(values)}"
            )
        
        # 检查时间戳单调性
        if len(timestamps) > 1:
            diffs = np.diff(timestamps)
            if np.any(diffs < 0):
                errors.append("Timestamps must be monotonically increasing")
        
        # 检查 NaN 值（仅在严格模式下）
        if self._config.strict_mode:
            if np.any(np.isnan(values)):
                errors.append("Values contain NaN")
        
        return errors
    
    def save(self) -> None:
        """
        保存文件
        
        将所有数据和元数据写入磁盘。
        如果使用 context manager，会在退出时自动调用。
        
        Raises:
            Mf4WriteError: 保存失败
            
        Example:
            >>> writer = Mf4Writer("output.mf4")
            >>> writer._open()
            >>> writer.add_signal("Test", timestamps, values)
            >>> writer.save()
            >>> writer.close()
        """
        if not self._is_open or self._mdf is None:
            raise Mf4WriteError("File not open", file_path=self._file_path)
        
        try:
            # 应用文件头
            self._apply_header_to_mdf()
            
            # 确保目录存在
            os.makedirs(os.path.dirname(self._file_path) or '.', exist_ok=True)
            
            # 在追加模式下，需要保存到临时文件然后替换原文件
            # 这是因为 asammdf 在追加模式下直接覆盖可能失败
            if getattr(self, '_is_append_mode', False):
                # 保存到临时文件（asammdf 会自动添加 .mf4 后缀）
                temp_base = self._file_path + '._temp_'
                saved_path = self._mdf.save(
                    temp_base,
                    overwrite=True,
                    compression=self._compression
                )
                
                # 关闭 MDF 以释放文件句柄
                self._mdf.close()
                
                # 替换原文件
                if os.path.exists(saved_path):
                    os.replace(saved_path, self._file_path)
            else:
                # 正常创建模式
                self._mdf.save(
                    self._file_path,
                    overwrite=True,
                    compression=self._compression
                )
            
        except Exception as e:
            raise Mf4WriteError(
                f"Failed to save MF4 file: {e}",
                file_path=self._file_path
            )
    
    def close(self) -> None:
        """
        关闭写入器
        
        如果有未保存的数据，会自动保存。
        释放所有资源。
        
        Example:
            >>> writer = Mf4Writer("output.mf4")
            >>> writer._open()
            >>> # ... 添加数据 ...
            >>> writer.close()  # 自动保存并关闭
        """
        if self._mdf is not None:
            try:
                # 保存数据
                self.save()
            except Exception as e:
                # 记录错误但不抛出
                import warnings
                warnings.warn(f"Error during save: {e}")
        
        try:
            # 关闭 MDF 对象，释放文件句柄
            if self._mdf is not None:
                self._mdf.close()
        except Exception:
            pass
        
        self._mdf = None
        self._is_open = False
    
    @classmethod
    @contextmanager
    def open_for_append(cls, file_path: str, config: Optional[Mf4Config] = None):
        """
        打开已存在的 MF4 文件进行追加
        
        允许向已存在的 MF4 文件添加新的信号数据。
        新数据将与现有数据合并，共享时间轴。
        
        Args:
            file_path: 已存在的 MF4 文件路径
            config: 配置实例（可选）
            
        Yields:
            Mf4Writer: 写入器实例
            
        Example:
            >>> # 首先创建文件
            >>> with Mf4Writer.create("data.mf4") as writer:
            ...     writer.add_signal("Speed", t1, v1, unit="rpm")
            
            >>> # 然后追加更多数据
            >>> with Mf4Writer.open_for_append("data.mf4") as writer:
            ...     writer.add_signal("Temperature", t2, v2, unit="C")
        """
        writer = cls.__new__(cls)
        writer._file_path = file_path
        writer._version = "4.10"
        writer._compression = False
        writer._config = config or Mf4Config.default()
        writer._mdf = None
        writer._is_open = False
        writer._header = None
        writer._signals_buffer = []
        writer._id_counter = 0
        writer._channels_info = {}
        writer._is_append_mode = True
        
        try:
            writer._open_for_append()
            yield writer
        finally:
            writer.close()
    
    def _open_for_append(self) -> None:
        """
        以追加模式打开文件
        
        使用 asammdf 的 MDF 打开已存在的文件，
        然后可以继续添加新的信号。
        """
        if self._is_open:
            return
        
        if not os.path.exists(self._file_path):
            raise Mf4WriteError(
                f"File does not exist: {self._file_path}",
                file_path=self._file_path
            )
        
        try:
            # 打开已存在的文件
            self._mdf = MDF(self._file_path)
            self._is_open = True
            
            # 获取文件的版本
            self._version = self._mdf.version
            
            # 获取现有通道信息
            for name in self._mdf.channels_db:
                if not name.lower().startswith('time'):
                    self._channels_info[name] = self._mdf.get_channel_unit(name)
                    
        except Exception as e:
            raise Mf4WriteError(
                f"Failed to open file for append: {e}",
                file_path=self._file_path
            )
    
    def append_signal(
        self,
        name: str,
        timestamps: np.ndarray,
        values: np.ndarray,
        unit: str = "",
        comment: str = ""
    ) -> None:
        """
        追加信号到已存在的文件
        
        功能与 add_signal 相同，语义上更明确表示追加操作。
        
        Args:
            name: 信号名称（必须唯一）
            timestamps: 时间戳数组
            values: 数值数组
            unit: 物理单位
            comment: 信号描述
            
        Raises:
            Mf4ValidationError: 数据验证失败
            Mf4WriteError: 写入失败
        """
        self.add_signal(name, timestamps, values, unit, comment)
    
    def get_existing_channels(self) -> List[str]:
        """
        获取已存在的通道列表
        
        Returns:
            List[str]: 已存在通道名称列表
        """
        if self._mdf is None:
            return []
        
        channels = []
        for name in self._mdf.channels_db:
            if not name.lower().startswith('time'):
                channels.append(name)
        
        return channels
    
    def channel_exists(self, name: str) -> bool:
        """
        检查通道是否已存在
        
        Args:
            name: 通道名称
            
        Returns:
            bool: 通道是否存在
        """
        return name in self._channels_info or name in self._mdf.channels_db if self._mdf else False
    
    def __enter__(self) -> 'Mf4Writer':
        """上下文管理器入口"""
        self._open()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """上下文管理器出口，自动保存并关闭"""
        if exc_type is None:
            try:
                self.save()
            except Exception:
                pass
        self.close()
    
    def __del__(self):
        """析构函数"""
        self.close()
    
    def __repr__(self) -> str:
        """返回对象表示"""
        status = "open" if self._is_open else "closed"
        signals = len(self._signals_buffer) if self._signals_buffer else 0
        return f"Mf4Writer(file_path='{self._file_path}', version='{self._version}', status='{status}')"
    
    def __str__(self) -> str:
        """返回简要描述"""
        return f"MF4 Writer: {os.path.basename(self._file_path)} (v{self._version})"