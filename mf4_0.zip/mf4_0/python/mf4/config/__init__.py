"""
配置管理模块

提供 MF4 SDK 的配置选项管理，包括：
- I/O 缓冲区大小
- 缓存策略和大小
- 性能调优参数
- 验证和日志配置

配置可以通过代码或环境变量进行设置。
"""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any
import os


@dataclass
class Mf4Config:
    """
    MF4 SDK 配置类
    
    管理 SDK 的各种配置选项，包括性能调优、缓存设置、验证选项等。
    
    Attributes:
        buffer_size: I/O 操作的缓冲区大小（记录数）
        use_memory_mapping: 是否使用内存映射提高大文件读取性能
        cache_enabled: 是否启用元数据缓存
        cache_size_mb: 缓存最大内存使用量（MB）
        max_workers: 并行处理的最大工作线程数
        prefetch_size: 预取数据的批次数
        validate_on_read: 读取时是否验证数据
        validate_on_write: 写入时是否验证数据
        strict_mode: 是否启用严格模式（更严格的验证）
        log_level: 日志级别
        log_file: 日志文件路径（可选）
    
    Example:
        >>> # 创建自定义配置
        >>> config = Mf4Config(
        ...     buffer_size=20000,
        ...     cache_size_mb=200,
        ...     validate_on_write=True
        ... )
        >>> 
        >>> # 使用配置
        >>> reader = Mf4Reader.open("file.mf4", config=config)
    
    Note:
        - 内存映射适用于大文件随机读取场景
        - 增大缓存可以提高重复读取性能，但会增加内存占用
        - 预取可以提高顺序读取性能，但会增加内存占用
    """
    
    # ==================== I/O 配置 ====================
    # I/O 操作的缓冲区大小（单位：记录数）
    # 较大的值可以提高读取性能，但会增加内存使用
    buffer_size: int = 10000
    
    # 是否使用内存映射（Memory Mapping）
    # 适用于大文件的随机访问，减少内存拷贝
    use_memory_mapping: bool = True
    
    # ==================== 缓存配置 ====================
    # 是否启用元数据缓存
    # 缓存可以加速重复访问，但会增加内存占用
    cache_enabled: bool = True
    
    # 缓存最大内存使用量（单位：MB）
    # 建议根据可用内存调整，过小会频繁淘汰，过大可能影响系统
    cache_size_mb: int = 100
    
    # 缓存淘汰策略：LRU（最近最少使用）或 LFU（最不经常使用）
    cache_strategy: str = "lru"
    
    # ==================== 性能配置 ====================
    # 并行处理的最大工作线程数
    # 设为 0 表示自动检测（通常为 CPU 核心数）
    max_workers: int = 0
    
    # 数据预取的批次数
    # 预取可以减少 I/O 等待时间，但会增加内存占用
    prefetch_size: int = 3
    
    # 批量写入的大小（单位：记录数）
    # 较大的值可以提高写入性能，但会增加内存占用
    batch_write_size: int = 50000
    
    # ==================== 验证配置 ====================
    # 读取时是否验证数据完整性
    # 启用会降低读取速度，但可以发现数据问题
    validate_on_read: bool = False
    
    # 写入时是否验证数据
    # 建议在生产环境启用，确保数据质量
    validate_on_write: bool = True
    
    # 是否启用严格模式
    # 严格模式下会进行更严格的数据验证
    strict_mode: bool = False
    
    # ==================== 日志配置 ====================
    # 日志级别：DEBUG, INFO, WARNING, ERROR, CRITICAL
    log_level: str = "INFO"
    
    # 日志文件路径（可选）
    # 如果不设置，日志将输出到控制台
    log_file: Optional[str] = None
    
    # ==================== 兼容性配置 ====================
    # 是否容忍非标准格式
    # 某些工具生成的文件可能不完全符合规范
    tolerant_mode: bool = True
    
    # 允许的最大文件大小（单位：GB）
    # 用于防止意外读取超大文件导致内存溢出
    max_file_size_gb: float = 50.0
    
    # ==================== 存储配置 ====================
    # storage_mode: 'single' 单文件 / 'sharded' 分片存储
    # 当选择 'sharded' 时，使用 LargeFileWriter/Reader 进行分片存储
    # 当选择 'single' 时，使用 Mf4Writer/Reader 进行单文件存储
    storage_mode: str = "single"
    
    # ==================== 其他配置 ====================
    # 文件句柄保持打开的超时时间（单位：秒）
    # 用于流式处理场景，超时后自动关闭
    file_handle_timeout: int = 300
    
    # 自定义配置项（用于扩展）
    custom: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        """
        初始化后验证配置项
        
        确保所有配置项都在有效范围内。
        """
        self._validate()
    
    def _validate(self) -> None:
        """
        验证配置项
        
        Raises:
            ValueError: 如果配置项值无效
        """
        # 验证缓冲区大小
        if self.buffer_size < 100:
            raise ValueError(f"buffer_size must be >= 100, got {self.buffer_size}")
        if self.buffer_size > 1000000:
            raise ValueError(f"buffer_size must be <= 1000000, got {self.buffer_size}")
        
        # 验证缓存大小
        if self.cache_size_mb < 10:
            raise ValueError(f"cache_size_mb must be >= 10, got {self.cache_size_mb}")
        if self.cache_size_mb > 1000:
            raise ValueError(f"cache_size_mb must be <= 1000, got {self.cache_size_mb}")
        
        # 验证缓存策略
        if self.cache_strategy not in ("lru", "lfu"):
            raise ValueError(f"cache_strategy must be 'lru' or 'lfu', got {self.cache_strategy}")
        
        # 验证日志级别
        valid_log_levels = ("DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL")
        if self.log_level not in valid_log_levels:
            raise ValueError(f"log_level must be one of {valid_log_levels}, got {self.log_level}")
        
        # 验证文件大小限制
        if self.max_file_size_gb <= 0:
            raise ValueError(f"max_file_size_gb must be > 0, got {self.max_file_size_gb}")
        
        if self.storage_mode not in ("single", "sharded"):
            raise ValueError(
                f"storage_mode must be 'single' or 'sharded', got '{self.storage_mode}'"
            )
    
    @classmethod
    def from_env(cls) -> 'Mf4Config':
        """
        从环境变量创建配置
        
        环境变量名称格式：MF4_<配置项名>
        例如：MF4_BUFFER_SIZE=20000
        
        Returns:
            从环境变量创建的 Mf4Config 实例
            
        Example:
            >>> # 设置环境变量
            >>> import os
            >>> os.environ["MF4_BUFFER_SIZE"] = "20000"
            >>> os.environ["MF4_CACHE_SIZE_MB"] = "200"
            >>> 
            >>> # 从环境变量创建配置
            >>> config = Mf4Config.from_env()
            >>> print(config.buffer_size)  # 20000
        """
        config_dict: Dict[str, Any] = {}
        
        # 映射环境变量名到配置项
        env_mapping = {
            "MF4_BUFFER_SIZE": ("buffer_size", int),
            "MF4_USE_MEMORY_MAPPING": ("use_memory_mapping", lambda x: x.lower() == "true"),
            "MF4_CACHE_ENABLED": ("cache_enabled", lambda x: x.lower() == "true"),
            "MF4_CACHE_SIZE_MB": ("cache_size_mb", int),
            "MF4_CACHE_STRATEGY": ("cache_strategy", str),
            "MF4_MAX_WORKERS": ("max_workers", int),
            "MF4_PREFETCH_SIZE": ("prefetch_size", int),
            "MF4_BATCH_WRITE_SIZE": ("batch_write_size", int),
            "MF4_VALIDATE_ON_READ": ("validate_on_read", lambda x: x.lower() == "true"),
            "MF4_VALIDATE_ON_WRITE": ("validate_on_write", lambda x: x.lower() == "true"),
            "MF4_STRICT_MODE": ("strict_mode", lambda x: x.lower() == "true"),
            "MF4_LOG_LEVEL": ("log_level", str),
            "MF4_LOG_FILE": ("log_file", str),
            "MF4_TOLERANT_MODE": ("tolerant_mode", lambda x: x.lower() == "true"),
            "MF4_MAX_FILE_SIZE_GB": ("max_file_size_gb", float),
        }
        
        for env_name, (config_key, converter) in env_mapping.items():
            env_value = os.environ.get(env_name)
            if env_value is not None:
                try:
                    config_dict[config_key] = converter(env_value)
                except (ValueError, TypeError) as e:
                    raise ValueError(f"Invalid environment variable {env_name}={env_value}: {e}")
        
        return cls(**config_dict)
    
    @classmethod
    def default(cls) -> 'Mf4Config':
        """
        创建默认配置
        
        Returns:
            使用默认值的 Mf4Config 实例
            
        Example:
            >>> config = Mf4Config.default()
            >>> print(config.buffer_size)  # 10000
        """
        return cls()
    
    @classmethod
    def high_performance(cls) -> 'Mf4Config':
        """
        创建高性能配置
        
        适用于需要最大性能的场景，会增加内存使用。
        
        Returns:
            高性能配置的 Mf4Config 实例
            
        Example:
            >>> config = Mf4Config.high_performance()
            >>> print(config.buffer_size)  # 50000
        """
        return cls(
            buffer_size=50000,
            use_memory_mapping=True,
            cache_enabled=True,
            cache_size_mb=500,
            max_workers=8,
            prefetch_size=10,
            batch_write_size=100000,
            validate_on_read=False,
            validate_on_write=False,
        )
    
    @classmethod
    def low_memory(cls) -> 'Mf4Config':
        """
        创建低内存配置
        
        适用于内存受限的场景，会牺牲部分性能。
        
        Returns:
            低内存配置的 Mf4Config 实例
            
        Example:
            >>> config = Mf4Config.low_memory()
            >>> print(config.cache_size_mb)  # 20
        """
        return cls(
            buffer_size=1000,
            use_memory_mapping=False,
            cache_enabled=True,
            cache_size_mb=20,
            max_workers=1,
            prefetch_size=1,
            batch_write_size=5000,
            validate_on_read=False,
            validate_on_write=True,
        )
    
    def merge(self, **kwargs) -> 'Mf4Config':
        """
        合并配置项创建新配置
        
        创建一个新配置，用指定的值覆盖当前配置。
        
        Args:
            **kwargs: 要覆盖的配置项
            
        Returns:
            合并后的新 Mf4Config 实例
            
        Example:
            >>> base_config = Mf4Config.default()
            >>> new_config = base_config.merge(buffer_size=20000, cache_size_mb=200)
            >>> print(new_config.buffer_size)  # 20000
        """
        current = {
            "buffer_size": self.buffer_size,
            "use_memory_mapping": self.use_memory_mapping,
            "cache_enabled": self.cache_enabled,
            "cache_size_mb": self.cache_size_mb,
            "cache_strategy": self.cache_strategy,
            "max_workers": self.max_workers,
            "prefetch_size": self.prefetch_size,
            "batch_write_size": self.batch_write_size,
            "validate_on_read": self.validate_on_read,
            "validate_on_write": self.validate_on_write,
            "strict_mode": self.strict_mode,
            "log_level": self.log_level,
            "log_file": self.log_file,
            "tolerant_mode": self.tolerant_mode,
            "max_file_size_gb": self.max_file_size_gb,
            "file_handle_timeout": self.file_handle_timeout,
            "storage_mode": self.storage_mode,
            "custom": self.custom.copy(),
        }
        
        current.update(kwargs)
        
        return Mf4Config(**current)
    
    def to_dict(self) -> Dict[str, Any]:
        """
        将配置转换为字典
        
        Returns:
            包含所有配置项的字典
            
        Example:
            >>> config = Mf4Config.default()
            >>> config_dict = config.to_dict()
            >>> print(config_dict["buffer_size"])  # 10000
        """
        return {
            "buffer_size": self.buffer_size,
            "use_memory_mapping": self.use_memory_mapping,
            "cache_enabled": self.cache_enabled,
            "cache_size_mb": self.cache_size_mb,
            "cache_strategy": self.cache_strategy,
            "max_workers": self.max_workers,
            "prefetch_size": self.prefetch_size,
            "batch_write_size": self.batch_write_size,
            "validate_on_read": self.validate_on_read,
            "validate_on_write": self.validate_on_write,
            "strict_mode": self.strict_mode,
            "log_level": self.log_level,
            "log_file": self.log_file,
            "tolerant_mode": self.tolerant_mode,
            "max_file_size_gb": self.max_file_size_gb,
            "file_handle_timeout": self.file_handle_timeout,
            "storage_mode": self.storage_mode,
            "custom": self.custom.copy(),
        }