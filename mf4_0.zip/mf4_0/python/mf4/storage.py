"""
统一存储接口

通过配置项 storage_mode 控制使用单文件存储还是分片存储：
- 'single': 使用 Mf4Writer/Mf4Reader 进行单文件读写
- 'sharded': 使用 LargeFileWriter/LargeFileReader 进行分片读写

使用示例:
    from mf4.storage import UnifiedWriter, UnifiedReader
    
    # 单文件模式
    config = Mf4Config(storage_mode="single")
    with UnifiedWriter.create("output.mf4", config=config) as writer:
        writer.add_signal("Speed", timestamps, values, unit="rpm")
    
    # 分片模式
    config = Mf4Config(storage_mode="sharded")
    with UnifiedWriter.create("output.mf4", config=config) as writer:
        writer.add_signal("Speed", timestamps, values, unit="rpm")
    
    # 读取时自动检测存储模式
    with UnifiedReader.open("output.mf4", config=config) as reader:
        signal = reader.read_channel("Speed")
"""

import os
from typing import Optional, Dict, List
from contextlib import contextmanager

import numpy as np

from mf4.config import Mf4Config
from mf4.writer import Mf4Writer
from mf4.reader import Mf4Reader
from mf4.large_file import (
    LargeFileWriter,
    LargeFileReader,
    LargeFileConfig,
)
from mf4.model import Signal
from mf4.exceptions import Mf4Error


def _mf4_config_to_large_config(mf4_config: Mf4Config) -> LargeFileConfig:
    return LargeFileConfig(
        parallel_workers=mf4_config.max_workers or 0,
        enable_async=mf4_config.max_workers != 1,
        buffer_size_mb=mf4_config.cache_size_mb,
        chunk_size=mf4_config.batch_write_size,
    )


class UnifiedWriter:
    """
    统一写入接口
    
    根据 storage_mode 配置自动选择底层存储方式：
    - 'single': 单文件模式 (Mf4Writer)
    - 'sharded': 分片模式 (LargeFileWriter)
    
    两种模式提供统一的 add_signal / add_signals / set_header 接口。
    """
    
    def __init__(self, file_path: str, config: Optional[Mf4Config] = None):
        self._file_path = file_path
        self._config = config or Mf4Config()
        self._mode = self._config.storage_mode
        self._writer = None
    
    @classmethod
    @contextmanager
    def create(cls, file_path: str, config: Optional[Mf4Config] = None):
        instance = cls(file_path, config)
        try:
            instance._open()
            yield instance
        finally:
            instance.close()
    
    def _open(self):
        if self._mode == "sharded":
            base_path = os.path.splitext(self._file_path)[0]
            large_config = _mf4_config_to_large_config(self._config)
            self._writer = LargeFileWriter(base_path, large_config)
            self._writer._open()
        else:
            self._writer = Mf4Writer(
                self._file_path,
                config=self._config,
            )
            self._writer._open()
    
    def set_header(self, **kwargs):
        self._writer.set_header(**kwargs)
    
    def add_signal(
        self,
        name: str,
        timestamps: np.ndarray,
        values: np.ndarray,
        unit: str = "",
        comment: str = "",
    ):
        if self._mode == "sharded":
            self._writer.add_signal(name, timestamps, values, unit, comment)
        else:
            self._writer.add_signal(name, timestamps, values, unit, comment)
    
    def add_signals(
        self,
        timestamps: np.ndarray,
        signals: Dict[str, np.ndarray],
        units: Optional[Dict[str, str]] = None,
        comments: Optional[Dict[str, str]] = None,
    ):
        if self._mode == "sharded":
            self._writer.add_signals(timestamps, signals, units, comments)
        else:
            self._writer.add_signals(timestamps, signals, units, comments)
    
    def add_channel_group(self, name: str, comment: str = "") -> int:
        if self._mode == "sharded":
            return 0
        return self._writer.add_channel_group(name, comment)
    
    def add_channel(self, cg_id: int, name: str, unit: str = "", comment: str = "") -> int:
        if self._mode == "sharded":
            return 0
        return self._writer.add_channel(cg_id, name, unit=unit, comment=comment)
    
    def write_data(
        self,
        channel_group_id: int,
        timestamps: np.ndarray,
        data: Dict[str, np.ndarray],
        units: Optional[Dict[str, str]] = None,
    ):
        if self._mode == "sharded":
            self._writer.add_signals(timestamps, data, units)
        else:
            self._writer.write_data(channel_group_id, timestamps, data, units)
    
    @property
    def storage_mode(self) -> str:
        return self._mode
    
    @property
    def underlying_writer(self):
        return self._writer
    
    def close(self):
        if self._writer is not None:
            if self._mode == "sharded":
                self._writer.close()
            else:
                self._writer.close()
            self._writer = None
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


class UnifiedReader:
    """
    统一读取接口
    
    根据 storage_mode 配置自动选择底层读取方式：
    - 'single': 单文件模式 (Mf4Reader)
    - 'sharded': 分片模式 (LargeFileReader)
    
    两种模式提供统一的 read_channel / get_channels / get_info 接口。
    """
    
    def __init__(self, file_path: str, config: Optional[Mf4Config] = None):
        self._file_path = file_path
        self._config = config or Mf4Config()
        self._mode = self._config.storage_mode
        self._reader = None
    
    @classmethod
    @contextmanager
    def open(cls, file_path: str, config: Optional[Mf4Config] = None):
        instance = cls(file_path, config)
        try:
            instance._open()
            yield instance
        finally:
            instance.close()
    
    def _open(self):
        if self._mode == "sharded":
            base_path = os.path.splitext(self._file_path)[0]
            large_config = _mf4_config_to_large_config(self._config)
            self._reader = LargeFileReader(base_path, large_config)
            self._reader._open()
        else:
            self._reader = Mf4Reader(self._file_path, self._config)
            self._reader._open()
    
    def get_channels(self):
        if self._mode == "sharded":
            return self._reader.channels
        return self._reader.get_channels()
    
    def read_channel(
        self,
        name: str,
        start_time: Optional[float] = None,
        end_time: Optional[float] = None,
    ):
        if self._mode == "sharded":
            if start_time is not None and end_time is not None:
                data = self._reader.read_time_range(start_time, end_time, [name])
                if name in data and len(data[name]) > 0:
                    return Signal(
                        name=name,
                        timestamps=data['timestamps'],
                        values=data[name],
                        unit='',
                    )
                return None
            
            all_data = None
            for shard_data in self._reader.iter_shards():
                if name in shard_data:
                    if all_data is None:
                        all_data = {
                            'timestamps': [shard_data['timestamps']],
                            name: [shard_data[name]],
                        }
                    else:
                        all_data['timestamps'].append(shard_data['timestamps'])
                        all_data[name].append(shard_data[name])
            
            if all_data is None:
                return None
            
            timestamps = np.concatenate(all_data['timestamps'])
            values = np.concatenate(all_data[name])
            return Signal(
                name=name,
                timestamps=timestamps,
                values=values,
                unit='',
            )
        return self._reader.read_channel(name, start_time, end_time)
    
    def read_channels(
        self,
        names: List[str],
        start_time: Optional[float] = None,
        end_time: Optional[float] = None,
    ):
        result = {}
        for name in names:
            signal = self.read_channel(name, start_time, end_time)
            if signal is not None:
                result[name] = signal
        return result
    
    def get_info(self) -> dict:
        if self._mode == "sharded":
            return self._reader.get_info()
        channels = self._reader.get_channels()
        return {
            "file_path": self._file_path,
            "channels": [ch.name for ch in channels],
            "storage_mode": "single",
        }
    
    @property
    def storage_mode(self) -> str:
        return self._mode
    
    @property
    def underlying_reader(self):
        return self._reader
    
    @property
    def header(self):
        if self._mode == "sharded":
            return None
        return self._reader.header
    
    def close(self):
        if self._reader is not None:
            self._reader.close()
            self._reader = None
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
