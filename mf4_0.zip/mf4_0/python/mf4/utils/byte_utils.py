"""
字节处理工具模块

提供 MF4 文件二进制数据的读写和转换功能。
MF4 文件使用小端字节序（Little-Endian）存储数据。
"""

import struct
from typing import Tuple, Any, BinaryIO, Optional
from datetime import datetime, timezone


# MF4 文件使用小端字节序
BYTE_ORDER = '<'


def read_bytes(handle: BinaryIO, size: int) -> bytes:
    """
    从文件句柄读取指定大小的字节
    
    Args:
        handle: 文件句柄
        size: 要读取的字节数
        
    Returns:
        读取的字节数据
        
    Raises:
        EOFError: 如果到达文件末尾但未读取到足够的数据
        
    Example:
        >>> with open('file.mf4', 'rb') as f:
        ...     data = read_bytes(f, 64)
    """
    data = handle.read(size)
    if len(data) < size:
        raise EOFError(f"Expected {size} bytes, got {len(data)}")
    return data


def read_uint8(handle: BinaryIO) -> int:
    """读取无符号8位整数"""
    return struct.unpack(f'{BYTE_ORDER}B', read_bytes(handle, 1))[0]


def read_uint16(handle: BinaryIO) -> int:
    """读取无符号16位整数"""
    return struct.unpack(f'{BYTE_ORDER}H', read_bytes(handle, 2))[0]


def read_uint32(handle: BinaryIO) -> int:
    """读取无符号32位整数"""
    return struct.unpack(f'{BYTE_ORDER}I', read_bytes(handle, 4))[0]


def read_uint64(handle: BinaryIO) -> int:
    """读取无符号64位整数"""
    return struct.unpack(f'{BYTE_ORDER}Q', read_bytes(handle, 8))[0]


def read_int8(handle: BinaryIO) -> int:
    """读取有符号8位整数"""
    return struct.unpack(f'{BYTE_ORDER}b', read_bytes(handle, 1))[0]


def read_int16(handle: BinaryIO) -> int:
    """读取有符号16位整数"""
    return struct.unpack(f'{BYTE_ORDER}h', read_bytes(handle, 2))[0]


def read_int32(handle: BinaryIO) -> int:
    """读取有符号32位整数"""
    return struct.unpack(f'{BYTE_ORDER}i', read_bytes(handle, 4))[0]


def read_int64(handle: BinaryIO) -> int:
    """读取有符号64位整数"""
    return struct.unpack(f'{BYTE_ORDER}q', read_bytes(handle, 8))[0]


def read_float32(handle: BinaryIO) -> float:
    """读取32位单精度浮点数"""
    return struct.unpack(f'{BYTE_ORDER}f', read_bytes(handle, 4))[0]


def read_float64(handle: BinaryIO) -> float:
    """读取64位双精度浮点数"""
    return struct.unpack(f'{BYTE_ORDER}d', read_bytes(handle, 8))[0]


def read_string(handle: BinaryIO, length: int, encoding: str = 'utf-8') -> str:
    """
    读取固定长度的字符串
    
    MF4 文件中的字符串通常是固定长度的，以空字节填充。
    此函数会自动去除末尾的空字节。
    
    Args:
        handle: 文件句柄
        length: 字符串长度（字节数）
        encoding: 字符编码，默认为 'utf-8'
        
    Returns:
        解码后的字符串（已去除填充的空字节）
        
    Example:
        >>> with open('file.mf4', 'rb') as f:
        ...     version = read_string(f, 8)  # 读取8字节版本号
        >>> print(version)  # "4.10"
    """
    data = read_bytes(handle, length)
    # 去除末尾的空字节
    return data.rstrip(b'\x00').decode(encoding)


def write_bytes(handle: BinaryIO, data: bytes) -> None:
    """
    写入字节数据到文件
    
    Args:
        handle: 文件句柄
        data: 要写入的字节数据
    """
    handle.write(data)


def write_uint8(handle: BinaryIO, value: int) -> None:
    """写入无符号8位整数"""
    handle.write(struct.pack(f'{BYTE_ORDER}B', value))


def write_uint16(handle: BinaryIO, value: int) -> None:
    """写入无符号16位整数"""
    handle.write(struct.pack(f'{BYTE_ORDER}H', value))


def write_uint32(handle: BinaryIO, value: int) -> None:
    """写入无符号32位整数"""
    handle.write(struct.pack(f'{BYTE_ORDER}I', value))


def write_uint64(handle: BinaryIO, value: int) -> None:
    """写入无符号64位整数"""
    handle.write(struct.pack(f'{BYTE_ORDER}Q', value))


def write_int8(handle: BinaryIO, value: int) -> None:
    """写入有符号8位整数"""
    handle.write(struct.pack(f'{BYTE_ORDER}b', value))


def write_int16(handle: BinaryIO, value: int) -> None:
    """写入有符号16位整数"""
    handle.write(struct.pack(f'{BYTE_ORDER}h', value))


def write_int32(handle: BinaryIO, value: int) -> None:
    """写入有符号32位整数"""
    handle.write(struct.pack(f'{BYTE_ORDER}i', value))


def write_int64(handle: BinaryIO, value: int) -> None:
    """写入有符号64位整数"""
    handle.write(struct.pack(f'{BYTE_ORDER}q', value))


def write_float32(handle: BinaryIO, value: float) -> None:
    """写入32位单精度浮点数"""
    handle.write(struct.pack(f'{BYTE_ORDER}f', value))


def write_float64(handle: BinaryIO, value: float) -> None:
    """写入64位双精度浮点数"""
    handle.write(struct.pack(f'{BYTE_ORDER}d', value))


def write_string(handle: BinaryIO, value: str, length: int, encoding: str = 'utf-8') -> None:
    """
    写入固定长度的字符串
    
    字符串会被填充到指定长度，以空字节填充。
    
    Args:
        handle: 文件句柄
        value: 要写入的字符串
        length: 目标长度（字节数）
        encoding: 字符编码，默认为 'utf-8'
        
    Raises:
        ValueError: 如果字符串编码后超过指定长度
    """
    encoded = value.encode(encoding)
    if len(encoded) > length:
        raise ValueError(f"String too long: {len(encoded)} > {length}")
    # 填充空字节到指定长度
    padded = encoded.ljust(length, b'\x00')
    handle.write(padded)


def mdf_timestamp_to_datetime(timestamp_ns: int) -> datetime:
    """
    将 MDF 时间戳转换为 Python datetime
    
    MDF 时间戳是从 1970-01-01 00:00:00 UTC 开始的纳秒数。
    
    Args:
        timestamp_ns: MDF 时间戳（纳秒）
        
    Returns:
        对应的 datetime 对象（UTC时区）
        
    Example:
        >>> dt = mdf_timestamp_to_datetime(1609459200000000000)
        >>> print(dt)  # 2021-01-01 00:00:00+00:00
    """
    seconds = timestamp_ns / 1_000_000_000
    return datetime.fromtimestamp(seconds, tz=timezone.utc)


def datetime_to_mdf_timestamp(dt: datetime) -> int:
    """
    将 Python datetime 转换为 MDF 时间戳
    
    Args:
        dt: datetime 对象
        
    Returns:
        MDF 时间戳（纳秒）
        
    Example:
        >>> from datetime import datetime, timezone
        >>> dt = datetime(2021, 1, 1, tzinfo=timezone.utc)
        >>> ts = datetime_to_mdf_timestamp(dt)
    """
    # 确保 UTC 时区
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    
    return int(dt.timestamp() * 1_000_000_000)


def get_bit_value(data: bytes, byte_offset: int, bit_offset: int, bit_count: int) -> int:
    """
    从字节数据中提取特定位范围的数据
    
    用于处理 MF4 文件中的位域数据，比如一个字节中存储多个小数值。
    
    Args:
        data: 原始字节数据
        byte_offset: 字节偏移量
        bit_offset: 位偏移量（0-7，从最低位开始）
        bit_count: 要提取的位数
        
    Returns:
        提取的整数值
        
    Example:
        >>> data = bytes([0b10110100])  # 180
        >>> # 提取低3位: 100 = 4
        >>> value = get_bit_value(data, 0, 0, 3)
        >>> print(value)  # 4
    """
    start_byte = byte_offset
    end_byte = byte_offset + (bit_offset + bit_count + 7) // 8
    
    # 提取相关字节
    value_bytes = data[start_byte:end_byte]
    
    # 转换为整数（小端）
    value = int.from_bytes(value_bytes, 'little')
    
    # 移位和掩码操作
    value = (value >> bit_offset) & ((1 << bit_count) - 1)
    
    return value