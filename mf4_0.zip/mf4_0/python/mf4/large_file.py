"""
大文件处理优化模块

提供针对大型 MF4 文件的高性能读写策略：
1. 分片存储：将大文件拆分为多个小文件（每文件 <= 1GB）
2. 并行写入：多线程并行处理数据块
3. 异步写入：后台线程写入，主线程不阻塞
4. 索引机制：快速定位和读取数据
5. 内存映射：高效读取已写入数据

性能目标：
- 写入耗时 < 3秒（1GB 数据）
- 内存峰值 < 500MB
- 支持增量写入

使用示例:
    from mf4.large_file import LargeFileWriter, LargeFileReader
    
    # 创建大文件写入器
    with LargeFileWriter.create(
        "large_measurement.mf4",
        max_shard_size_mb=1024,  # 每个分片最大 1GB
        parallel_workers=4,      # 4个并行工作线程
        enable_async=True        # 启用异步写入
    ) as writer:
        # 批量添加数据
        for batch in data_batches:
            writer.add_signals_batch(batch)
    
    # 读取大文件
    with LargeFileReader.open("large_measurement.mf4") as reader:
        # 流式读取
        for shard_data in reader.read_shards():
            process(shard_data)
"""

import os
import re
import json
import threading
import multiprocessing as mp
from typing import Optional, List, Dict, Any, Iterator, Callable
from dataclasses import dataclass, field
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
from contextlib import contextmanager
import queue
import time
import warnings

import numpy as np
from asammdf import MDF, Signal

from mf4.config import Mf4Config
from mf4.model import Signal as Mf4Signal
from mf4.exceptions import Mf4Error, Mf4WriteError


# ==================== 配置 ====================

@dataclass
class LargeFileConfig:
    """
    大文件处理配置
    
    Attributes:
        max_shard_size_mb: 单个分片最大大小（MB），默认 1024MB (1GB)
        parallel_workers: 并行工作线程数，默认自动检测
        enable_async: 是否启用异步写入
        buffer_size_mb: 写入缓冲区大小（MB）
        compression: 是否启用压缩
        index_enabled: 是否创建索引
        chunk_size: 数据分块大小（记录数）
        timeout_seconds: 操作超时时间（秒）
        storage_mode: 存储模式，'single' 单文件 / 'sharded' 分片存储
    """
    
    max_shard_size_mb: int = 1024
    parallel_workers: int = 0
    enable_async: bool = True
    buffer_size_mb: int = 100
    compression: bool = False
    index_enabled: bool = True
    chunk_size: int = 50000
    timeout_seconds: int = 30
    max_memory_mb: int = 500
    storage_mode: str = "sharded"
    
    def __post_init__(self):
        if self.parallel_workers == 0:
            self.parallel_workers = min(mp.cpu_count(), 8)
        if self.storage_mode not in ("single", "sharded"):
            raise ValueError(
                f"storage_mode must be 'single' or 'sharded', got '{self.storage_mode}'"
            )
    
    @classmethod
    def high_performance(cls) -> 'LargeFileConfig':
        return cls(
            max_shard_size_mb=2048,
            parallel_workers=min(mp.cpu_count(), 16),
            enable_async=True,
            buffer_size_mb=200,
            chunk_size=100000,
        )
    
    @classmethod
    def low_memory(cls) -> 'LargeFileConfig':
        return cls(
            max_shard_size_mb=512,
            parallel_workers=2,
            enable_async=False,
            buffer_size_mb=50,
            chunk_size=20000,
            max_memory_mb=200,
        )


# ==================== 分片索引 ====================

@dataclass
class ShardIndex:
    """
    分片索引
    
    记录每个分片的元数据，用于快速定位数据。
    """
    
    shard_id: int
    file_path: str
    start_time: float
    end_time: float
    record_count: int
    file_size: int
    channels: List[str] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    
    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "shard_id": self.shard_id,
            "file_path": self.file_path,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "record_count": self.record_count,
            "file_size": self.file_size,
            "channels": self.channels,
            "created_at": self.created_at,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'ShardIndex':
        """从字典创建"""
        return cls(**data)


@dataclass
class FileIndex:
    """
    文件索引
    
    管理所有分片的索引信息。
    """
    
    base_path: str
    shards: List[ShardIndex] = field(default_factory=list)
    total_records: int = 0
    total_size: int = 0
    all_channels: List[str] = field(default_factory=list)
    
    def add_shard(self, shard: ShardIndex):
        """添加分片索引"""
        self.shards.append(shard)
        self.total_records += shard.record_count
        self.total_size += shard.file_size
        # 更新通道列表
        for ch in shard.channels:
            if ch not in self.all_channels:
                self.all_channels.append(ch)
    
    def find_shard(self, timestamp: float) -> Optional[ShardIndex]:
        """根据时间戳查找分片"""
        for shard in self.shards:
            if shard.start_time <= timestamp <= shard.end_time:
                return shard
        return None
    
    def find_shards_in_range(
        self, 
        start_time: float, 
        end_time: float
    ) -> List[ShardIndex]:
        """查找时间范围内的所有分片"""
        result = []
        for shard in self.shards:
            if shard.end_time >= start_time and shard.start_time <= end_time:
                result.append(shard)
        return result
    
    def save(self, path: str):
        """保存索引到文件"""
        data = {
            "base_path": self.base_path,
            "shards": [s.to_dict() for s in self.shards],
            "total_records": self.total_records,
            "total_size": self.total_size,
            "all_channels": self.all_channels,
        }
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    
    @classmethod
    def load(cls, path: str) -> 'FileIndex':
        """从文件加载索引"""
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        index = cls(base_path=data["base_path"])
        index.total_records = data.get("total_records", 0)
        index.total_size = data.get("total_size", 0)
        index.all_channels = data.get("all_channels", [])
        index.shards = [ShardIndex.from_dict(s) for s in data.get("shards", [])]
        
        return index


# ==================== 写入队列 ====================

class WriteQueue:
    """
    写入队列
    
    用于异步写入的数据缓冲队列。
    支持优先级和批量提交。
    """
    
    def __init__(self, max_size: int = 100):
        """
        初始化队列
        
        Args:
            max_size: 队列最大容量
        """
        self._queue = queue.Queue(maxsize=max_size)
        self._stop_event = threading.Event()
        self._total_items = 0
    
    def put(self, item: Any, timeout: float = 5.0) -> bool:
        """
        添加项目到队列
        
        Args:
            item: 数据项
            timeout: 超时时间
            
        Returns:
            bool: 是否成功添加
        """
        if self._stop_event.is_set():
            return False
        
        try:
            self._queue.put(item, timeout=timeout)
            self._total_items += 1
            return True
        except queue.Full:
            return False
    
    def get(self, timeout: float = 1.0) -> Optional[Any]:
        """获取队列项目"""
        try:
            return self._queue.get(timeout=timeout)
        except queue.Empty:
            return None
    
    def task_done(self):
        """标记任务完成"""
        self._queue.task_done()
    
    def stop(self):
        """停止队列"""
        self._stop_event.set()
    
    def is_stopped(self) -> bool:
        """是否已停止"""
        return self._stop_event.is_set()
    
    def size(self) -> int:
        """当前队列大小"""
        return self._queue.qsize()
    
    def wait_empty(self, timeout: float = 30.0) -> bool:
        """等待队列清空"""
        start = time.time()
        while time.time() - start < timeout:
            if self._queue.empty():
                return True
            time.sleep(0.1)
        return False


# ==================== 并行工作器 ====================

class ParallelWorker:
    """
    并行工作器
    
    管理并行写入任务。
    """
    
    def __init__(self, num_workers: int = 4):
        """
        初始化工作器
        
        Args:
            num_workers: 工作线程数
        """
        self._num_workers = num_workers
        self._executor: Optional[ThreadPoolExecutor] = None
        self._futures = []
    
    def start(self):
        """启动工作器"""
        self._executor = ThreadPoolExecutor(max_workers=self._num_workers)
    
    def submit(self, func: Callable, *args, **kwargs):
        """
        提交任务
        
        Args:
            func: 任务函数
            *args: 位置参数
            **kwargs: 关键字参数
            
        Returns:
            Future: 任务句柄
        """
        if self._executor is None:
            self.start()
        
        future = self._executor.submit(func, *args, **kwargs)
        self._futures.append(future)
        return future
    
    def wait_all(self, timeout: float = 30.0) -> List[Any]:
        """
        等待所有任务完成
        
        Args:
            timeout: 超时时间
            
        Returns:
            List: 所有任务的结果
        """
        results = []
        for future in as_completed(self._futures, timeout=timeout):
            try:
                results.append(future.result())
            except Exception as e:
                warnings.warn(f"Task failed: {e}")
        
        self._futures.clear()
        return results
    
    def shutdown(self, wait: bool = True):
        """关闭工作器"""
        if self._executor:
            self._executor.shutdown(wait=wait)
            self._executor = None


# ==================== 大文件写入器 ====================

class LargeFileWriter:
    """
    大文件写入器
    
    针对大型数据集优化的 MF4 写入器，主要特性：
    
    1. **分片存储**：自动将大文件拆分为多个小文件（每个 <= 1GB）
    2. **并行写入**：多线程并行处理数据分片
    3. **异步写入**：后台线程写入，主线程不阻塞
    4. **增量写入**：支持流式增量添加数据
    5. **自动索引**：创建索引文件，加速后续读取
    
    性能指标：
    - 1GB 数据写入目标：< 3秒
    - 内存峰值：< 500MB
    
    Example:
        >>> # 创建写入器
        >>> with LargeFileWriter.create(
        ...     "large_data.mf4",
        ...     config=LargeFileConfig.high_performance()
        ... ) as writer:
        ...     # 设置元数据
        ...     writer.set_header(author="Test", project="Large File Demo")
        ...     
        ...     # 批量写入数据
        ...     for i in range(100):
        ...         batch = generate_batch(10000)  # 生成 1万条记录
        ...         writer.add_signals_batch(
        ...             batch["timestamps"],
        ...             batch["signals"],
        ...             batch["units"]
        ...         )
        ...     
        ...     # 查看统计
        ...     print(writer.get_stats())
    """
    
    def __init__(
        self,
        base_path: str,
        config: Optional[LargeFileConfig] = None
    ):
        """
        初始化大文件写入器
        
        Args:
            base_path: 基础文件路径（不含扩展名）
            config: 大文件配置
        """
        self._base_path = base_path
        self._config = config or LargeFileConfig()
        
        # 文件索引
        self._index = FileIndex(base_path=base_path)
        
        # 当前分片信息
        self._current_shard_id = 0
        self._current_shard_size = 0
        self._current_shard_start_time = 0.0
        
        # 缓冲区
        self._buffer_batches: List[Dict] = []
        self._buffer_records = 0
        self._buffer_size_bytes = 0
        
        # 元数据
        self._header_info: Dict[str, str] = {}
        self._channels_info: Dict[str, str] = {}  # name -> unit
        
        # 并行工作器
        self._worker = ParallelWorker(self._config.parallel_workers)
        
        # 异步写入队列
        self._write_queue: Optional[WriteQueue] = None
        self._write_thread: Optional[threading.Thread] = None
        
        # 统计信息
        self._stats = {
            "total_records": 0,
            "total_shards": 0,
            "total_time": 0.0,
            "write_time": 0.0,
            "avg_shard_size": 0,
        }
        
        # 是否已打开
        self._is_open = False
    
    @property
    def _shard_dir(self) -> str:
        return f"{self._base_path}_shards"
    
    @classmethod
    @contextmanager
    def create(
        cls,
        base_path: str,
        config: Optional[LargeFileConfig] = None
    ):
        """
        上下文管理器方式创建写入器
        
        Args:
            base_path: 基础文件路径
            config: 配置实例
            
        Yields:
            LargeFileWriter: 写入器实例
        """
        writer = cls(base_path, config)
        try:
            writer._open()
            yield writer
        finally:
            writer.close()
    
    def _open(self):
        """打开写入器"""
        if self._is_open:
            return
        
        os.makedirs(os.path.dirname(self._base_path) or '.', exist_ok=True)
        os.makedirs(self._shard_dir, exist_ok=True)
        
        self._worker.start()
        
        if self._config.enable_async:
            self._start_async_writer()
        
        self._is_open = True
    
    def _start_async_writer(self):
        """启动异步写入线程"""
        self._write_queue = WriteQueue(max_size=50)
        
        def writer_loop():
            """写入线程主循环"""
            while not self._write_queue.is_stopped():
                item = self._write_queue.get(timeout=0.5)
                if item is not None:
                    self._write_shard_sync(*item)
                    self._write_queue.task_done()
        
        self._write_thread = threading.Thread(target=writer_loop, daemon=True)
        self._write_thread.start()
    
    def set_header(self, **kwargs):
        """
        设置文件头信息
        
        Args:
            **kwargs: 头信息字段（author, organization, project 等）
        """
        self._header_info.update(kwargs)
    
    def add_signal(
        self,
        name: str,
        timestamps: np.ndarray,
        values: np.ndarray,
        unit: str = "",
        comment: str = ""
    ):
        """
        添加单个信号
        
        Args:
            name: 信号名称
            timestamps: 时间戳数组
            values: 数值数组
            unit: 物理单位
            comment: 信号描述
        """
        self.add_signals(
            timestamps,
            {name: values},
            units={name: unit},
            comments={name: comment}
        )
    
    def add_signals(
        self,
        timestamps: np.ndarray,
        signals: Dict[str, np.ndarray],
        units: Optional[Dict[str, str]] = None,
        comments: Optional[Dict[str, str]] = None
    ):
        """
        批量添加信号
        
        这是高性能写入的主要方法，支持大批量数据添加。
        
        Args:
            timestamps: 时间戳数组
            signals: 信号字典 {名称: 数值数组}
            units: 单位字典
            comments: 注释字典
            
        Example:
            >>> timestamps = np.linspace(0, 100, 100000)
            >>> signals = {
            ...     "Engine_Speed": np.random.uniform(1000, 6000, 100000),
            ...     "Vehicle_Speed": np.random.uniform(0, 180, 100000),
            ... }
            >>> writer.add_signals(timestamps, signals, units={"Engine_Speed": "rpm"})
        """
        if not self._is_open:
            self._open()
        
        start_time = time.time()
        
        units = units or {}
        comments = comments or {}
        
        for name in signals.keys():
            if name not in self._channels_info:
                self._channels_info[name] = units.get(name, '')
        
        batch_size = len(timestamps)
        batch_bytes = self._estimate_size(signals, batch_size)
        
        if self._should_flush(batch_bytes):
            self._flush_buffer()
        
        self._buffer_batches.append({
            'timestamps': timestamps.copy(),
            'signals': {k: v.copy() for k, v in signals.items()},
        })
        
        self._buffer_records += batch_size
        self._buffer_size_bytes += batch_bytes
        
        self._stats["total_records"] += batch_size
        self._stats["total_time"] += time.time() - start_time
    
    def add_signals_batch(
        self,
        timestamps: np.ndarray,
        signals: Dict[str, np.ndarray],
        units: Optional[Dict[str, str]] = None,
        comments: Optional[Dict[str, str]] = None
    ):
        """
        添加批量信号（与 add_signals 相同，便于区分语义）
        """
        self.add_signals(timestamps, signals, units, comments)
    
    def _estimate_size(self, signals: Dict[str, np.ndarray], count: int) -> int:
        """估算数据大小（字节）"""
        # 每个浮点数 8 字节
        # 时间戳 + 信号数量
        num_signals = len(signals)
        return count * (8 + num_signals * 8)
    
    def _should_flush(self, new_bytes: int) -> bool:
        """
        判断是否需要刷新缓冲区
        
        Args:
            new_bytes: 新增数据字节数
            
        Returns:
            bool: 是否需要刷新
        """
        # 按记录数判断
        if self._buffer_records >= self._config.chunk_size:
            return True
        
        # 按大小判断
        max_buffer_bytes = self._config.buffer_size_mb * 1024 * 1024
        if self._buffer_size_bytes + new_bytes > max_buffer_bytes:
            return True
        
        return False
    
    def _flush_buffer(self):
        if not self._buffer_batches:
            return
        
        all_signal_names = set()
        for b in self._buffer_batches:
            all_signal_names.update(b['signals'].keys())
        
        groups = self._group_batches_by_timestamps()
        
        for group in groups:
            batches = group['batches']
            ref_timestamps = batches[0]['timestamps']
            
            all_signals = {}
            for name in all_signal_names:
                arrays = []
                for b in batches:
                    if name in b['signals']:
                        arrays.append(b['signals'][name])
                if arrays:
                    all_signals[name] = np.concatenate(arrays)
            
            shared_ts = all(
                np.array_equal(b['timestamps'], batches[0]['timestamps'])
                for b in batches[1:]
            )
            final_timestamps = (
                batches[0]['timestamps']
                if shared_ts
                else np.concatenate([b['timestamps'] for b in batches])
            )
            
            shard_data = {
                "timestamps": final_timestamps,
                "signals": all_signals,
                "units": self._channels_info.copy(),
            }
            
            if self._config.enable_async and self._write_queue:
                self._write_queue.put((
                    shard_data,
                    self._current_shard_id,
                    self._header_info.copy()
                ))
            else:
                self._write_shard_sync(shard_data, self._current_shard_id, self._header_info)
            
            self._current_shard_id += 1
        
        self._buffer_batches = []
        self._buffer_records = 0
        self._buffer_size_bytes = 0
    
    def _group_batches_by_timestamps(self) -> List[Dict]:
        if not self._buffer_batches:
            return []
        
        groups = []
        current_group = {
            'batches': [self._buffer_batches[0]],
            'ts_signature': self._ts_signature(self._buffer_batches[0]['timestamps']),
        }
        
        for batch in self._buffer_batches[1:]:
            sig = self._ts_signature(batch['timestamps'])
            has_overlap = bool(
                set(batch['signals'].keys()) &
                set(current_group['batches'][-1]['signals'].keys())
            )
            
            if sig == current_group['ts_signature'] and not has_overlap:
                current_group['batches'].append(batch)
            else:
                groups.append(current_group)
                current_group = {
                    'batches': [batch],
                    'ts_signature': sig,
                }
        
        groups.append(current_group)
        return groups
    
    def _ts_signature(self, ts: np.ndarray) -> tuple:
        if len(ts) == 0:
            return (0, 0.0, 0.0)
        return (len(ts), float(ts[0]), float(ts[-1]))
    
    def _write_shard_sync(
        self,
        shard_data: dict,
        shard_id: int,
        header_info: dict
    ):
        """
        同步写入分片
        
        Args:
            shard_data: 分片数据
            shard_id: 分片ID
            header_info: 头信息
        """
        start_time = time.time()
        
        # 生成分片文件名
        shard_path = self._get_shard_path(shard_id)
        
        # 创建 MDF 文件
        mdf = MDF(version='4.10')
        
        # 设置头信息
        for key, value in header_info.items():
            if hasattr(mdf, key):
                setattr(mdf, key, value)
        
        # 添加信号
        timestamps = shard_data["timestamps"]
        signals = shard_data["signals"]
        units = shard_data.get("units", {})
        
        for name, values in signals.items():
            signal = Signal(
                samples=values,
                timestamps=timestamps,
                unit=units.get(name, ''),
                name=name,
            )
            mdf.append(signal, common_timebase=True)
        
        # 保存文件
        mdf.save(shard_path, overwrite=True, compression=self._config.compression)
        mdf.close()
        
        # 更新索引
        file_size = os.path.getsize(shard_path)
        shard_index = ShardIndex(
            shard_id=shard_id,
            file_path=os.path.abspath(shard_path),
            start_time=float(timestamps[0]),
            end_time=float(timestamps[-1]),
            record_count=len(timestamps),
            file_size=file_size,
            channels=list(signals.keys()),
        )
        
        self._index.add_shard(shard_index)
        
        # 更新统计
        self._stats["total_shards"] += 1
        self._stats["write_time"] += time.time() - start_time
    
    def _get_shard_path(self, shard_id: int) -> str:
        shard_name = os.path.basename(f"{self._base_path}_shard_{shard_id:04d}.mf4")
        return os.path.join(self._shard_dir, shard_name)
    
    def get_stats(self) -> dict:
        """
        获取统计信息
        
        Returns:
            dict: 包含写入统计的字典
        """
        stats = self._stats.copy()
        
        if stats["total_shards"] > 0:
            stats["avg_shard_size"] = stats["total_records"] / stats["total_shards"]
        
        stats["buffer_records"] = self._buffer_records
        stats["buffer_size_mb"] = self._buffer_size_bytes / (1024 * 1024)
        
        return stats
    
    def save(self):
        """
        保存所有数据
        
        刷新缓冲区、等待异步写入完成、保存索引。
        """
        # 刷新剩余缓冲区
        self._flush_buffer()
        
        # 等待异步写入完成
        if self._write_queue:
            self._write_queue.wait_empty(timeout=30.0)
            self._write_queue.stop()
        
        if self._write_thread:
            self._write_thread.join(timeout=5.0)
        
        # 等待并行任务完成
        self._worker.wait_all(timeout=30.0)
        
        # 保存索引
        if self._config.index_enabled:
            index_path = f"{self._base_path}.index"
            self._index.save(index_path)
    
    def close(self):
        """关闭写入器"""
        self.save()
        
        self._worker.shutdown(wait=True)
        
        self._is_open = False
    
    def __enter__(self) -> 'LargeFileWriter':
        self._open()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


# ==================== 大文件读取器 ====================

class LargeFileReader:
    """
    大文件读取器
    
    针对分片存储的大型 MF4 文件的高性能读取器。
    
    特性：
    - 基于索引的快速定位
    - 时间范围查询
    - 并行读取分片
    - 流式迭代
    
    Example:
        >>> with LargeFileReader.open("large_data.mf4") as reader:
        ...     # 获取总信息
        ...     print(f"总分片: {reader.shard_count}")
        ...     print(f"总记录: {reader.total_records}")
        ...     
        ...     # 读取特定时间范围
        ...     data = reader.read_time_range(10.0, 20.0)
        ...     
        ...     # 流式迭代
        ...     for shard_data in reader.iter_shards():
        ...         process(shard_data)
    """
    
    def __init__(
        self,
        base_path: str,
        config: Optional[LargeFileConfig] = None
    ):
        """
        初始化大文件读取器
        
        Args:
            base_path: 基础文件路径
            config: 配置实例
        """
        self._base_path = base_path
        self._config = config or LargeFileConfig()
        
        # 文件索引
        self._index: Optional[FileIndex] = None
        
        self._is_open = False
    
    @property
    def _shard_dir(self) -> str:
        return f"{self._base_path}_shards"
    
    @classmethod
    @contextmanager
    def open(cls, base_path: str, config: Optional[LargeFileConfig] = None):
        """
        上下文管理器方式打开
        
        Args:
            base_path: 基础文件路径
            config: 配置实例
        """
        reader = cls(base_path, config)
        try:
            reader._open()
            yield reader
        finally:
            reader.close()
    
    def _open(self):
        """打开读取器"""
        if self._is_open:
            return
        
        # 加载索引
        index_path = f"{self._base_path}.index"
        if os.path.exists(index_path):
            self._index = FileIndex.load(index_path)
        else:
            # 尝试自动发现分片
            self._index = self._discover_shards()
        
        self._is_open = True
    
    def _discover_shards(self) -> FileIndex:
        index = FileIndex(base_path=self._base_path)
        
        shard_dir = self._shard_dir
        if os.path.isdir(shard_dir):
            shard_files = sorted(
                f for f in os.listdir(shard_dir)
                if f.endswith('.mf4') and f.startswith(os.path.basename(self._base_path))
            )
            for shard_file in shard_files:
                shard_path = os.path.join(shard_dir, shard_file)
                try:
                    shard_id_match = re.search(r'_shard_(\d+)', shard_file)
                    if not shard_id_match:
                        continue
                    shard_id = int(shard_id_match.group(1))
                    
                    mdf = MDF(shard_path, read_minimum=True)
                    first_channel = list(mdf.channels_db.keys())[1]
                    signal = mdf.get(first_channel, samples_only=False)
                    
                    shard_index = ShardIndex(
                        shard_id=shard_id,
                        file_path=os.path.abspath(shard_path),
                        start_time=float(signal.timestamps[0]),
                        end_time=float(signal.timestamps[-1]),
                        record_count=len(signal.timestamps),
                        file_size=os.path.getsize(shard_path),
                        channels=list(mdf.channels_db.keys())[1:],
                    )
                    
                    index.add_shard(shard_index)
                    mdf.close()
                except Exception as e:
                    warnings.warn(f"Failed to read shard {shard_file}: {e}")
        else:
            base_name = os.path.basename(self._base_path)
            parent_dir = os.path.dirname(self._base_path) or '.'
            shard_id = 0
            while True:
                shard_path = f"{self._base_path}_shard_{shard_id:04d}.mf4"
                if not os.path.exists(shard_path):
                    break
                try:
                    mdf = MDF(shard_path, read_minimum=True)
                    first_channel = list(mdf.channels_db.keys())[1]
                    signal = mdf.get(first_channel, samples_only=False)
                    
                    shard_index = ShardIndex(
                        shard_id=shard_id,
                        file_path=os.path.abspath(shard_path),
                        start_time=float(signal.timestamps[0]),
                        end_time=float(signal.timestamps[-1]),
                        record_count=len(signal.timestamps),
                        file_size=os.path.getsize(shard_path),
                        channels=list(mdf.channels_db.keys())[1:],
                    )
                    
                    index.add_shard(shard_index)
                    mdf.close()
                except Exception as e:
                    warnings.warn(f"Failed to read shard {shard_id}: {e}")
                shard_id += 1
        
        return index
    
    @property
    def shard_count(self) -> int:
        """分片数量"""
        return len(self._index.shards) if self._index else 0
    
    @property
    def total_records(self) -> int:
        """总记录数"""
        return self._index.total_records if self._index else 0
    
    @property
    def total_size(self) -> int:
        """总文件大小（字节）"""
        return self._index.total_size if self._index else 0
    
    @property
    def channels(self) -> List[str]:
        """所有通道名称"""
        return self._index.all_channels if self._index else []
    
    def read_shard(self, shard_id: int) -> Dict[str, np.ndarray]:
        """
        读取指定分片
        
        Args:
            shard_id: 分片ID
            
        Returns:
            dict: 包含 timestamps 和各通道数据的字典
        """
        if not self._index or shard_id >= len(self._index.shards):
            raise ValueError(f"Invalid shard_id: {shard_id}")
        
        shard = self._index.shards[shard_id]
        return self._read_shard_file(shard.file_path)
    
    def _read_shard_file(self, file_path: str) -> Dict[str, np.ndarray]:
        """读取分片文件"""
        data = {}
        
        mdf = MDF(file_path)
        
        for name in mdf.channels_db.keys():
            if name.lower() == 'time':
                continue
            
            signal = mdf.get(name, samples_only=False)
            
            if 'timestamps' not in data:
                data['timestamps'] = signal.timestamps
            
            data[name] = signal.samples
        
        mdf.close()
        
        return data
    
    def read_time_range(
        self,
        start_time: float,
        end_time: float,
        channels: Optional[List[str]] = None
    ) -> Dict[str, np.ndarray]:
        """
        读取指定时间范围的数据
        
        Args:
            start_time: 起始时间（秒）
            end_time: 结束时间（秒）
            channels: 要读取的通道列表（None 表示全部）
            
        Returns:
            dict: 数据字典
        """
        if not self._index:
            return {}
        
        # 查找相关分片
        shards = self._index.find_shards_in_range(start_time, end_time)
        
        if not shards:
            return {}
        
        # 读取并合并数据
        all_data = {'timestamps': []}
        channels = channels or self.channels
        
        for ch in channels:
            all_data[ch] = []
        
        for shard in shards:
            shard_data = self._read_shard_file(shard.file_path)
            
            # 过滤时间范围
            timestamps = shard_data['timestamps']
            mask = (timestamps >= start_time) & (timestamps <= end_time)
            
            all_data['timestamps'].extend(timestamps[mask])
            
            for ch in channels:
                if ch in shard_data:
                    all_data[ch].extend(shard_data[ch][mask])
        
        # 转换为 numpy 数组
        for key in all_data:
            all_data[key] = np.array(all_data[key])
        
        return all_data
    
    def iter_shards(
        self,
        start_shard: int = 0,
        end_shard: Optional[int] = None
    ) -> Iterator[Dict[str, np.ndarray]]:
        """
        迭代读取分片
        
        Args:
            start_shard: 起始分片ID
            end_shard: 结束分片ID（None 表示到最后）
            
        Yields:
            dict: 分片数据
        """
        if not self._index:
            return
        
        end_shard = end_shard or len(self._index.shards)
        
        for shard_id in range(start_shard, end_shard):
            yield self.read_shard(shard_id)
    
    def read_parallel(
        self,
        shard_ids: Optional[List[int]] = None,
        max_workers: Optional[int] = None
    ) -> List[Dict[str, np.ndarray]]:
        """
        并行读取多个分片
        
        Args:
            shard_ids: 分片ID列表（None 表示全部）
            max_workers: 最大工作线程数
            
        Returns:
            List: 分片数据列表
        """
        if not self._index:
            return []
        
        shard_ids = shard_ids or list(range(len(self._index.shards)))
        max_workers = max_workers or self._config.parallel_workers
        
        results = [None] * len(shard_ids)
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {
                executor.submit(self.read_shard, sid): i
                for i, sid in enumerate(shard_ids)
            }
            
            for future in as_completed(futures):
                idx = futures[future]
                try:
                    results[idx] = future.result()
                except Exception as e:
                    warnings.warn(f"Failed to read shard: {e}")
        
        return results
    
    def get_info(self) -> dict:
        """
        获取文件信息
        
        Returns:
            dict: 文件信息字典
        """
        return {
            "base_path": self._base_path,
            "shard_count": self.shard_count,
            "total_records": self.total_records,
            "total_size_mb": self.total_size / (1024 * 1024),
            "channels": self.channels,
            "shards": [
                {
                    "id": s.shard_id,
                    "records": s.record_count,
                    "size_mb": s.file_size / (1024 * 1024),
                    "time_range": f"{s.start_time:.2f} - {s.end_time:.2f}",
                }
                for s in (self._index.shards if self._index else [])
            ],
        }
    
    def close(self):
        """关闭读取器"""
        self._is_open = False
    
    def __enter__(self) -> 'LargeFileReader':
        self._open()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


# ==================== 便捷函数 ====================

def create_large_writer(
    base_path: str,
    max_shard_size_mb: int = 1024,
    parallel_workers: int = 4,
    enable_async: bool = True
) -> LargeFileWriter:
    """
    创建大文件写入器的便捷函数
    
    Args:
        base_path: 基础文件路径
        max_shard_size_mb: 最大分片大小（MB）
        parallel_workers: 并行工作线程数
        enable_async: 是否启用异步写入
        
    Returns:
        LargeFileWriter: 写入器实例
    """
    config = LargeFileConfig(
        max_shard_size_mb=max_shard_size_mb,
        parallel_workers=parallel_workers,
        enable_async=enable_async,
    )
    return LargeFileWriter(base_path, config)


def open_large_reader(base_path: str) -> LargeFileReader:
    """
    打开大文件读取器的便捷函数
    
    Args:
        base_path: 基础文件路径
        
    Returns:
        LargeFileReader: 读取器实例
    """
    return LargeFileReader(base_path)