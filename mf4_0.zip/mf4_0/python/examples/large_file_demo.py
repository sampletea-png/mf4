"""
大文件读写演示

展示 MF4 SDK 的大文件优化功能：
1. 分片存储 - 自动拆分大文件
2. 并行写入 - 多线程加速
3. 异步写入 - 后台处理
4. 快速读取 - 基于索引

性能目标：1GB 数据写入 < 3秒

运行方式:
    python examples/large_file_demo.py
"""

import os
import sys
import time
import tempfile
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from mf4 import (
    LargeFileWriter,
    LargeFileReader,
    LargeFileConfig,
    create_large_writer,
)


def print_section(title):
    """打印分节标题"""
    print("\n" + "=" * 70)
    print(f"  {title}")
    print("=" * 70)


def print_subsection(title):
    """打印子标题"""
    print(f"\n--- {title} ---")


def format_size(bytes_size):
    """格式化文件大小"""
    for unit in ['B', 'KB', 'MB', 'GB']:
        if bytes_size < 1024:
            return f"{bytes_size:.2f} {unit}"
        bytes_size /= 1024
    return f"{bytes_size:.2f} TB"


def format_time(seconds):
    """格式化时间"""
    if seconds < 1:
        return f"{seconds * 1000:.0f} ms"
    return f"{seconds:.2f} s"


def demo_basic_large_file():
    """
    演示基本的大文件写入
    
    目标：展示如何创建大型 MF4 文件
    """
    print_section("1. 基本大文件写入")
    
    temp_dir = tempfile.mkdtemp()
    base_path = os.path.join(temp_dir, "basic_large")
    
    # 配置：高性能模式
    config = LargeFileConfig.high_performance()
    
    print(f"配置信息:")
    print(f"  最大分片大小: {config.max_shard_size_mb} MB")
    print(f"  并行工作线程: {config.parallel_workers}")
    print(f"  异步写入: {config.enable_async}")
    print(f"  缓冲区大小: {config.buffer_size_mb} MB")
    
    # 数据规模
    num_records = 2_000_000  # 200万记录
    num_channels = 8
    
    print(f"\n数据规模:")
    print(f"  记录数: {num_records:,}")
    print(f"  通道数: {num_channels}")
    print(f"  预估大小: {num_records * (8 + num_channels * 8) / (1024**2):.0f} MB")
    
    start_time = time.time()
    
    with LargeFileWriter.create(base_path, config) as writer:
        # 设置文件头
        writer.set_header(
            author="Large File Demo",
            organization="MF4 SDK",
            project="Performance Test",
            comment="Demonstrating large file optimization"
        )
        
        # 分批写入数据
        batch_size = 200_000
        num_batches = num_records // batch_size
        
        print(f"\n写入进度:")
        for i in range(num_batches):
            # 生成批次数据
            timestamps = np.linspace(
                i * batch_size * 0.001,
                (i + 1) * batch_size * 0.001,
                batch_size
            )
            
            signals = {
                f"Signal_{j}": np.random.randn(batch_size)
                for j in range(num_channels)
            }
            
            units = {f"Signal_{j}": "V" for j in range(num_channels)}
            
            writer.add_signals(timestamps, signals, units)
            
            # 显示进度
            progress = (i + 1) / num_batches * 100
            elapsed = time.time() - start_time
            print(f"  批次 {i+1}/{num_batches} ({progress:.0f}%) - 耗时: {format_time(elapsed)}")
        
        # 获取统计
        stats = writer.get_stats()
    
    total_time = time.time() - start_time
    
    # 计算总文件大小
    total_size = sum(
        os.path.getsize(os.path.join(temp_dir, f))
        for f in os.listdir(temp_dir)
        if f.startswith("basic_large")
    )
    
    print(f"\n结果:")
    print(f"  总耗时: {format_time(total_time)}")
    print(f"  文件大小: {format_size(total_size)}")
    print(f"  写入速度: {total_size / total_time / (1024**2):.1f} MB/s")
    print(f"  分片数量: {stats['total_shards']}")
    print(f"  总记录数: {stats['total_records']:,}")
    
    return base_path


def demo_shard_storage():
    """
    演示分片存储
    
    目标：展示文件如何被自动分片
    """
    print_section("2. 分片存储演示")
    
    temp_dir = tempfile.mkdtemp()
    base_path = os.path.join(temp_dir, "shard_demo")
    
    # 配置：小分片以便观察
    config = LargeFileConfig(
        max_shard_size_mb=30,  # 30MB 每分片
        parallel_workers=2,
        enable_async=False,
        chunk_size=50_000,
    )
    
    print(f"配置: 每分片最大 {config.max_shard_size_mb} MB")
    
    # 写入足够触发分片的数据
    num_records = 500_000
    num_channels = 10
    
    with LargeFileWriter.create(base_path, config) as writer:
        writer.set_header(author="Shard Demo")
        
        timestamps = np.linspace(0, 100, num_records)
        signals = {
            f"Channel_{i}": np.random.randn(num_records)
            for i in range(num_channels)
        }
        
        writer.add_signals(timestamps, signals)
    
    # 显示分片文件
    print(f"\n生成的分片文件:")
    shard_files = sorted([
        f for f in os.listdir(temp_dir)
        if f.startswith("shard_demo_shard")
    ])
    
    for f in shard_files:
        path = os.path.join(temp_dir, f)
        size = os.path.getsize(path)
        print(f"  {f}: {format_size(size)}")
    
    # 显示索引文件
    index_file = f"{os.path.basename(base_path)}.index"
    if os.path.exists(os.path.join(temp_dir, index_file)):
        print(f"\n索引文件:")
        print(f"  {index_file}")
        
        # 读取并显示索引内容
        import json
        with open(os.path.join(temp_dir, index_file), 'r') as f:
            index_data = json.load(f)
        
        print(f"\n索引信息:")
        print(f"  总记录数: {index_data['total_records']:,}")
        print(f"  总大小: {format_size(index_data['total_size'])}")
        print(f"  通道数: {len(index_data['all_channels'])}")
    
    return base_path


def demo_parallel_vs_sequential():
    """
    演示并行 vs 顺序写入
    
    目标：对比性能差异
    """
    print_section("3. 并行写入 vs 顺序写入")
    
    temp_dir = tempfile.mkdtemp()
    
    # 测试参数
    num_records = 1_000_000
    num_channels = 5
    batch_size = 100_000
    
    print(f"测试参数:")
    print(f"  记录数: {num_records:,}")
    print(f"  通道数: {num_channels}")
    
    # 生成测试数据
    timestamps = np.linspace(0, 100, num_records)
    signals = {
        f"Signal_{i}": np.random.randn(num_records)
        for i in range(num_channels)
    }
    
    # 顺序写入
    print_subsection("顺序写入")
    config_seq = LargeFileConfig(
        parallel_workers=1,
        enable_async=False,
    )
    
    start_seq = time.time()
    with LargeFileWriter.create(
        os.path.join(temp_dir, "seq"), 
        config_seq
    ) as writer:
        for i in range(num_records // batch_size):
            start_idx = i * batch_size
            end_idx = (i + 1) * batch_size
            writer.add_signals(
                timestamps[start_idx:end_idx],
                {k: v[start_idx:end_idx] for k, v in signals.items()}
            )
    time_seq = time.time() - start_seq
    
    print(f"  耗时: {format_time(time_seq)}")
    
    # 并行写入
    print_subsection("并行写入 (4线程)")
    config_par = LargeFileConfig(
        parallel_workers=4,
        enable_async=True,
    )
    
    start_par = time.time()
    with LargeFileWriter.create(
        os.path.join(temp_dir, "par"),
        config_par
    ) as writer:
        for i in range(num_records // batch_size):
            start_idx = i * batch_size
            end_idx = (i + 1) * batch_size
            writer.add_signals(
                timestamps[start_idx:end_idx],
                {k: v[start_idx:end_idx] for k, v in signals.items()}
            )
    time_par = time.time() - start_par
    
    print(f"  耗时: {format_time(time_par)}")
    
    # 对比
    speedup = time_seq / time_par if time_par > 0 else 1
    print(f"\n对比:")
    print(f"  加速比: {speedup:.2f}x")
    print(f"  时间节省: {(1 - time_par/time_seq)*100:.1f}%")


def demo_async_write():
    """
    演示异步写入
    
    目标：展示异步写入如何避免阻塞
    """
    print_section("4. 异步写入演示")
    
    temp_dir = tempfile.mkdtemp()
    base_path = os.path.join(temp_dir, "async_demo")
    
    config = LargeFileConfig(
        enable_async=True,
        parallel_workers=4,
        buffer_size_mb=50,
    )
    
    num_records = 500_000
    num_batches = 10
    batch_size = num_records // num_batches
    
    print(f"配置:")
    print(f"  异步写入: 启用")
    print(f"  缓冲区: {config.buffer_size_mb} MB")
    print(f"\n写入批次耗时:")
    
    batch_times = []
    total_start = time.time()
    
    with LargeFileWriter.create(base_path, config) as writer:
        for i in range(num_batches):
            batch_start = time.time()
            
            timestamps = np.linspace(i * 10, (i + 1) * 10, batch_size)
            signals = {f"Ch_{j}": np.random.randn(batch_size) for j in range(5)}
            writer.add_signals(timestamps, signals)
            
            batch_time = time.time() - batch_start
            batch_times.append(batch_time)
            print(f"  批次 {i+1}: {format_time(batch_time)}")
    
    total_time = time.time() - total_start
    
    print(f"\n统计:")
    print(f"  批次平均耗时: {format_time(sum(batch_times)/len(batch_times))}")
    print(f"  总耗时: {format_time(total_time)}")
    print(f"  说明: 批次添加很快，因为实际写入在后台进行")


def demo_1gb_performance():
    """
    演示 1GB 数据写入性能
    
    目标：验证写入时间 < 3秒
    """
    print_section("5. 1GB 数据写入性能测试")
    
    temp_dir = tempfile.mkdtemp()
    base_path = os.path.join(temp_dir, "1gb_test")
    
    # 最优配置
    config = LargeFileConfig(
        max_shard_size_mb=1024,
        parallel_workers=min(8, os.cpu_count() or 4),
        enable_async=True,
        buffer_size_mb=200,
        chunk_size=100_000,
        compression=False,
    )
    
    # 1GB 数据量
    # 每记录：时间戳(8) + 10通道(10*8) = 88 字节
    # 1GB / 88 ≈ 12,000,000 记录
    num_records = 10_000_000
    num_channels = 10
    
    estimated_size = num_records * (8 + num_channels * 8)
    
    print(f"测试配置:")
    print(f"  记录数: {num_records:,}")
    print(f"  通道数: {num_channels}")
    print(f"  预估大小: {format_size(estimated_size)}")
    print(f"  目标时间: < 3 秒")
    
    print(f"\n开始写入...")
    start_time = time.time()
    
    with LargeFileWriter.create(base_path, config) as writer:
        writer.set_header(
            author="1GB Performance Test",
            comment="Testing 3-second write constraint"
        )
        
        batch_size = 500_000
        num_batches = num_records // batch_size
        
        for i in range(num_batches):
            timestamps = np.linspace(
                i * batch_size * 0.0001,
                (i + 1) * batch_size * 0.0001,
                batch_size
            )
            
            signals = {
                f"Channel_{j}": np.random.randn(batch_size)
                for j in range(num_channels)
            }
            
            writer.add_signals(timestamps, signals)
            
            # 显示进度
            if (i + 1) % 4 == 0:
                elapsed = time.time() - start_time
                progress = (i + 1) / num_batches * 100
                print(f"  进度: {progress:.0f}% - 耗时: {format_time(elapsed)}")
    
    write_time = time.time() - start_time
    
    # 计算实际文件大小
    total_size = sum(
        os.path.getsize(os.path.join(temp_dir, f))
        for f in os.listdir(temp_dir)
        if f.startswith("1gb_test")
    )
    
    print(f"\n" + "=" * 50)
    print(f"  结果")
    print(f"=" * 50)
    print(f"  写入时间: {format_time(write_time)}")
    print(f"  文件大小: {format_size(total_size)}")
    print(f"  写入速度: {total_size / write_time / (1024**2):.1f} MB/s")
    
    # 判断是否达标
    if write_time <= 3.0:
        print(f"\n  ✓ 达标！写入时间 {format_time(write_time)} < 3秒")
    else:
        print(f"\n  ✗ 未达标。写入时间 {format_time(write_time)} > 3秒")
        print(f"    建议: 增加并行线程数或使用更快的存储设备")
    
    return base_path


def demo_large_file_read(base_path):
    """
    演示大文件读取
    
    目标：展示如何读取分片存储的文件
    """
    print_section("6. 大文件读取演示")
    
    if not base_path or not os.path.exists(f"{base_path}.index"):
        print("跳过：需要先运行写入演示")
        return
    
    with LargeFileReader.open(base_path) as reader:
        # 获取文件信息
        info = reader.get_info()
        
        print(f"文件信息:")
        print(f"  分片数: {info['shard_count']}")
        print(f"  总记录: {info['total_records']:,}")
        print(f"  总大小: {info['total_size_mb']:.1f} MB")
        print(f"  通道: {info['channels']}")
        
        # 显示分片详情
        print(f"\n分片详情:")
        for shard in info['shards']:
            print(f"  分片 {shard['id']}: {shard['records']:,} 记录, "
                  f"{shard['size_mb']:.1f} MB, 时间: {shard['time_range']}")
        
        # 读取单个分片
        print_subsection("读取单个分片")
        start = time.time()
        shard_data = reader.read_shard(0)
        read_time = time.time() - start
        
        print(f"  分片 0 数据点: {len(shard_data.get('timestamps', [])):,}")
        print(f"  读取耗时: {format_time(read_time)}")
        
        # 读取时间范围
        print_subsection("时间范围读取")
        start = time.time()
        range_data = reader.read_time_range(10.0, 20.0)
        read_time = time.time() - start
        
        print(f"  时间范围: 10-20 秒")
        print(f"  数据点: {len(range_data.get('timestamps', [])):,}")
        print(f"  读取耗时: {format_time(read_time)}")


def demo_configuration_options():
    """
    演示配置选项
    
    目标：展示不同的配置预设
    """
    print_section("7. 配置选项演示")
    
    # 默认配置
    default = LargeFileConfig()
    print("默认配置:")
    print(f"  分片大小: {default.max_shard_size_mb} MB")
    print(f"  并行线程: {default.parallel_workers}")
    print(f"  异步写入: {default.enable_async}")
    print(f"  缓冲区: {default.buffer_size_mb} MB")
    
    # 高性能配置
    hp = LargeFileConfig.high_performance()
    print("\n高性能配置:")
    print(f"  分片大小: {hp.max_shard_size_mb} MB")
    print(f"  并行线程: {hp.parallel_workers}")
    print(f"  异步写入: {hp.enable_async}")
    print(f"  缓冲区: {hp.buffer_size_mb} MB")
    print(f"  分块大小: {hp.chunk_size:,}")
    
    # 低内存配置
    lm = LargeFileConfig.low_memory()
    print("\n低内存配置:")
    print(f"  分片大小: {lm.max_shard_size_mb} MB")
    print(f"  并行线程: {lm.parallel_workers}")
    print(f"  异步写入: {lm.enable_async}")
    print(f"  缓冲区: {lm.buffer_size_mb} MB")
    print(f"  最大内存: {lm.max_memory_mb} MB")


def main():
    """运行所有演示"""
    print("\n" + "=" * 70)
    print("  MF4 SDK - 大文件读写优化演示")
    print("=" * 70)
    print(f"\n时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    start_time = time.time()
    
    try:
        # 基本演示
        basic_path = demo_basic_large_file()
        
        # 分片存储
        shard_path = demo_shard_storage()
        
        # 并行对比
        demo_parallel_vs_sequential()
        
        # 异步写入
        demo_async_write()
        
        # 1GB 性能测试
        path_1gb = demo_1gb_performance()
        
        # 大文件读取
        demo_large_file_read(path_1gb)
        
        # 配置选项
        demo_configuration_options()
        
        # 总结
        total_time = time.time() - start_time
        
        print("\n" + "=" * 70)
        print("  演示完成")
        print("=" * 70)
        print(f"  总耗时: {format_time(total_time)}")
        print(f"\n  主要优化技术:")
        print(f"    1. 分片存储 - 自动拆分大文件")
        print(f"    2. 并行写入 - 多线程加速处理")
        print(f"    3. 异步写入 - 后台写入不阻塞")
        print(f"    4. 索引机制 - 快速定位数据")
        print("=" * 70 + "\n")
        
    except Exception as e:
        print(f"\n错误: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    sys.exit(main())