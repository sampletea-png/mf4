"""
MF4 SDK 完整功能演示脚本

展示如何使用 MF4 SDK 进行：
1. 创建 MF4 文件
2. 写入多种类型的数据
3. 读取和查询数据
4. 格式转换
5. 流式处理大文件

运行方式:
    python examples/complete_demo.py
"""

import os
import sys
import time
import tempfile
from datetime import datetime

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np

from mf4 import Mf4Reader, Mf4Writer, Mf4Converter, Mf4Config, Mf4StreamingReader
from mf4.enums import DataType, ChannelType
from mf4.model import FileHeader


def print_section(title):
    """打印分节标题"""
    print("\n" + "=" * 60)
    print(f"  {title}")
    print("=" * 60)


def demo_write_basic():
    """
    演示基本的 MF4 文件创建
    
    内容：
    - 创建文件并设置元数据
    - 添加单个信号
    - 使用不同的数据类型
    """
    print_section("1. 基本写入演示")
    
    # 创建临时文件
    temp_dir = tempfile.mkdtemp()
    file_path = os.path.join(temp_dir, "demo_basic.mf4")
    
    print(f"创建文件: {file_path}")
    
    with Mf4Writer.create(file_path, version="4.10") as writer:
        # 设置文件头信息
        # 这些信息会存储在 MF4 文件的 HDBLOCK 中
        writer.set_header(
            author="MF4 SDK Demo",
            organization="Example Corporation",
            project="Engine Performance Test",
            subject="Test Engine #001",
            comment="Basic write demonstration"
        )
        
        # 创建时间轴（10秒，1000个采样点）
        # 时间单位为秒
        timestamps = np.linspace(0, 10, 1000)
        
        # 创建模拟发动机转速数据
        # 基础转速 + 正弦波动 + 随机噪声
        base_speed = 3000  # rpm
        amplitude = 500    # 波动幅度
        noise_level = 50   # 噪声水平
        
        engine_speed = (
            base_speed 
            + amplitude * np.sin(2 * np.pi * timestamps / 5)  # 正弦波动
            + np.random.normal(0, noise_level, 1000)           # 高斯噪声
        )
        
        # 添加信号到 MF4 文件
        # asammdf 会自动管理通道组
        writer.add_signal(
            name="Engine_Speed",
            timestamps=timestamps,
            values=engine_speed,
            unit="rpm",
            comment="Engine rotational speed measured at the crankshaft"
        )
        
        print(f"  ✓ 写入 Engine_Speed: {len(engine_speed)} 个数据点")
        
        # 添加另一个信号：车速
        vehicle_speed = np.interp(
            timestamps,
            [0, 2, 5, 8, 10],  # 时间节点
            [0, 50, 100, 80, 0]  # 车速节点
        ) + np.random.normal(0, 2, 1000)
        vehicle_speed = np.clip(vehicle_speed, 0, 120)  # 限制范围
        
        writer.add_signal(
            name="Vehicle_Speed",
            timestamps=timestamps,
            values=vehicle_speed,
            unit="km/h",
            comment="Vehicle speed from GPS"
        )
        
        print(f"  ✓ 写入 Vehicle_Speed: {len(vehicle_speed)} 个数据点")
        print(f"  ✓ 文件已保存")
    
    return file_path


def demo_write_multiple_signals():
    """
    演示批量写入多个信号
    
    内容：
    - 使用 add_signals 批量添加
    - 设置不同的单位
    - 处理大量数据
    """
    print_section("2. 批量写入演示")
    
    temp_dir = tempfile.mkdtemp()
    file_path = os.path.join(temp_dir, "demo_multi.mf4")
    
    print(f"创建文件: {file_path}")
    
    with Mf4Writer.create(file_path) as writer:
        writer.set_header(
            author="Multi-Signal Demo",
            project="Complete Engine Test"
        )
        
        # 创建时间轴：100秒，10000个采样点
        timestamps = np.linspace(0, 100, 10000)
        
        # 创建多个信号的数据
        signals = {
            # 发动机参数
            "Engine_Speed": np.random.uniform(1000, 6000, 10000),
            "Engine_Torque": np.random.uniform(100, 300, 10000),
            "Engine_Power": np.random.uniform(50, 150, 10000),
            
            # 车辆参数
            "Vehicle_Speed": np.random.uniform(0, 180, 10000),
            "Acceleration": np.random.uniform(-5, 5, 10000),
            
            # 温度参数
            "Coolant_Temp": np.random.uniform(70, 105, 10000),
            "Oil_Temp": np.random.uniform(60, 120, 10000),
            "Intake_Air_Temp": np.random.uniform(20, 50, 10000),
            
            # 压力参数
            "Oil_Pressure": np.random.uniform(1, 5, 10000),
            "Fuel_Pressure": np.random.uniform(3, 5, 10000),
            "Boost_Pressure": np.random.uniform(1, 2.5, 10000),
            
            # 控制参数
            "Throttle_Position": np.random.uniform(0, 100, 10000),
            "Brake_Pressure": np.random.uniform(0, 100, 10000),
        }
        
        # 定义单位映射
        units = {
            "Engine_Speed": "rpm",
            "Engine_Torque": "Nm",
            "Engine_Power": "kW",
            "Vehicle_Speed": "km/h",
            "Acceleration": "m/s²",
            "Coolant_Temp": "°C",
            "Oil_Temp": "°C",
            "Intake_Air_Temp": "°C",
            "Oil_Pressure": "bar",
            "Fuel_Pressure": "bar",
            "Boost_Pressure": "bar",
            "Throttle_Position": "%",
            "Brake_Pressure": "bar",
        }
        
        # 批量添加所有信号
        writer.add_signals(timestamps, signals, units=units)
        
        print(f"  ✓ 写入 {len(signals)} 个信号")
        print(f"  ✓ 每个信号 {len(timestamps)} 个数据点")
        print(f"  ✓ 总数据点: {len(signals) * len(timestamps):,}")
    
    return file_path


def demo_read_basic(file_path):
    """
    演示基本的文件读取
    
    内容：
    - 打开文件并读取头信息
    - 获取通道列表
    - 读取单个通道数据
    """
    print_section("3. 基本读取演示")
    
    print(f"读取文件: {file_path}")
    
    with Mf4Reader.open(file_path) as reader:
        # 获取文件头信息
        header = reader.header
        print(f"\n文件信息:")
        print(f"  版本: {header.version}")
        print(f"  作者: {header.author}")
        print(f"  项目: {header.project}")
        
        # 获取通道列表
        channels = reader.get_channels()
        print(f"\n通道列表 (共 {len(channels)} 个):")
        for ch in channels[:5]:  # 只显示前5个
            print(f"  - {ch.name} ({ch.unit})")
        
        # 读取特定通道数据
        signal = reader.read_channel("Engine_Speed")
        
        print(f"\nEngine_Speed 信号信息:")
        print(f"  数据点数: {len(signal)}")
        print(f"  单位: {signal.unit}")
        print(f"  时间范围: {signal.timestamps[0]:.2f} - {signal.timestamps[-1]:.2f} 秒")
        
        # 计算统计信息
        stats = signal.get_statistics()
        print(f"\n统计信息:")
        print(f"  最小值: {stats['min']:.2f} {signal.unit}")
        print(f"  最大值: {stats['max']:.2f} {signal.unit}")
        print(f"  平均值: {stats['mean']:.2f} {signal.unit}")
        print(f"  标准差: {stats['std']:.2f} {signal.unit}")


def demo_read_time_range(file_path):
    """
    演示按时间范围读取数据
    
    内容：
    - 截取特定时间范围的数据
    - 数据插值查询
    """
    print_section("4. 时间范围读取演示")
    
    print(f"读取文件: {file_path}")
    
    with Mf4Reader.open(file_path) as reader:
        # 只读取 2-5 秒的数据
        signal = reader.read_channel(
            "Engine_Speed",
            start_time=2.0,
            end_time=5.0
        )
        
        print(f"\n时间范围 2-5 秒的数据:")
        print(f"  数据点数: {len(signal)}")
        print(f"  实际时间范围: {signal.timestamps[0]:.3f} - {signal.timestamps[-1]:.3f} 秒")
        
        # 在特定时间点查询值（线性插值）
        query_times = [2.5, 3.0, 4.5]
        print(f"\n指定时间的值:")
        for t in query_times:
            value = signal.get_value_at_time(t)
            print(f"  t={t:.1f}s: {value:.2f} {signal.unit}")


def demo_filter_channels(file_path):
    """
    演示通道过滤功能
    
    内容：
    - 按名称模式过滤
    - 按单位过滤
    """
    print_section("5. 通道过滤演示")
    
    print(f"读取文件: {file_path}")
    
    with Mf4Reader.open(file_path) as reader:
        # 按名称模式过滤（支持通配符）
        temp_channels = reader.filter_channels(name_pattern="*Temp")
        print(f"\n温度相关通道:")
        for ch in temp_channels:
            print(f"  - {ch.name}")
        
        # 过滤特定单位
        pressure_channels = reader.filter_channels(unit="bar")
        print(f"\n压力通道 (bar):")
        for ch in pressure_channels:
            print(f"  - {ch.name}")


def demo_streaming_read(file_path):
    """
    演示流式读取大文件
    
    内容：
    - 批量读取数据
    - 处理进度跟踪
    """
    print_section("6. 流式读取演示")
    
    print(f"读取文件: {file_path}")
    
    total_samples = 0
    batch_count = 0
    
    with Mf4StreamingReader.open(file_path) as reader:
        for batch in reader.read_batches(batch_size=2000):
            batch_count += 1
            
            # 获取第一个通道的样本数
            sample_count = len(list(batch.values())[0])
            total_samples += sample_count
            
            print(f"  批次 {batch_count}: {sample_count} 个样本")
    
    print(f"\n总计: {batch_count} 批次, {total_samples:,} 个样本")


def demo_format_conversion(file_path):
    """
    演示格式转换功能
    
    内容：
    - 转换为 CSV
    - 转换为 JSON
    - 获取文件信息
    """
    print_section("7. 格式转换演示")
    
    temp_dir = tempfile.mkdtemp()
    
    print(f"源文件: {file_path}")
    
    converter = Mf4Converter(file_path)
    
    # 获取文件信息
    info = converter.get_info()
    print(f"\n文件信息:")
    print(f"  版本: {info['version']}")
    print(f"  通道数: {info['channels_count']}")
    print(f"  组数: {info['groups_count']}")
    
    # 转换为 CSV
    csv_path = os.path.join(temp_dir, "output.csv")
    print(f"\n转换为 CSV: {csv_path}")
    converter.to_csv(csv_path, channels=["Engine_Speed", "Vehicle_Speed"])
    
    # 验证文件
    if os.path.exists(csv_path):
        file_size = os.path.getsize(csv_path)
        print(f"  ✓ 文件大小: {file_size:,} 字节")
    
    # 转换为 JSON
    json_path = os.path.join(temp_dir, "output.json")
    print(f"\n转换为 JSON: {json_path}")
    converter.to_json(json_path)
    
    converter.close()


def demo_with_compression():
    """
    演示压缩写入
    
    内容：
    - 创建压缩的 MF4 文件
    - 比较文件大小
    """
    print_section("8. 压缩功能演示")
    
    temp_dir = tempfile.mkdtemp()
    
    # 创建未压缩文件
    normal_path = os.path.join(temp_dir, "normal.mf4")
    with Mf4Writer.create(normal_path) as writer:
        writer.set_header(author="Compression Demo")
        timestamps = np.linspace(0, 10, 10000)
        values = np.random.randn(10000)
        writer.add_signal("Data", timestamps, values)
    
    # 创建压缩文件
    compressed_path = os.path.join(temp_dir, "compressed.mf4")
    with Mf4Writer.create(compressed_path, compression=True) as writer:
        writer.set_header(author="Compression Demo")
        timestamps = np.linspace(0, 10, 10000)
        values = np.random.randn(10000)
        writer.add_signal("Data", timestamps, values)
    
    # 比较文件大小
    normal_size = os.path.getsize(normal_path)
    compressed_size = os.path.getsize(compressed_path)
    
    print(f"\n文件大小比较:")
    print(f"  未压缩: {normal_size:,} 字节")
    print(f"  压缩后: {compressed_size:,} 字节")
    print(f"  压缩率: {(1 - compressed_size/normal_size)*100:.1f}%")


def demo_configuration():
    """
    演示配置功能
    
    内容：
    - 默认配置
    - 高性能配置
    - 低内存配置
    - 自定义配置
    """
    print_section("9. 配置选项演示")
    
    # 默认配置
    default_config = Mf4Config.default()
    print(f"\n默认配置:")
    print(f"  缓冲区大小: {default_config.buffer_size}")
    print(f"  缓存大小: {default_config.cache_size_mb} MB")
    print(f"  写入时验证: {default_config.validate_on_write}")
    
    # 高性能配置
    hp_config = Mf4Config.high_performance()
    print(f"\n高性能配置:")
    print(f"  缓冲区大小: {hp_config.buffer_size}")
    print(f"  缓存大小: {hp_config.cache_size_mb} MB")
    print(f"  最大工作线程: {hp_config.max_workers}")
    
    # 低内存配置
    lm_config = Mf4Config.low_memory()
    print(f"\n低内存配置:")
    print(f"  缓冲区大小: {lm_config.buffer_size}")
    print(f"  缓存大小: {lm_config.cache_size_mb} MB")
    
    # 自定义配置
    custom_config = Mf4Config(
        buffer_size=30000,
        cache_size_mb=200,
        validate_on_write=False
    )
    print(f"\n自定义配置:")
    print(f"  缓冲区大小: {custom_config.buffer_size}")
    print(f"  缓存大小: {custom_config.cache_size_mb} MB")


def main():
    """运行所有演示"""
    print("\n" + "=" * 60)
    print("  MF4 SDK 完整功能演示")
    print("  基于 asammdf 库")
    print("=" * 60)
    
    start_time = time.time()
    
    try:
        # 写入演示
        basic_file = demo_write_basic()
        multi_file = demo_write_multiple_signals()
        
        # 读取演示
        demo_read_basic(basic_file)
        demo_read_time_range(basic_file)
        demo_filter_channels(multi_file)
        demo_streaming_read(multi_file)
        
        # 转换演示
        demo_format_conversion(multi_file)
        
        # 其他功能
        demo_with_compression()
        demo_configuration()
        
        # 完成
        elapsed_time = time.time() - start_time
        
        print("\n" + "=" * 60)
        print("  演示完成!")
        print(f"  耗时: {elapsed_time:.2f} 秒")
        print("=" * 60 + "\n")
        
    except Exception as e:
        print(f"\n错误: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    sys.exit(main())