"""
MF4 SDK 基本使用示例

演示如何读取和写入 MF4 文件。
"""

import numpy as np
from mf4 import Mf4Reader, Mf4Writer, Mf4Config
from mf4.enums import DataType, CompressionType


def basic_write_example():
    """
    基本写入示例
    
    演示如何创建一个简单的 MF4 文件。
    """
    print("=== 基本写入示例 ===")
    
    # 创建 MF4 文件
    with Mf4Writer.create("output_basic.mf4") as writer:
        # 设置文件头信息
        writer.set_header(
            author="John Doe",
            organization="Example Corp",
            project="Engine Testing",
            comment="Sample measurement data"
        )
        
        # 添加通道组
        cg_id = writer.add_channel_group(
            "Engine_Data",
            comment="Engine measurement parameters"
        )
        
        # 添加测量通道
        writer.add_channel(
            cg_id,
            name="Engine_Speed",
            unit="rpm",
            data_type=DataType.FLOAT64,
            comment="Engine rotational speed"
        )
        
        writer.add_channel(
            cg_id,
            name="Vehicle_Speed",
            unit="km/h",
            data_type=DataType.FLOAT64,
            comment="Vehicle speed"
        )
        
        writer.add_channel(
            cg_id,
            name="Throttle_Position",
            unit="%",
            data_type=DataType.FLOAT64,
            comment="Throttle position percentage"
        )
        
        # 生成模拟数据
        sample_count = 1000
        timestamps = np.linspace(0, 10, sample_count)  # 10秒测量
        
        # 模拟发动机转速（带噪声的正弦波动）
        base_speed = 3000
        amplitude = 500
        noise = np.random.normal(0, 50, sample_count)
        engine_speed = base_speed + amplitude * np.sin(timestamps) + noise
        
        # 模拟车速
        vehicle_speed = np.random.uniform(0, 120, sample_count)
        
        # 模拟油门位置
        throttle = np.random.uniform(0, 100, sample_count)
        
        # 写入数据
        writer.write_data(
            cg_id,
            timestamps,
            {
                "Engine_Speed": engine_speed,
                "Vehicle_Speed": vehicle_speed,
                "Throttle_Position": throttle
            }
        )
    
    print("文件已创建: output_basic.mf4")


def basic_read_example():
    """
    基本读取示例
    
    演示如何读取 MF4 文件中的数据。
    """
    print("\n=== 基本读取示例 ===")
    
    try:
        with Mf4Reader.open("output_basic.mf4") as reader:
            # 获取文件头信息
            header = reader.header
            print(f"文件版本: {header.version}")
            print(f"作者: {header.author}")
            print(f"组织: {header.organization}")
            
            # 获取所有通道
            channels = reader.get_channels()
            print(f"\n通道数量: {len(channels)}")
            
            for ch in channels:
                print(f"  - {ch.name} ({ch.unit})")
            
            # 读取特定通道数据
            signal = reader.read_channel("Engine_Speed")
            print(f"\nEngine_Speed 数据点数: {len(signal)}")
            
            # 计算统计信息
            stats = signal.get_statistics()
            print(f"最小值: {stats['min']:.2f} rpm")
            print(f"最大值: {stats['max']:.2f} rpm")
            print(f"平均值: {stats['mean']:.2f} rpm")
            print(f"标准差: {stats['std']:.2f} rpm")
            
    except FileNotFoundError:
        print("错误: 请先运行写入示例创建文件")


def compressed_write_example():
    """
    压缩写入示例
    
    演示如何创建带压缩的 MF4 文件。
    """
    print("\n=== 压缩写入示例 ===")
    
    config = Mf4Config.high_performance()
    
    with Mf4Writer.create(
        "output_compressed.mf4",
        compression=CompressionType.DEFLATE
    ) as writer:
        writer.set_header(author="Compression Test")
        
        cg_id = writer.add_channel_group("Large_Data")
        writer.add_channel(cg_id, "Signal", unit="V")
        
        # 创建大量数据
        timestamps = np.linspace(0, 100, 10000)
        values = np.sin(timestamps)
        
        writer.write_data(cg_id, timestamps, {"Signal": values})
    
    print("压缩文件已创建: output_compressed.mf4")


def query_example():
    """
    查询示例
    
    演示如何使用查询功能。
    """
    print("\n=== 查询示例 ===")
    
    try:
        with Mf4Reader.open("output_basic.mf4") as reader:
            # 过滤通道
            channels = reader.filter_channels(name_pattern="Engine_*")
            print(f"匹配 'Engine_*' 的通道: {len(channels)}")
            
            for ch in channels:
                print(f"  - {ch.name}")
                
    except FileNotFoundError:
        print("错误: 请先运行写入示例创建文件")


if __name__ == "__main__":
    # 运行所有示例
    basic_write_example()
    basic_read_example()
    compressed_write_example()
    query_example()
    
    print("\n示例完成！")