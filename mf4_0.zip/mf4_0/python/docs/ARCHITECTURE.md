# MF4 SDK 技术文档

> 版本: 1.0.0  
> 基于 ASAM MDF 4.x 规范，底层依赖 asammdf 库

---

## 目录

1. [项目概述](#1-项目概述)
2. [架构设计](#2-架构设计)
3. [目录结构](#3-目录结构)
4. [核心模块详解](#4-核心模块详解)
   - 4.1 [标准读写 (reader / writer)](#41-标准读写)
   - 4.2 [大文件处理 (large_file)](#42-大文件处理)
   - 4.3 [统一存储接口 (storage)](#43-统一存储接口)
   - 4.4 [流式读写 (streaming_reader / streaming_writer)](#44-流式读写)
   - 4.5 [格式转换 (converter)](#45-格式转换)
5. [数据模型层 (model)](#5-数据模型层)
6. [枚举类型 (enums)](#6-枚举类型)
7. [异常体系 (exceptions)](#7-异常体系)
8. [配置系统 (config)](#8-配置系统)
9. [工具模块 (utils)](#9-工具模块)
10. [测试体系](#10-测试体系)
11. [依赖关系](#11-依赖关系)
12. [已知的局限与待完善项](#12-已知的局限与待完善项)

---

## 1. 项目概述

MF4 SDK 是一个用于读写 MF4 (Measurement Data Format 4) 文件的 Python 库，面向汽车测量数据、工业传感器数据等场景。MF4 是 ASAM (Association for Standardization of Automation and Measuring Systems) 定义的 MCD-2 MC 标准文件格式，广泛用于车辆 ECU 标定、台架测试、道路试验等数据记录。

### 1.1 核心能力

| 能力 | 说明 |
|------|------|
| 标准 MF4 读写 | 基于 asammdf 的完整 MF4 4.x 读写 |
| 大文件分片存储 | 自动将大数据集拆分为多个分片文件，每个 ≤ 可配置阈值 (默认 1GB) |
| 并行写入 | 多线程并行处理数据分片 |
| 异步写入 | 后台线程写入，主线程不阻塞 |
| 流式读取 | 批量迭代读取，避免全量加载到内存 |
| 格式转换 | 导出为 CSV / Parquet / HDF5 / Excel / JSON |
| 统一存储接口 | 通过 `storage_mode` 配置项透明切换单文件/分片模式 |
| 信号追加 | 向已存在的 MF4 文件追加新的信号通道 |

### 1.2 性能目标

| 指标 | 目标值 |
|------|--------|
| 1GB 数据写入 | < 3 秒 |
| 流式读取速度 | ~350 MB/s |
| 内存峰值 | < 500 MB |
| 支持文件大小 | ≤ 50 GB (可配置) |

### 1.3 运行环境

- Python >= 3.8
- 核心依赖: `asammdf >= 7.0.0`, `numpy >= 1.20.0`
- 可选依赖: `pandas`, `pyarrow`, `h5py`, `openpyxl`

---

## 2. 架构设计

### 2.1 分层架构

```
┌─────────────────────────────────────────────────┐
│              用户代码 (User Code)                 │
├─────────────────────────────────────────────────┤
│         统一接口层 (Unified API)                  │
│    UnifiedWriter  ·  UnifiedReader               │
├──────────┬──────────┬───────────────────────────┤
│ 标准 I/O │ 大文件   │  流式 I/O                  │
│ Mf4Writer│ LargeFile│  Mf4StreamingReader        │
│ Mf4Reader│ Writer   │  Mf4StreamingWriter        │
│          │ LargeFile│                            │
│          │ Reader   │  格式转换                   │
│          │          │  Mf4Converter               │
├──────────┴──────────┴───────────────────────────┤
│           数据模型层 (Data Models)                │
│  FileHeader · Channel · ChannelGroup · Signal    │
│  ChannelConversion · DataGroup · Attachment      │
├─────────────────────────────────────────────────┤
│           基础设施层 (Infrastructure)             │
│  Mf4Config · Enums · Exceptions · Utils          │
├─────────────────────────────────────────────────┤
│           第三方库 (Third-party)                  │
│           asammdf · numpy                        │
└─────────────────────────────────────────────────┘
```

### 2.2 核心设计决策

1. **asammdf 封装而非重写**: 标准 MF4 读写直接委托给 asammdf，利用其成熟的 MDF 4.x 解析能力。大文件模块在其之上构建分片/并行/异步层。

2. **分片子目录隔离**: 大文件模式的分片存储在 `{base_path}_shards/` 子目录中，索引文件 `{base_path}.index` 放在父目录。避免与单文件模式产生的 `.mf4` 文件混淆。

3. **配置驱动模式切换**: `Mf4Config.storage_mode` 字段 (`"single"` / `"sharded"`) 控制统一接口的底层实现，用户代码无需感知具体存储方式。

4. **惰性加载**: `Mf4Reader` 的文件头信息、通道列表等使用缓存 + 惰性加载模式，首次访问时从 MDF 对象提取，后续访问直接返回缓存。

5. **信号缓冲 + 智能分组**: `LargeFileWriter` 内部维护批次缓冲区，刷新时按时间戳签名自动分组合并——共享相同时间戳且无通道重叠的批次会合并为一次写入，避免时间戳重复。

---

## 3. 目录结构

```
python/
├── README.md                  # 项目说明
├── setup.py                   # 安装配置 (pip install .)
├── requirements.txt           # 依赖清单
├── docs/
│   └── LARGE_FILE.md          # 大文件模块详细文档
├── examples/
│   ├── basic_usage.py         # 基本用法示例
│   ├── complete_demo.py       # 完整功能演示
│   └── large_file_demo.py     # 大文件性能演示
├── mf4/
│   ├── __init__.py            # 包入口，统一导出所有公开符号
│   ├── reader.py              # Mf4Reader — 标准文件读取器
│   ├── writer.py              # Mf4Writer — 标准文件写入器
│   ├── converter.py           # Mf4Converter — 格式转换器
│   ├── storage.py             # UnifiedWriter/Reader — 统一存储接口
│   ├── large_file.py          # 大文件分片读写（核心模块）
│   ├── streaming_reader.py    # Mf4StreamingReader — 流式读取器
│   ├── streaming_writer.py    # Mf4StreamingWriter — 流式写入器（骨架）
│   ├── config/
│   │   └── __init__.py        # Mf4Config 配置类
│   ├── enums/
│   │   └── __init__.py        # 枚举类型定义
│   ├── exceptions/
│   │   └── __init__.py        # 异常类层次
│   ├── model/
│   │   ├── __init__.py        # 模型包入口
│   │   ├── file_header.py     # FileHeader
│   │   ├── data_group.py      # DataGroup
│   │   ├── channel_group.py   # ChannelGroup
│   │   ├── channel.py         # Channel
│   │   ├── channel_conversion.py # ChannelConversion
│   │   ├── signal.py          # Signal
│   │   ├── attachment.py      # Attachment
│   │   └── metadata.py        # Metadata
│   └── utils/
│       └── byte_utils.py      # 二进制 I/O 工具函数
└── tests/
    ├── conftest.py            # pytest fixtures
    ├── test_complete.py       # 完整功能测试
    ├── test_append.py         # 信号追加测试
    ├── test_large_file.py     # 大文件 + 统一接口测试
    ├── integration/
    │   └── test_reader_writer.py
    └── unit/
        ├── test_config.py
        ├── test_enums.py
        ├── test_exceptions.py
        └── test_models.py
```

---

## 4. 核心模块详解

### 4.1 标准读写

#### 4.1.1 Mf4Writer (`mf4/writer.py`)

基于 asammdf 的 MDF 类实现的标准 MF4 文件写入器。

**构造参数**:

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `file_path` | `str` | — | 输出文件路径 |
| `version` | `str` | `"4.10"` | MF4 版本，支持 `4.00`/`4.10`/`4.11`/`4.20` |
| `compression` | `bool` | `False` | 是否启用压缩 |
| `config` | `Mf4Config` | `None` | 配置实例 |

**核心方法**:

```python
# 上下文管理器方式创建（推荐）
with Mf4Writer.create("output.mf4") as writer:
    writer.set_header(author="Tester", project="Demo")
    writer.add_signal("Speed", timestamps, values, unit="rpm")
```

| 方法 | 说明 |
|------|------|
| `create(file_path, ...)` | 类方法，上下文管理器工厂，退出时自动保存关闭 |
| `set_header(**kwargs)` | 设置文件头: `author`, `organization`, `project`, `subject`, `comment` |
| `add_signal(name, timestamps, values, unit, comment)` | 添加单个信号，内部创建 `asammdf.Signal` 对象并调用 `mdf.append()` |
| `add_signals(timestamps, signals, units, comments)` | 批量添加，signals 为 `Dict[str, np.ndarray]` |
| `write_data(cg_id, timestamps, data, units)` | `add_signals` 的兼容别名，cg_id 在 asammdf 中被忽略 |
| `add_channel_group(name, comment)` | 添加通道组（asammdf 自动管理，此方法主要用于兼容性） |
| `add_channel(cg_id, name, unit, ...)` | 添加通道定义（仅记录元数据，不写数据） |
| `add_attachment(filename, content, mime_type, comment)` | 嵌入附件到 MF4 文件 |
| `save()` | 将数据写入磁盘（追加模式先写临时文件再替换） |
| `open_for_append(file_path)` | 类方法，打开已存在文件进行追加 |
| `append_signal(name, timestamps, values, unit, comment)` | 追加模式下的信号写入（语义别名） |
| `get_existing_channels()` | 返回已存在通道名称列表 |
| `channel_exists(name)` | 检查通道是否已存在 |

**追加模式实现**: `open_for_append` 打开已有 MDF 文件，新信号通过 `mdf.append()` 追加，保存时先写入临时文件 `._temp_` 再 `os.replace` 替换原文件，保证原子性。

**信号验证** (`_validate_signal`): 当 `config.validate_on_write=True` 时检查:
- 名称非空
- timestamps 与 values 长度一致
- 时间戳单调递增
- 严格模式下检查 NaN 值

#### 4.1.2 Mf4Reader (`mf4/reader.py`)

**构造参数**:

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `file_path` | `str` | — | MF4 文件路径 |
| `config` | `Mf4Config` | `None` | 配置实例 |

构造时即验证文件存在性、可读性和大小限制。

**核心方法**:

```python
with Mf4Reader.open("measurement.mf4") as reader:
    header = reader.header               # 惰性加载的 FileHeader
    channels = reader.get_channels()     # 缓存的 Channel 列表
    signal = reader.read_channel("Speed") # 读取为 Signal 对象
    df = reader.to_dataframe()           # 导出 pandas DataFrame
```

| 方法 | 说明 |
|------|------|
| `open(file_path, config)` | 类方法，上下文管理器工厂 |
| `header` (property) | 惰性加载的 `FileHeader`，从 MDF 属性提取 |
| `get_channels()` | 返回 `List[Channel]`，结果缓存 |
| `get_channel(name)` | 返回单个 `Channel`，不存在则抛 `Mf4ChannelNotFoundError` |
| `read_channel(name, start_time, end_time)` | 读取通道数据为 `Signal`，可选时间范围过滤 |
| `read_channels(names, start_time, end_time)` | 批量读取，返回 `Dict[str, Signal]` |
| `filter_channels(name_pattern, unit, data_type)` | 通配符/单位/类型过滤，使用 `fnmatch` |
| `get_channel_groups()` | 返回 `List[ChannelGroup]` |
| `to_dataframe(channels, start_time, end_time)` | 导出为 `pandas.DataFrame` |

**实现细节**:
- 使用 `MDF(path, read_minimum=True)` 打开文件，最小化初始读取
- `header`、`channels`、`groups` 均采用惰性加载 + 缓存策略
- `read_channel` 先 `mdf.get(name)` 获取 asammdf Signal，再用布尔掩码过滤时间范围

---

### 4.2 大文件处理

#### 4.2.1 整体架构

```
LargeFileWriter
  ├── WriteQueue              异步写入队列 (可选)
  ├── ParallelWorker          并行线程池
  ├── 缓冲区 (_buffer_batches) 批次缓冲
  └── FileIndex               分片索引

LargeFileReader
  ├── FileIndex                加载/自动发现索引
  └── ThreadPoolExecutor       并行读取
```

**文件布局**:

```
parent_dir/
├── {base_path}.index              # JSON 索引文件
└── {base_path}_shards/            # 分片子目录
    ├── {base_path}_shard_0000.mf4
    ├── {base_path}_shard_0001.mf4
    └── ...
```

#### 4.2.2 LargeFileConfig

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `max_shard_size_mb` | `int` | `1024` | 单分片最大容量 (MB) |
| `parallel_workers` | `int` | `0` | 并行线程数，0=自动 (min(cpu_count, 8)) |
| `enable_async` | `bool` | `True` | 是否启用异步写入 |
| `buffer_size_mb` | `int` | `100` | 写入缓冲区大小 (MB) |
| `compression` | `bool` | `False` | 是否压缩 |
| `index_enabled` | `bool` | `True` | 是否生成分片索引 |
| `chunk_size` | `int` | `50000` | 数据分块大小 (记录数) |
| `timeout_seconds` | `int` | `30` | 操作超时 |
| `max_memory_mb` | `int` | `500` | 最大内存限制 |
| `storage_mode` | `str` | `"sharded"` | 存储模式 (single/sharded) |

**预设配置**:
- `LargeFileConfig.high_performance()`: 大缓冲(200MB), 多线程(up to 16), 大分块(100K)
- `LargeFileConfig.low_memory()`: 小缓冲(50MB), 2线程, 小分块(20K), 最大内存200MB

#### 4.2.3 LargeFileWriter

```python
with LargeFileWriter.create("data/large", config=LargeFileConfig.high_performance()) as writer:
    writer.set_header(author="Perf Test")
    for batch in data_batches:
        writer.add_signals(batch["timestamps"], batch["signals"], batch["units"])
```

**写入流程**:

```
add_signal / add_signals
        │
        ▼
   ┌─ 缓冲区 (_buffer_batches) ─┐
   │  [{timestamps, signals}, ...] │
   └────────────┬───────────────┘
                │ _should_flush() == True
                ▼
         _flush_buffer()
                │
        _group_batches_by_timestamps()
        (合并相同时间戳且无通道重叠的批次)
                │
        ┌───────┴───────┐
        │               │
   enable_async?    同步写入
   _write_queue     _write_shard_sync()
   .put()                 │
        │           创建 MDF → append Signal → save
   后台线程               │
   writer_loop()    更新 FileIndex
                │
                ▼
         close() 时
         刷新剩余缓冲 → 等待异步完成 → 保存索引 JSON
```

**缓冲区分组逻辑** (`_group_batches_by_timestamps`):

当通过 `add_signal` 逐个添加共享同一时间戳的信号时，缓冲区会收到多个批次，每个批次包含一个信号。`_flush_buffer` 会检测这些批次的「时间戳签名」`(长度, 起始值, 终止值)` 和通道重叠情况，将时间戳相同且无重叠的批次合并为一组，共享同一份时间戳数组写入 MDF。这避免了时间戳被重复连接导致与信号数据长度不匹配的问题。

**分片路径生成** (`_get_shard_path`):

```
base_path = "data/large"
_shard_dir = "data/large_shards"
shard_path = "data/large_shards/large_shard_0000.mf4"
```

**索引文件格式** (JSON):

```json
{
  "base_path": "data/large",
  "shards": [
    {
      "shard_id": 0,
      "file_path": "data/large_shards/large_shard_0000.mf4",
      "start_time": 0.0,
      "end_time": 9.99999,
      "record_count": 100000,
      "file_size": 16006296,
      "channels": ["Speed", "Temp"],
      "created_at": "2026-04-07T00:00:00+00:00"
    }
  ],
  "total_records": 500000,
  "total_size": 80031480,
  "all_channels": ["Speed", "Temp"]
}
```

#### 4.2.4 LargeFileReader

```python
with LargeFileReader.open("data/large") as reader:
    print(reader.shard_count)         # 分片数
    data = reader.read_shard(0)       # 读取单个分片
    data = reader.read_time_range(5.0, 15.0)  # 时间范围查询
    for shard in reader.iter_shards(): # 迭代所有分片
        process(shard)
    results = reader.read_parallel()  # 并行读取所有分片
```

**分片发现策略** (`_discover_shards`):

1. 优先检查 `{base_path}_shards/` 子目录
2. 若子目录存在，扫描其中匹配 `{basename}_shard_NNNN.mf4` 的文件
3. 若子目录不存在，回退到旧版扁平布局 (`{base_path}_shard_NNNN.mf4`)
4. 对每个分片文件打开 MDF 提取元数据构建 `FileIndex`

**辅助类**:

| 类 | 说明 |
|------|------|
| `ShardIndex` | 单个分片的元数据 (ID, 路径, 时间范围, 记录数, 文件大小, 通道列表) |
| `FileIndex` | 所有分片索引的容器，支持按时间戳查找分片 |
| `WriteQueue` | 基于 `queue.Queue` 的线程安全异步写入队列 |
| `ParallelWorker` | `ThreadPoolExecutor` 封装 |

---

### 4.3 统一存储接口

#### 4.3.1 设计目标

使用户代码通过同一个 API 透明切换 `"single"` 和 `"sharded"` 两种存储模式，仅在配置项中指定即可。

#### 4.3.2 UnifiedWriter

```python
from mf4.storage import UnifiedWriter
from mf4.config import Mf4Config

config = Mf4Config(storage_mode="sharded")  # 或 "single"
with UnifiedWriter.create("output.mf4", config=config) as writer:
    writer.set_header(author="Test")
    writer.add_signal("Speed", timestamps, values, unit="rpm")
    writer.add_signals(timestamps, {"Temp": temp_values})
```

**接口方法**:

| 方法 | 说明 | single 模式 | sharded 模式 |
|------|------|------------|-------------|
| `set_header(**kwargs)` | 设置头信息 | → `Mf4Writer.set_header` | → `LargeFileWriter.set_header` |
| `add_signal(name, ts, vals, unit, comment)` | 添加信号 | → `Mf4Writer.add_signal` | → `LargeFileWriter.add_signal` |
| `add_signals(ts, signals, units, comments)` | 批量添加 | → `Mf4Writer.add_signals` | → `LargeFileWriter.add_signals` |
| `add_channel_group(name, comment)` | 添加通道组 | → `Mf4Writer` | 返回 0 (忽略) |
| `add_channel(cg_id, name, unit, comment)` | 添加通道 | → `Mf4Writer` | 返回 0 (忽略) |
| `write_data(cg_id, ts, data, units)` | 写入数据 | → `Mf4Writer.write_data` | → `LargeFileWriter.add_signals` |
| `storage_mode` (property) | 当前模式 | `"single"` | `"sharded"` |
| `underlying_writer` (property) | 底层写入器 | `Mf4Writer` 实例 | `LargeFileWriter` 实例 |

**配置转换** (`_mf4_config_to_large_config`):

将 `Mf4Config` 参数映射为 `LargeFileConfig`:
- `max_workers` → `parallel_workers`
- `max_workers != 1` → `enable_async`
- `cache_size_mb` → `buffer_size_mb`
- `batch_write_size` → `chunk_size`

#### 4.3.3 UnifiedReader

```python
with UnifiedReader.open("output.mf4", config=config) as reader:
    channels = reader.get_channels()
    signal = reader.read_channel("Speed")
    info = reader.get_info()
```

| 方法 | 说明 | single | sharded |
|------|------|--------|---------|
| `get_channels()` | 获取通道列表 | `List[Channel]` | `List[str]` (通道名) |
| `read_channel(name, start, end)` | 读取信号 | → `Mf4Reader.read_channel` | 遍历分片合并数据 |
| `read_channels(names, start, end)` | 批量读取 | 逐一调用 `read_channel` | 同左 |
| `get_info()` | 文件信息 | `{file_path, channels, storage_mode}` | → `LargeFileReader.get_info` |
| `header` (property) | 文件头 | → `Mf4Reader.header` | `None` |
| `storage_mode` (property) | 当前模式 | `"single"` | `"sharded"` |
| `underlying_reader` (property) | 底层读取器 | `Mf4Reader` | `LargeFileReader` |

**sharded 模式的 read_channel 实现**:
- 若指定了 `start_time` 和 `end_time`，使用 `reader.read_time_range()` 限定范围
- 否则遍历所有分片 (`iter_shards`)，逐片提取目标通道数据，最终 `np.concatenate` 合并

---

### 4.4 流式读写

#### 4.4.1 Mf4StreamingReader (`mf4/streaming_reader.py`)

面向大文件的批量迭代读取器，避免全量加载。

```python
with Mf4StreamingReader.open("large.mf4", channels=["Speed"], buffer_size=5000) as reader:
    for batch in reader.read_batches(batch_size=10000):
        process(batch)  # Dict[str, np.ndarray]

    for signal in reader.iter_signals():
        print(signal.name, len(signal))  # Signal 对象
```

| 方法 | 说明 |
|------|------|
| `open(file_path, channels, buffer_size, config)` | 上下文管理器工厂 |
| `read_batches(batch_size, start_time, end_time)` | 按批次 yield 数据字典 |
| `iter_signals(start_time, end_time)` | 逐信号 yield `Signal` 对象 |
| `get_progress()` | 返回读取进度 0.0-1.0 |

**实现**: 打开时使用 `read_minimum=True`，`read_batches` 内部先读取完整信号再按 `batch_size` 切片，不是真正的流式 I/O，但对外提供了分批处理的接口。

#### 4.4.2 Mf4StreamingWriter (`mf4/streaming_writer.py`)

**当前为骨架实现**，仅维护内存缓冲区，`write()` 添加记录，`flush()` 清空缓冲。未实际写入 MF4 文件。

---

### 4.5 格式转换

#### Mf4Converter (`mf4/converter.py`)

```python
converter = Mf4Converter("measurement.mf4")
converter.to_csv("output.csv", channels=["Speed"])
converter.to_parquet("output.parquet")
converter.to_hdf5("output.h5")
converter.to_excel("output.xlsx", max_rows=50000)
converter.to_json("output.json")
converter.close()
```

| 方法 | 说明 | 额外依赖 |
|------|------|---------|
| `to_csv(output_path, channels, delimiter, include_timestamp, time_column, start_time, end_time, max_rows)` | 手动逐行写入 CSV | 无 |
| `to_parquet(output_path, channels, compression, start_time, end_time)` | 导出 Parquet | `pandas`, `pyarrow` |
| `to_hdf5(output_path, channels, group_path, compression, start_time, end_time)` | 导出 HDF5，保留单位/注释属性 | `h5py` |
| `to_excel(output_path, channels, max_rows, start_time, end_time)` | 导出 Excel，有行数限制 | `pandas`, `openpyxl` |
| `to_json(output_path, channels, orient, start_time, end_time, max_rows)` | 导出 JSON | `pandas` |
| `get_info()` | 返回文件版本、通道数、组数 | 无 |

**CSV 实现**: 直接使用 Python 文件 I/O 写入，不依赖 pandas。支持自定义分隔符、时间戳列名、时间范围过滤和行数限制。

**HDF5 实现**: 使用 h5py 在指定 group_path 下创建 `timestamp` dataset 和各通道 dataset，通道的单位 (unit) 和注释 (comment) 存为 HDF5 属性。

---

## 5. 数据模型层

所有模型定义在 `mf4/model/` 下，使用 `@dataclass` 装饰器，与 ASAM MDF 4.x 规范中的概念对应。

### 5.1 Signal (`signal.py`)

```python
signal = Signal(name="Speed", timestamps=ts, values=vals, unit="rpm")
len(signal)                       # 数据点数
signal.get_sample_rate()          # 采样率 (Hz)
signal.get_statistics()           # {min, max, mean, std, count}
signal.get_value_at_time(5.0)     # 线性插值获取指定时刻值
```

### 5.2 Channel (`channel.py`)

```python
channel = Channel(name="Speed", unit="rpm", data_type=DataType.FLOAT64)
channel.get_byte_size()           # 数据类型字节大小
channel.get_numpy_dtype()         # 对应的 numpy dtype 字符串
channel.validate()                # 验证通道元数据
```

### 5.3 ChannelConversion (`channel_conversion.py`)

支持 MDF 标准的转换公式:

| 类型 | 公式 | `apply(value)` | `inverse(value)` |
|------|------|---------------|-----------------|
| `NONE` | y = x | 直接返回 | 直接返回 |
| `LINEAR` | y = ax + b | `a*value + b` | `(value - b) / a` |
| `RATIONAL` | y = (ax + b) / (cx + d) | 计算 | `(d*value - b) / (a - c*value)` |
| `TABULAR` | 查表插值 | 线性插值 | 不支持 |

### 5.4 ChannelGroup (`channel_group.py`)

通道组，包含一组共享时间轴的 Channel。提供 `add_channel()`, `get_channel()`, `get_time_channel()` 方法。

### 5.5 DataGroup (`data_group.py`)

数据组，包含多个 ChannelGroup。提供 `add_channel_group()`, `get_all_channels()` 方法。

### 5.6 FileHeader (`file_header.py`)

| 字段 | 默认值 | 说明 |
|------|--------|------|
| `version` | `"4.10"` | MF4 版本 |
| `program_id` | `"MF4SDK"` | 生成程序标识 |
| `author` | `""` | 作者 |
| `organization` | `""` | 组织 |
| `project` | `""` | 项目 |
| `subject` | `""` | 主题 |
| `comment` | `""` | 注释 |
| `start_time` | `datetime.now(UTC)` | 开始时间 |
| `end_time` | `None` | 结束时间 |
| `file_uuid` | `uuid4()` | 文件唯一标识 |

`validate()` 检查版本号合法性、时间顺序、UUID 格式。

### 5.7 Attachment (`attachment.py`)

嵌入式附件，包含 `filename`, `content: bytes`, `mime_type`, `create_time`。支持 `save_to(path)` 写出到磁盘。

### 5.8 Metadata (`metadata.py`)

通用键值元数据容器，提供 `add/get/remove/keys/to_dict` 方法。

---

## 6. 枚举类型

定义在 `mf4/enums/__init__.py`。

| 枚举 | 基类 | 值 | 说明 |
|------|------|----|------|
| `DataType` | `IntEnum` | `UINT8(0)` ~ `BOOL(14)` | 15 种 MDF 数据类型 |
| `ChannelType` | `IntEnum` | `VALUE(0)`, `MASTER(1)`, `VIRTUAL_MASTER(2)`, `SYNC(3)` | 通道角色 |
| `ConversionType` | `IntEnum` | `NONE(0)` ~ `DATE(6)` | 7 种转换公式类型 |
| `CompressionType` | `Enum` | `NONE`, `DEFLATE`, `LZ4` | 压缩算法 |
| `SourceType` | `Enum` | `SENSOR`, `CALCULATED`, `IMPORTED`, `SIMULATED` | 数据来源 |
| `BlockType` | `Enum` | `ID`, `HD`, `DG`, `CG`, `CN`, `CC`, `TX`, `SR`, `AT` | MDF 块类型标识 |

`DataType` 的关键方法:
- `from_mdf_code(code: int)`: 从 MDF 整数编码创建枚举
- `to_numpy_dtype() -> str`: 转换为 numpy dtype 字符串（如 `"float64"`, `"int32"`）
- `get_byte_size() -> int`: 返回数据类型占用的字节数（字符串类型返回 0）

---

## 7. 异常体系

定义在 `mf4/exceptions/__init__.py`，继承层次:

```
Mf4Error (基类)
├── Mf4FileNotFoundError         文件不存在
├── Mf4CorruptedFileError        文件损坏 (含 block_type, offset)
├── Mf4UnsupportedVersionError   版本不支持 (含 version, supported_versions)
├── Mf4PermissionError           权限错误 (含 operation)
├── Mf4ChannelNotFoundError      通道不存在 (含 channel_name, available_channels)
├── Mf4DataGroupNotFoundError    数据组不存在 (含 data_group_id)
├── Mf4ValidationError           数据验证失败 (含 validation_errors 列表)
├── Mf4ParseError                解析错误 (含 block_type, offset)
├── Mf4WriteError                写入错误
└── Mf4ConversionError           转换错误 (含 conversion_type, raw_value)
```

所有异常都携带 `message` 和可选的 `file_path`、`details` 字段，提供上下文信息。

---

## 8. 配置系统

### 8.1 Mf4Config (`mf4/config/__init__.py`)

| 配置项 | 类型 | 默认值 | 说明 |
|--------|------|--------|------|
| `buffer_size` | `int` | `10000` | I/O 缓冲区大小 (记录数)，范围 [100, 1000000] |
| `use_memory_mapping` | `bool` | `True` | 是否使用内存映射 |
| `cache_enabled` | `bool` | `True` | 是否启用元数据缓存 |
| `cache_size_mb` | `int` | `100` | 缓存上限 (MB)，范围 [10, 1000] |
| `cache_strategy` | `str` | `"lru"` | 缓存淘汰策略: `lru` / `lfu` |
| `max_workers` | `int` | `0` | 最大并行线程数，0=自动检测 |
| `prefetch_size` | `int` | `3` | 预取批次数 |
| `batch_write_size` | `int` | `50000` | 批量写入大小 (记录数) |
| `validate_on_read` | `bool` | `False` | 读取时验证 |
| `validate_on_write` | `bool` | `True` | 写入时验证 |
| `strict_mode` | `bool` | `False` | 严格模式 (检查 NaN 等) |
| `log_level` | `str` | `"INFO"` | 日志级别 |
| `log_file` | `str` | `None` | 日志文件路径 |
| `tolerant_mode` | `bool` | `True` | 容忍非标准格式 |
| `max_file_size_gb` | `float` | `50.0` | 文件大小上限 (GB) |
| `storage_mode` | `str` | `"single"` | 存储模式: `"single"` / `"sharded"` |
| `file_handle_timeout` | `int` | `300` | 文件句柄超时 (秒) |
| `custom` | `Dict` | `{}` | 自定义扩展配置 |

**预设配置**:
- `Mf4Config.default()`: 默认配置
- `Mf4Config.high_performance()`: 大缓冲 (50K), 大缓存 (500MB), 8线程, 关闭验证
- `Mf4Config.low_memory()`: 小缓冲 (1K), 小缓存 (20MB), 单线程

**创建方式**:
```python
config = Mf4Config(buffer_size=20000, storage_mode="sharded")
config = Mf4Config.from_env()         # 从 MF4_* 环境变量
config = config.merge(cache_size_mb=200)  # 合并覆盖
d = config.to_dict()                  # 序列化为字典
```

**环境变量映射**: `MF4_BUFFER_SIZE`, `MF4_STORAGE_MODE`, `MF4_CACHE_SIZE_MB` 等。

---

## 9. 工具模块

### byte_utils (`mf4/utils/byte_utils.py`)

面向 MF4 二进制格式底层 I/O 的工具函数集，所有函数使用小端字节序 (`BYTE_ORDER = '<'`)。

**读取函数**: `read_uint8/16/32/64`, `read_int8/16/32/64`, `read_float32/64`, `read_string`, `read_bytes`

**写入函数**: `write_uint8/16/32/64`, `write_int8/16/32/64`, `write_float32/64`, `write_string`, `write_bytes`

**时间转换**: `mdf_timestamp_to_datetime(ns)`, `datetime_to_mdf_timestamp(dt)` — MDF 使用纳秒级 Unix 时间戳

**位操作**: `get_bit_value(data, byte_offset, bit_offset, bit_count)` — 从字节数据中提取指定位域

---

## 10. 测试体系

### 10.1 测试结构

| 文件 | 类 | 测试数 | 覆盖范围 |
|------|-----|--------|---------|
| `test_complete.py` | `TestMf4Writer` | 4 | 写入基本/多信号/压缩/大文件 |
| | `TestMf4Reader` | 7 | 头信息/通道列表/数据读取/批量/异常/过滤/DataFrame |
| | `TestMf4Converter` | 2 | CSV/JSON 转换 |
| | `TestMf4StreamingReader` | 2 | 批量读取/信号迭代 |
| | `TestConfiguration` | 9 | 默认/高性能/低内存/自定义配置 + storage_mode |
| | `TestEndToEnd` | 2 | 写读周期/工作流 |
| `test_append.py` | `TestSignalAppend` | 6 | 追加/多信号/数据保持/通道列表/存在检查/循环 |
| | `TestAppendPerformance` | 1 | 大数据追加性能 |
| `test_large_file.py` | `TestLargeFilePerformance` | 5 | 写入性能/分片/并行/异步/内存 |
| | `TestLargeFileReader` | 5 | 信息/分片/时间范围/迭代/并行 |
| | `TestWriteTimeConstraint` | 1 | 1GB 写入时间约束 |
| | `TestShardDirectory` | 3 | 子目录创建/读取/父目录清洁 |
| | `TestUnifiedStorage` | 9 | single/sharded 模式全覆盖 |
| `integration/` | — | 7 | 写读/多通道/上下文/覆写/配置/CSV |
| `unit/` | — | 22 | 配置/枚举/异常/模型 |

**总计: 115 个测试用例**

### 10.2 测试输出

所有测试文件输出到 `tests/test_output/` 目录（通过 `conftest.py` 中的 `temp_dir` fixture），测试结束后保留不删除。

---

## 11. 依赖关系

```
mf4
├── asammdf >= 7.0.0     # MF4 文件解析核心引擎
├── numpy >= 1.20.0      # 数值计算
├── [可选] pandas         # DataFrame 导出、JSON/Excel/Parquet 转换
├── [可选] pyarrow        # Parquet 导出
├── [可选] h5py           # HDF5 导出
└── [可选] openpyxl       # Excel 导出
```

---

## 12. 已知的局限与待完善项

### 12.1 功能局限

1. **Mf4StreamingWriter 为骨架实现**: `write()` 仅将记录追加到内存列表，`flush()` 仅清空列表，未实际写入 MF4 文件。需要对接 `Mf4Writer` 或 `LargeFileWriter` 完成真实写入。

2. **UnifiedReader 的 sharded 模式 `read_channel` 不保留单位信息**: 从分片读取数据时构造的 `Signal` 对象 `unit` 字段为空字符串，因为 `LargeFileReader` 的原始 `read_shard` / `iter_shards` 返回的字典中不包含单位元数据。

3. **UnifiedReader 的 sharded 模式 `get_channels()` 返回类型不一致**: single 模式返回 `List[Channel]` 对象，sharded 模式返回 `List[str]` 通道名称列表。

4. **Mf4Reader.to_dataframe 需要所有通道等长**: 如果不同通道的数据点数量不同，DataFrame 构造可能出错。

5. **Mf4Converter.to_csv 的 NaN 处理**: 使用 `np.isnan()` 检查，仅适用于浮点类型，整数或字符串类型数据会触发异常。

6. **setup.py 编码问题**: `long_description=open("README.md").read()` 在某些系统上可能因默认编码不是 UTF-8 而失败（GBK 编码错误）。

### 12.2 代码中存在但为空的预留目录

以下目录在 `mf4/` 下存在但不含任何 Python 源文件（仅有空的 `__pycache__` 或完全为空），属于预留扩展位置：
- `builder/` — 构建器（预留）
- `cache/` — 缓存实现（预留，配置中 `cache_enabled`/`cache_strategy` 已定义但未使用）
- `compression/` — 压缩算法（预留）
- `conversion/` — 转换逻辑（预留，当前转换实现在 `converter.py`）
- `parser/` — 解析器（预留，当前解析委托给 asammdf）
- `query/` — 查询引擎（预留）
- `record/` — 记录管理（预留）
- `validation/` — 验证逻辑（预留，当前验证内联在 writer 中）

### 12.3 架构改进建议

1. **缓存策略未实际实现**: `Mf4Config` 中定义了 `cache_enabled`, `cache_size_mb`, `cache_strategy` 等配置，但 `Mf4Reader` 中的缓存只是简单的实例变量，没有实现 LRU/LFU 淘汰和内存限制。

2. **Mf4Config.max_workers 与 LargeFileConfig.parallel_workers 语义重叠**: 统一接口通过 `_mf4_config_to_large_config` 做了映射，但两套配置并存可能造成混淆。

3. **分片索引中存储绝对路径**: `ShardIndex.file_path` 当前存储 `os.path.abspath()` 的绝对路径，文件移动后索引将失效。可考虑改为相对路径。

4. **缺少并发安全说明**: `LargeFileWriter` 的异步写入使用守护线程，异常仅通过 `warnings.warn` 报告，生产环境可能需要更可靠的错误传播机制。
