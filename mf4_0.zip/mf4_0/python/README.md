# MF4 Python SDK

基于 [asammdf](https://github.com/danielhrisca/asammdf) 库实现的 MF4 文件读写 SDK。

## 功能特性

- ✅ **完整的 MF4 读写支持**：基于 asammdf 成熟实现
- ✅ **大文件优化**：分片存储、并行写入、异步处理（目标：1GB < 3秒）
- ✅ **高性能**：支持流式读取，避免内存溢出
- ✅ **格式转换**：CSV、Parquet、HDF5、Excel、JSON
- ✅ **数据查询**：时间范围查询、通道过滤
- ✅ **完整注释**：详细中文注释

## 安装

```bash
pip install asammdf numpy
```

可选依赖：
```bash
pip install pandas pyarrow h5py openpyxl
```

## 快速开始

### 标准读写

```python
from mf4 import Mf4Writer, Mf4Reader
import numpy as np

# 写入文件
with Mf4Writer.create("output.mf4") as writer:
    writer.set_header(author="Test", project="Demo")
    
    timestamps = np.linspace(0, 10, 1000)
    values = np.sin(timestamps)
    
    writer.add_signal("Sine_Wave", timestamps, values, unit="V")

# 读取文件
with Mf4Reader.open("output.mf4") as reader:
    signal = reader.read_channel("Sine_Wave")
    print(f"平均值: {signal.values.mean():.3f}")
```

### 大文件读写（性能优化）

```python
from mf4 import LargeFileWriter, LargeFileReader, LargeFileConfig

# 高性能配置
config = LargeFileConfig.high_performance()

# 写入 1GB 数据（目标 < 3秒）
with LargeFileWriter.create("large_data", config) as writer:
    writer.set_header(author="Large File Test")
    
    for batch in range(20):
        timestamps = np.linspace(batch * 50, (batch + 1) * 50, 500_000)
        signals = {f"Ch_{i}": np.random.randn(500_000) for i in range(10)}
        writer.add_signals(timestamps, signals)

# 读取大文件
with LargeFileReader.open("large_data") as reader:
    # 时间范围查询
    data = reader.read_time_range(100.0, 200.0)
    
    # 流式迭代
    for shard in reader.iter_shards():
        process(shard)
```

## 大文件优化说明

### 核心技术

| 技术 | 说明 |
|------|------|
| **分片存储** | 自动拆分为多个文件（≤1GB/文件） |
| **并行写入** | 多线程并行处理数据块 |
| **异步写入** | 后台线程写入，不阻塞主线程 |
| **索引机制** | JSON 索引文件，快速定位数据 |

### 性能测试

```bash
# 运行性能测试
pytest tests/test_large_file.py -v -s

# 运行演示
python examples/large_file_demo.py
```

### 配置选项

```python
# 高性能（使用更多资源）
config = LargeFileConfig.high_performance()

# 低内存（节省内存）
config = LargeFileConfig.low_memory()

# 自定义
config = LargeFileConfig(
    max_shard_size_mb=1024,   # 分片大小
    parallel_workers=8,        # 并行线程
    enable_async=True,         # 异步写入
    buffer_size_mb=100,        # 缓冲区
)
```

## API 文档

详细 API 参考：
- [大文件模块](./docs/LARGE_FILE.md)
- [核心读写](./docs/API.md)

## 项目结构

```
python/
├── mf4/
│   ├── reader.py            # 标准读取器
│   ├── writer.py            # 标准写入器
│   ├── large_file.py        # 大文件优化模块 ⭐
│   ├── streaming_reader.py  # 流式读取
│   ├── converter.py         # 格式转换
│   ├── config/              # 配置管理
│   ├── model/               # 数据模型
│   ├── enums/               # 枚举类型
│   └── exceptions/          # 异常定义
├── tests/
│   ├── test_large_file.py   # 大文件测试 ⭐
│   └── test_complete.py     # 完整功能测试
└── examples/
    ├── large_file_demo.py   # 大文件演示 ⭐
    └── complete_demo.py     # 完整功能演示
```

## 性能指标

| 场景 | 数据量 | 目标时间 | 实测时间 |
|------|--------|----------|----------|
| 标准写入 | 100MB | < 1s | ~0.3s |
| 大文件写入 | 1GB | < 3s | ~5s* |
| 流式读取 | 1GB | - | ~350 MB/s |

*实测值受存储设备影响，SSD 更快

## 运行测试

```bash
cd python
pytest tests/ -v
```

## 许可证

MIT License