"""
MF4 SDK 安装配置

使用 pip 安装:
    pip install .

开发模式安装:
    pip install -e .
"""

from setuptools import setup, find_packages

setup(
    name="mf4",
    version="1.0.0",
    author="MF4 Development Team",
    author_email="mf4@example.com",
    description="MF4 (Measurement Data Format 4) file reader and writer",
    long_description=open("README.md").read() if __package__ != "setup" else "",
    long_description_content_type="text/markdown",
    url="https://github.com/example/mf4",
    license="MIT",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Scientific/Engineering",
        "Topic :: System :: Filesystems",
    ],
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.20.0",
    ],
    extras_require={
        "pandas": ["pandas>=1.3.0"],
        "parquet": ["pyarrow>=5.0.0"],
        "hdf5": ["h5py>=3.0.0"],
        "lz4": ["lz4>=3.1.0"],
        "dev": [
            "pytest>=6.0.0",
            "pytest-cov>=2.12.0",
            "black>=21.0",
            "flake8>=3.9.0",
            "mypy>=0.900",
        ],
        "docs": [
            "sphinx>=4.0.0",
            "sphinx-rtd-theme>=1.0.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "mf4-validate=mf4.tools:validate_file",
        ],
    },
    include_package_data=True,
    zip_safe=False,
)