# 类图设计

## 1. Python SDK 类图

```mermaid
classDiagram
    class Mf4Reader {
        -str _file_path
        -FileHandle _handle
        -FileHeader _header
        -dict _channel_cache
        -dict _data_group_cache
        +__init__(file_path: str)
        +read_header() FileHeader
        +get_channels() List~Channel~
        +get_channel(name: str) Channel
        +get_channel_group(id: int) ChannelGroup
        +get_data_groups() List~DataGroup~
        +read_records(dg_id: int, start: int, count: int) ndarray
        +read_channel_values(channel: str) Signal
        +close()
        +__enter__() Mf4Reader
        +__exit__(type, value, traceback)
    }

    class Mf4Writer {
        -str _file_path
        -FileHandle _handle
        -FileHeader _header
        -List~DataGroup~ _data_groups
        -dict _metadata
        +__init__(file_path: str, version: str = "4.10")
        +set_header(header: FileHeader)
        +add_channel_group(name: str, channels: List~Channel~)
        +add_channel(cg_id: int, channel: Channel)
        +write_records(cg_id: int, records: ndarray)
        +add_attachment(filename: str, content: bytes)
        +save()
        +close()
        +__enter__() Mf4Writer
        +__exit__(type, value, traceback)
    }

    class BlockParser {
        -FileHandle _handle
        -int _position
        +__init__(handle: FileHandle)
        +parse_id_block() dict
        +parse_hd_block() FileHeader
        +parse_dg_block(offset: int) DataGroup
        +parse_cg_block(offset: int) ChannelGroup
        +parse_cn_block(offset: int) Channel
        +parse_cc_block(offset: int) ChannelConversion
        +parse_tx_block(offset: int) str
        +parse_sr_block(offset: int) SampleReduction
        +parse_at_block(offset: int) Attachment
        +_read_block_header() tuple
        +_resolve_link(block: Block, link_id: int) int
    }

    class BlockBuilder {
        -FileHandle _handle
        -dict _block_positions
        +__init__(handle: FileHandle)
        +build_id_block(version: str)
        +build_hd_block(header: FileHeader) int
        +build_dg_block(data_group: DataGroup) int
        +build_cg_block(channel_group: ChannelGroup) int
        +build_cn_block(channel: Channel) int
        +build_cc_block(conversion: ChannelConversion) int
        +build_tx_block(text: str) int
        +build_sr_block(sr: SampleReduction) int
        +build_at_block(attachment: Attachment) int
        +write_data_records(offset: int, records: ndarray)
        +finalize()
    }

    class RecordReader {
        -FileHandle _handle
        -ChannelGroup _channel_group
        -RecordLayout _layout
        +__init__(handle: FileHandle, cg: ChannelGroup)
        +read_record(position: int) dict
        +read_records(start: int, count: int) ndarray
        +read_channel_values(channel: Channel, start: int, count: int) ndarray
        +get_channel_position(channel: str) tuple
        +_decode_value(raw_bytes: bytes, channel: Channel) Any
        +_apply_conversion(value: Any, conversion: ChannelConversion) float
    }

    class RecordWriter {
        -FileHandle _handle
        -ChannelGroup _channel_group
        -RecordLayout _layout
        -CompressionType _compression
        +__init__(handle: FileHandle, cg: ChannelGroup, compression: CompressionType)
        +write_record(record: dict)
        +write_records(records: ndarray)
        +flush()
        +_encode_value(value: Any, channel: Channel) bytes
    }

    class RecordLayout {
        -ChannelGroup _channel_group
        -dict _field_offsets
        -struct.Struct _struct
        +__init__(cg: ChannelGroup)
        +get_offset(channel_name: str) int
        +get_dtype() numpy.dtype
        +get_record_size() int
        +pack(record: dict) bytes
        +unpack(data: bytes) dict
    }

    class CompressionHandler {
        +__init__(compression_type: CompressionType)
        +compress(data: bytes) bytes
        +decompress(data: bytes) bytes
        +get_compression_ratio() float
    }

    class DataValidator {
        +validate_channel(channel: Channel) List~ValidationError~
        +validate_header(header: FileHeader) List~ValidationError~
        +validate_record(record: dict, cg: ChannelGroup) List~ValidationError~
        +check_data_type(value: Any, expected_type: DataType) bool
        +check_range(value: float, min_val: float, max_val: float) bool
    }

    Mf4Reader --> BlockParser : uses
    Mf4Reader --> RecordReader : uses
    Mf4Writer --> BlockBuilder : uses
    Mf4Writer --> RecordWriter : uses
    RecordReader --> RecordLayout : uses
    RecordWriter --> RecordLayout : uses
    RecordWriter --> CompressionHandler : uses
    BlockBuilder --> DataValidator : uses
```

---

## 2. Java SDK 类图

```mermaid
classDiagram
    class Mf4Reader {
        -String filePath
        -RandomAccessFile fileHandle
        -FileHeader header
        -Map~Integer, DataGroup~ dataGroupCache
        -Map~Integer, Channel~ channelCache
        +Mf4Reader(String filePath)
        +FileHeader readHeader()
        +List~Channel~ getChannels()
        +Channel getChannel(String name)
        +ChannelGroup getChannelGroup(int id)
        +List~DataGroup~ getDataGroups()
        +double[][] readRecords(int dgId, int start, int count)
        +Signal readChannelValues(String channelName)
        +void close()
    }

    class Mf4Writer {
        -String filePath
        -RandomAccessFile fileHandle
        -FileHeader header
        -List~DataGroup~ dataGroups
        -Map~String, Object~ metadata
        +Mf4Writer(String filePath, String version)
        +void setHeader(FileHeader header)
        +int addChannelGroup(String name, List~Channel~ channels)
        +void addChannel(int cgId, Channel channel)
        +void writeRecords(int cgId, double[][] records)
        +void addAttachment(String filename, byte[] content)
        +void save()
        +void close()
    }

    class BlockParser {
        -RandomAccessFile handle
        -long position
        +BlockParser(RandomAccessFile handle)
        +Map~String, Object~ parseIdBlock()
        +FileHeader parseHdBlock()
        +DataGroup parseDgBlock(long offset)
        +ChannelGroup parseCgBlock(long offset)
        +Channel parseCnBlock(long offset)
        +ChannelConversion parseCcBlock(long offset)
        +String parseTxBlock(long offset)
        +SampleReduction parseSrBlock(long offset)
        +Attachment parseAtBlock(long offset)
        -BlockHeader readBlockHeader()
        -long resolveLink(Block block, int linkId)
    }

    class BlockBuilder {
        -RandomAccessFile handle
        -Map~String, Long~ blockPositions
        +BlockBuilder(RandomAccessFile handle)
        +void buildIdBlock(String version)
        +long buildHdBlock(FileHeader header)
        +long buildDgBlock(DataGroup dataGroup)
        +long buildCgBlock(ChannelGroup channelGroup)
        +long buildCnBlock(Channel channel)
        +long buildCcBlock(ChannelConversion conversion)
        +long buildTxBlock(String text)
        +long buildSrBlock(SampleReduction sr)
        +long buildAtBlock(Attachment attachment)
        +void writeDataRecords(long offset, double[][] records)
        +void finalize()
    }

    class RecordReader {
        -RandomAccessFile handle
        -ChannelGroup channelGroup
        -RecordLayout layout
        +RecordReader(RandomAccessFile handle, ChannelGroup cg)
        +Map~String, Object~ readRecord(long position)
        +double[][] readRecords(int start, int count)
        +double[] readChannelValues(Channel channel, int start, int count)
        -Object decodeValue(byte[] rawBytes, Channel channel)
        -double applyConversion(double value, ChannelConversion conversion)
    }

    class RecordWriter {
        -RandomAccessFile handle
        -ChannelGroup channelGroup
        -RecordLayout layout
        -CompressionType compression
        +RecordWriter(RandomAccessFile handle, ChannelGroup cg, CompressionType compression)
        +void writeRecord(Map~String, Object~ record)
        +void writeRecords(double[][] records)
        +void flush()
        -byte[] encodeValue(Object value, Channel channel)
    }

    class RecordLayout {
        -ChannelGroup channelGroup
        -Map~String, Integer~ fieldOffsets
        -int recordSize
        +RecordLayout(ChannelGroup cg)
        +int getOffset(String channelName)
        +int getRecordSize()
        +byte[] pack(Map~String, Object~ record)
        +Map~String, Object~ unpack(byte[] data)
    }

    class CompressionHandler {
        -CompressionType compressionType
        +CompressionHandler(CompressionType compressionType)
        +byte[] compress(byte[] data)
        +byte[] decompress(byte[] data)
        +float getCompressionRatio()
    }

    class DataValidator {
        +List~ValidationError~ validateChannel(Channel channel)
        +List~ValidationError~ validateHeader(FileHeader header)
        +List~ValidationError~ validateRecord(Map record, ChannelGroup cg)
        +boolean checkDataType(Object value, DataType expectedType)
        +boolean checkRange(double value, double min, double max)
    }

    Mf4Reader --> BlockParser : uses
    Mf4Reader --> RecordReader : uses
    Mf4Writer --> BlockBuilder : uses
    Mf4Writer --> RecordWriter : uses
    RecordReader --> RecordLayout : uses
    RecordWriter --> RecordLayout : uses
    RecordWriter --> CompressionHandler : uses
    BlockBuilder --> DataValidator : uses
```

---

## 3. 工厂类设计

```mermaid
classDiagram
    class ReaderFactory {
        <<interface>>
        +create_reader(file_path: str) Mf4Reader
        +create_streaming_reader(file_path: str, buffer_size: int) Mf4StreamingReader
    }

    class DefaultReaderFactory {
        +create_reader(file_path: str) Mf4Reader
        +create_streaming_reader(file_path: str, buffer_size: int) Mf4StreamingReader
    }

    class WriterFactory {
        <<interface>>
        +create_writer(file_path: str, version: str) Mf4Writer
        +create_streaming_writer(file_path: str, buffer_size: int) Mf4StreamingWriter
    }

    class DefaultWriterFactory {
        +create_writer(file_path: str, version: str) Mf4Writer
        +create_streaming_writer(file_path: str, buffer_size: int) Mf4StreamingWriter
    }

    class Mf4StreamingReader {
        -int buffer_size
        -Iterator record_iterator
        +__iter__()
        +__next__() Record
        +seek(position: int)
        +get_progress() float
    }

    class Mf4StreamingWriter {
        -int buffer_size
        -Queue write_queue
        +write(record: Record)
        +flush()
        +get_progress() float
    }

    ReaderFactory <|.. DefaultReaderFactory
    WriterFactory <|.. DefaultWriterFactory
    DefaultReaderFactory ..> Mf4Reader : creates
    DefaultReaderFactory ..> Mf4StreamingReader : creates
    DefaultWriterFactory ..> Mf4Writer : creates
    DefaultWriterFactory ..> Mf4StreamingWriter : creates
```

---

## 4. 策略模式设计

```mermaid
classDiagram
    class CompressionStrategy {
        <<interface>>
        +compress(data: bytes) bytes
        +decompress(data: bytes) bytes
        +get_name() str
    }

    class NoCompression {
        +compress(data: bytes) bytes
        +decompress(data: bytes) bytes
        +get_name() str
    }

    class DeflateCompression {
        -int level
        +compress(data: bytes) bytes
        +decompress(data: bytes) bytes
        +get_name() str
    }

    class LZ4Compression {
        -int acceleration
        +compress(data: bytes) bytes
        +decompress(data: bytes) bytes
        +get_name() str
    }

    class ConversionStrategy {
        <<interface>>
        +convert(value: float) float
        +inverse(value: float) float
        +get_formula() str
    }

    class LinearConversion {
        -float a
        -float b
        +convert(value: float) float
        +inverse(value: float) float
        +get_formula() str
    }

    class RationalConversion {
        -float a, b, c, d
        +convert(value: float) float
        +inverse(value: float) float
        +get_formula() str
    }

    class TabularConversion {
        -List~Tuple~ points
        +convert(value: float) float
        +inverse(value: float) float
        +get_formula() str
    }

    CompressionStrategy <|.. NoCompression
    CompressionStrategy <|.. DeflateCompression
    CompressionStrategy <|.. LZ4Compression
    ConversionStrategy <|.. LinearConversion
    ConversionStrategy <|.. RationalConversion
    ConversionStrategy <|.. TabularConversion
```

---

## 5. 观察者模式设计

```mermaid
classDiagram
    class ProgressListener {
        <<interface>>
        +on_progress(current: int, total: int, message: str)
        +on_complete()
        +on_error(error: Exception)
    }

    class ProgressNotifier {
        -List~ProgressListener~ listeners
        +add_listener(listener: ProgressListener)
        +remove_listener(listener: ProgressListener)
        +notify_progress(current: int, total: int, message: str)
        +notify_complete()
        +notify_error(error: Exception)
    }

    class ConsoleProgressListener {
        +on_progress(current: int, total: int, message: str)
        +on_complete()
        +on_error(error: Exception)
    }

    class LoggingProgressListener {
        -Logger logger
        +on_progress(current: int, total: int, message: str)
        +on_complete()
        +on_error(error: Exception)
    }

    ProgressListener <|.. ConsoleProgressListener
    ProgressListener <|.. LoggingProgressListener
    ProgressNotifier o-- ProgressListener
    Mf4Reader o-- ProgressNotifier
    Mf4Writer o-- ProgressNotifier
```

---

## 6. 类职责说明

### 6.1 核心类

| 类名 | 职责 | 关键方法 |
|------|------|----------|
| Mf4Reader | MF4文件读取主类 | read_header, get_channels, read_records |
| Mf4Writer | MF4文件写入主类 | add_channel_group, write_records, save |
| BlockParser | 二进制块解析 | parse_hd_block, parse_cg_block, parse_cn_block |
| BlockBuilder | 二进制块构建 | build_hd_block, build_cg_block, build_cn_block |
| RecordReader | 记录数据读取 | read_record, read_records, read_channel_values |
| RecordWriter | 记录数据写入 | write_record, write_records, flush |

### 6.2 辅助类

| 类名 | 职责 |
|------|------|
| RecordLayout | 定义记录的字节布局 |
| CompressionHandler | 处理数据压缩/解压 |
| DataValidator | 数据验证 |
| ProgressNotifier | 进度通知 |

---

## 7. 类设计原则

### 7.1 SOLID 原则应用

- **单一职责**: 每个类只负责一个功能（如 Parser 只负责解析）
- **开闭原则**: 通过策略模式支持扩展新的压缩/转换方式
- **里氏替换**: 子类可替换父类（如各种压缩策略）
- **接口隔离**: 使用小接口（如 ProgressListener）
- **依赖倒置**: 依赖抽象而非具体实现

### 7.2 设计模式应用

| 模式 | 应用场景 |
|------|----------|
| 工厂模式 | 创建 Reader/Writer 对象 |
| 策略模式 | 压缩、转换算法 |
| 观察者模式 | 进度通知 |
| 建造者模式 | 复杂对象构建（如 FileHeader） |
| 适配器模式 | 统一不同版本 MF4 格式 |
