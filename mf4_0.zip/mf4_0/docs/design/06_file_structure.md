# 文件结构设计

## 1. 项目整体结构

```
mf4_0/
├── docs/                              # 文档目录
│   ├── design/                        # 设计文档
│   │   ├── README.md                  # 设计文档总览
│   │   ├── 01_data_model.md           # 数据模型设计
│   │   ├── 02_class_diagram.md        # 类图设计
│   │   ├── 03_sequence_diagram.md      # 序列图设计
│   │   ├── 04_swimlane_diagram.md      # 泳道图设计
│   │   ├── 05_api_design.md            # API设计
│   │   └── 06_file_structure.md        # 文件结构设计（本文件）
│   └── api/                           # API文档
│       ├── python/                    # Python API文档
│       └── java/                      # Java API文档
│
├── python/                            # Python SDK
│   ├── mf4/                           # 源码包
│   │   ├── __init__.py
│   │   ├── reader.py                  # Mf4Reader类
│   │   ├── writer.py                  # Mf4Writer类
│   │   ├── streaming_reader.py        # 流式读取器
│   │   ├── streaming_writer.py        # 流式写入器
│   │   ├── converter.py               # 格式转换器
│   │   │
│   │   ├── model/                     # 数据模型
│   │   │   ├── __init__.py
│   │   │   ├── file_header.py
│   │   │   ├── data_group.py
│   │   │   ├── channel_group.py
│   │   │   ├── channel.py
│   │   │   ├── channel_conversion.py
│   │   │   ├── signal.py
│   │   │   ├── attachment.py
│   │   │   └── metadata.py
│   │   │
│   │   ├── parser/                    # 解析器
│   │   │   ├── __init__.py
│   │   │   ├── block_parser.py
│   │   │   ├── id_block.py
│   │   │   ├── hd_block.py
│   │   │   ├── dg_block.py
│   │   │   ├── cg_block.py
│   │   │   ├── cn_block.py
│   │   │   ├── cc_block.py
│   │   │   ├── tx_block.py
│   │   │   ├── sr_block.py
│   │   │   └── at_block.py
│   │   │
│   │   ├── builder/                   # 构建器
│   │   │   ├── __init__.py
│   │   │   ├── block_builder.py
│   │   │   ├── id_builder.py
│   │   │   ├── hd_builder.py
│   │   │   ├── dg_builder.py
│   │   │   ├── cg_builder.py
│   │   │   ├── cn_builder.py
│   │   │   ├── cc_builder.py
│   │   │   ├── tx_builder.py
│   │   │   ├── sr_builder.py
│   │   │   └── at_builder.py
│   │   │
│   │   ├── record/                    # 记录处理
│   │   │   ├── __init__.py
│   │   │   ├── record_reader.py
│   │   │   ├── record_writer.py
│   │   │   ├── record_layout.py
│   │   │   └── record_decoder.py
│   │   │
│   │   ├── compression/               # 压缩处理
│   │   │   ├── __init__.py
│   │   │   ├── compression_handler.py
│   │   │   ├── no_compression.py
│   │   │   ├── deflate_compression.py
│   │   │   └── lz4_compression.py
│   │   │
│   │   ├── conversion/                # 数据转换
│   │   │   ├── __init__.py
│   │   │   ├── conversion_strategy.py
│   │   │   ├── linear_conversion.py
│   │   │   ├── rational_conversion.py
│   │   │   └── tabular_conversion.py
│   │   │
│   │   ├── query/                     # 查询功能
│   │   │   ├── __init__.py
│   │   │   ├── query_builder.py
│   │   │   ├── query_executor.py
│   │   │   └── query_result.py
│   │   │
│   │   ├── cache/                     # 缓存管理
│   │   │   ├── __init__.py
│   │   │   ├── metadata_cache.py
│   │   │   ├── data_cache.py
│   │   │   └── cache_strategy.py
│   │   │
│   │   ├── validation/                # 数据验证
│   │   │   ├── __init__.py
│   │   │   ├── validator.py
│   │   │   ├── channel_validator.py
│   │   │   └── record_validator.py
│   │   │
│   │   ├── enums/                     # 枚举类型
│   │   │   ├── __init__.py
│   │   │   ├── data_type.py
│   │   │   ├── channel_type.py
│   │   │   ├── conversion_type.py
│   │   │   └── compression_type.py
│   │   │
│   │   ├── exceptions/                # 异常定义
│   │   │   ├── __init__.py
│   │   │   ├── base.py
│   │   │   ├── file_exceptions.py
│   │   │   ├── data_exceptions.py
│   │   │   └── validation_exceptions.py
│   │   │
│   │   ├── utils/                     # 工具函数
│   │   │   ├── __init__.py
│   │   │   ├── file_utils.py
│   │   │   ├── byte_utils.py
│   │   │   ├── time_utils.py
│   │   │   └── memory_utils.py
│   │   │
│   │   └── config/                    # 配置管理
│   │       ├── __init__.py
│   │       ├── config.py
│   │       └── default_config.py
│   │
│   ├── tests/                         # 测试目录
│   │   ├── __init__.py
│   │   ├── conftest.py                # pytest配置
│   │   ├── test_reader.py
│   │   ├── test_writer.py
│   │   ├── test_parser/
│   │   ├── test_model/
│   │   ├── test_conversion/
│   │   └── fixtures/                  # 测试数据
│   │       └── sample_files/
│   │
│   ├── examples/                      # 示例代码
│   │   ├── basic_reader.py
│   │   ├── basic_writer.py
│   │   ├── streaming_reader.py
│   │   ├── query_example.py
│   │   └── conversion_example.py
│   │
│   ├── pyproject.toml                # 项目配置
│   ├── setup.py                      # 安装脚本
│   ├── requirements.txt              # 依赖
│   └── README.md                     # Python SDK文档
│
├── java/                              # Java SDK
│   ├── mf4-core/                      # 核心模块
│   │   ├── src/
│   │   │   ├── main/
│   │   │   │   ├── java/
│   │   │   │   │   └── com/mf4/
│   │   │   │   │       ├── Mf4Reader.java
│   │   │   │   │       ├── Mf4Writer.java
│   │   │   │   │       ├── Mf4StreamingReader.java
│   │   │   │   │       ├── Mf4StreamingWriter.java
│   │   │   │   │       ├── Mf4Converter.java
│   │   │   │   │       │
│   │   │   │   │       ├── model/           # 数据模型
│   │   │   │   │       │   ├── FileHeader.java
│   │   │   │   │       │   ├── DataGroup.java
│   │   │   │   │       │   ├── ChannelGroup.java
│   │   │   │   │       │   ├── Channel.java
│   │   │   │   │       │   ├── ChannelConversion.java
│   │   │   │   │       │   ├── Signal.java
│   │   │   │   │       │   ├── Attachment.java
│   │   │   │   │       │   └── Metadata.java
│   │   │   │   │       │
│   │   │   │   │       ├── parser/          # 解析器
│   │   │   │   │       │   ├── BlockParser.java
│   │   │   │   │       │   ├── IdBlockParser.java
│   │   │   │   │       │   ├── HdBlockParser.java
│   │   │   │   │       │   ├── DgBlockParser.java
│   │   │   │   │       │   ├── CgBlockParser.java
│   │   │   │   │       │   ├── CnBlockParser.java
│   │   │   │   │       │   ├── CcBlockParser.java
│   │   │   │   │       │   ├── TxBlockParser.java
│   │   │   │   │       │   ├── SrBlockParser.java
│   │   │   │   │       │   └── AtBlockParser.java
│   │   │   │   │       │
│   │   │   │   │       ├── builder/         # 构建器
│   │   │   │   │       │   ├── BlockBuilder.java
│   │   │   │   │       │   ├── IdBlockBuilder.java
│   │   │   │   │       │   ├── HdBlockBuilder.java
│   │   │   │   │       │   ├── DgBlockBuilder.java
│   │   │   │   │       │   ├── CgBlockBuilder.java
│   │   │   │   │       │   ├── CnBlockBuilder.java
│   │   │   │   │       │   ├── CcBlockBuilder.java
│   │   │   │   │       │   ├── TxBlockBuilder.java
│   │   │   │   │       │   ├── SrBlockBuilder.java
│   │   │   │   │       │   └── AtBlockBuilder.java
│   │   │   │   │       │
│   │   │   │   │       ├── record/         # 记录处理
│   │   │   │   │       │   ├── RecordReader.java
│   │   │   │   │       │   ├── RecordWriter.java
│   │   │   │   │       │   ├── RecordLayout.java
│   │   │   │   │       │   └── RecordDecoder.java
│   │   │   │   │       │
│   │   │   │   │       ├── compression/     # 压缩处理
│   │   │   │   │       │   ├── CompressionHandler.java
│   │   │   │   │       │   ├── NoCompression.java
│   │   │   │   │       │   ├── DeflateCompression.java
│   │   │   │   │       │   └── Lz4Compression.java
│   │   │   │   │       │
│   │   │   │   │       ├── conversion/      # 数据转换
│   │   │   │   │       │   ├── ConversionStrategy.java
│   │   │   │   │       │   ├── LinearConversion.java
│   │   │   │   │       │   │   RationalConversion.java
│   │   │   │   │       │   └── TabularConversion.java
│   │   │   │   │       │
│   │   │   │   │       ├── query/           # 查询功能
│   │   │   │   │       │   ├── QueryBuilder.java
│   │   │   │   │       │   ├── QueryExecutor.java
│   │   │   │   │       │   └── QueryResult.java
│   │   │   │   │       │
│   │   │   │   │       ├── cache/           # 缓存管理
│   │   │   │   │       │   ├── MetadataCache.java
│   │   │   │   │       │   ├── DataCache.java
│   │   │   │   │       │   └── CacheStrategy.java
│   │   │   │   │       │
│   │   │   │   │       ├── validation/      # 数据验证
│   │   │   │   │       │   ├── Validator.java
│   │   │   │   │       │   ├── ChannelValidator.java
│   │   │   │   │       │   └── RecordValidator.java
│   │   │   │   │       │
│   │   │   │   │       ├── enums/          # 枚举类型
│   │   │   │   │       │   ├── DataType.java
│   │   │   │   │       │   ├── ChannelType.java
│   │   │   │   │       │   ├── ConversionType.java
│   │   │   │   │       │   └── CompressionType.java
│   │   │   │   │       │
│   │   │   │   │       ├── exceptions/      # 异常定义
│   │   │   │   │       │   ├── Mf4Exception.java
│   │   │   │   │       │   ├── Mf4FileNotFoundException.java
│   │   │   │   │       │   ├── Mf4CorruptedFileException.java
│   │   │   │   │       │   ├── Mf4UnsupportedVersionException.java
│   │   │   │   │       │   ├── Mf4ChannelNotFoundException.java
│   │   │   │   │       │   └── Mf4ValidationException.java
│   │   │   │   │       │
│   │   │   │   │       ├── utils/           # 工具类
│   │   │   │   │       │   ├── FileUtils.java
│   │   │   │   │       │   ├── ByteUtils.java
│   │   │   │   │       │   ├── TimeUtils.java
│   │   │   │   │       │   └── MemoryUtils.java
│   │   │   │   │       │
│   │   │   │   │       ├── config/          # 配置管理
│   │   │   │   │       │   ├── Mf4Config.java
│   │   │   │   │       │   └── DefaultConfig.java
│   │   │   │   │       │
│   │   │   │   │       └── callback/        # 回调接口
│   │   │   │   │           ├── ProgressListener.java
│   │   │   │   │           └── DataListener.java
│   │   │   │   │
│   │   │   │   └── resources/
│   │   │   │       └── log4j2.xml
│   │   │   │
│   │   │   └── test/
│   │   │       ├── java/
│   │   │       │   └── com/mf4/
│   │   │       │       ├── ReaderTest.java
│   │   │       │       ├── WriterTest.java
│   │   │       │       ├── ParserTest.java
│   │   │       │       ├── ModelTest.java
│   │   │       │       └── ConversionTest.java
│   │   │       └── resources/
│   │   │           └── fixtures/
│   │   │
│   │   └── pom.xml
│   │
│   ├── mf4-examples/                 # 示例模块
│   │   ├── src/main/java/com/mf4/examples/
│   │   │   ├── BasicReaderExample.java
│   │   │   ├── BasicWriterExample.java
│   │   │   ├── StreamingReaderExample.java
│   │   │   ├── QueryExample.java
│   │   │   └── ConversionExample.java
│   │   └── pom.xml
│   │
│   ├── pom.xml                       # 父POM
│   └── README.md                     # Java SDK文档
│
├── shared/                           # 共享资源
│   ├── schema/                       # 数据模式
│   │   ├── channel_schema.json
│   │   ├── header_schema.json
│   │   └── signal_schema.json
│   │
│   └── test_data/                    # 测试数据
│       ├── sample_v410.mf4
│       ├── sample_v411.mf4
│       └── large_file.mf4
│
├── tools/                            # 工具脚本
│   ├── generate_docs.py              # 生成文档
│   ├── validate_mf4.py               # 验证文件
│   └── benchmark.py                  # 性能测试
│
├── .gitignore                        # Git忽略文件
├── LICENSE                           # 许可证
└── README.md                         # 项目总览
```

---

## 2. 核心文件说明

### 2.1 Python 核心文件

| 文件路径 | 说明 | 关键类/函数 |
|---------|------|-----------|
| `python/mf4/reader.py` | 文件读取主类 | `Mf4Reader` |
| `python/mf4/writer.py` | 文件写入主类 | `Mf4Writer` |
| `python/mf4/streaming_reader.py` | 流式读取器 | `Mf4StreamingReader` |
| `python/mf4/streaming_writer.py` | 流式写入器 | `Mf4StreamingWriter` |
| `python/mf4/parser/block_parser.py` | 块解析器 | `BlockParser` |
| `python/mf4/builder/block_builder.py` | 块构建器 | `BlockBuilder` |
| `python/mf4/record/record_reader.py` | 记录读取器 | `RecordReader` |
| `python/mf4/record/record_writer.py` | 记录写入器 | `RecordWriter` |

### 2.2 Java 核心文件

| 文件路径 | 说明 | 关键类 |
|---------|------|--------|
| `java/mf4-core/src/main/java/com/mf4/Mf4Reader.java` | 文件读取主类 | `Mf4Reader` |
| `java/mf4-core/src/main/java/com/mf4/Mf4Writer.java` | 文件写入主类 | `Mf4Writer` |
| `java/mf4-core/src/main/java/com/mf4/parser/BlockParser.java` | 块解析器 | `BlockParser` |
| `java/mf4-core/src/main/java/com/mf4/builder/BlockBuilder.java` | 块构建器 | `BlockBuilder` |
| `java/mf4-core/src/main/java/com/mf4/record/RecordReader.java` | 记录读取器 | `RecordReader` |
| `java/mf4-core/src/main/java/com/mf4/record/RecordWriter.java` | 记录写入器 | `RecordWriter` |

---

## 3. 依赖管理

### 3.1 Python 依赖 (requirements.txt)

```
# 核心依赖
numpy>=1.20.0
pandas>=1.3.0

# 可选依赖
lz4>=3.1.0              # LZ4压缩
pyarrow>=5.0.0          # Parquet支持
h5py>=3.0.0             # HDF5支持

# 开发依赖
pytest>=6.0.0
pytest-cov>=2.12.0
sphinx>=4.0.0
black>=21.0
flake8>=3.9.0
mypy>=0.900
```

### 3.2 Java 依赖 (pom.xml)

```xml
<dependencies>
    <!-- 核心依赖 -->
    <dependency>
        <groupId>org.slf4j</groupId>
        <artifactId>slf4j-api</artifactId>
        <version>1.7.36</version>
    </dependency>
    
    <dependency>
        <groupId>org.apache.logging.log4j</groupId>
        <artifactId>log4j-core</artifactId>
        <version>2.17.1</version>
    </dependency>
    
    <!-- 可选依赖 -->
    <dependency>
        <groupId>org.lz4</groupId>
        <artifactId>lz4-java</artifactId>
        <version>1.8.0</version>
        <optional>true</optional>
    </dependency>
    
    <dependency>
        <groupId>org.apache.parquet</groupId>
        <artifactId>parquet-hadoop</artifactId>
        <version>1.12.0</version>
        <optional>true</optional>
    </dependency>
    
    <!-- 测试依赖 -->
    <dependency>
        <groupId>org.junit.jupiter</groupId>
        <artifactId>junit-jupiter</artifactId>
        <version>5.8.2</version>
        <scope>test</scope>
    </dependency>
</dependencies>
```

---

## 4. 构建配置

### 4.1 Python 构建配置 (pyproject.toml)

```toml
[tool.poetry]
name = "mf4"
version = "1.0.0"
description = "MF4 file format reader and writer"
authors = ["Your Team <team@example.com>"]
license = "MIT"

[tool.poetry.dependencies]
python = "^3.8"
numpy = "^1.20.0"
pandas = "^1.3.0"

[tool.poetry.dev-dependencies]
pytest = "^6.0.0"
pytest-cov = "^2.12.0"
sphinx = "^4.0.0"
black = "^21.0"
flake8 = "^3.9.0"
mypy = "^0.900"

[tool.black]
line-length = 100
target-version = ['py38', 'py39', 'py310']

[tool.mypy]
python_version = "3.8"
warn_return_any = true
warn_unused_configs = true

[tool.pytest.ini_options]
testpaths = ["tests"]
python_files = ["test_*.py"]
python_classes = ["Test*"]
python_functions = ["test_*"]
```

### 4.2 Java 构建配置 (pom.xml)

```xml
<project>
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.mf4</groupId>
    <artifactId>mf4-parent</artifactId>
    <version>1.0.0</version>
    <packaging>pom</packaging>
    
    <modules>
        <module>mf4-core</module>
        <module>mf4-examples</module>
    </modules>
    
    <properties>
        <maven.compiler.source>11</maven.compiler.source>
        <maven.compiler.target>11</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>
    
    <build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-compiler-plugin</artifactId>
                <version>3.8.1</version>
            </plugin>
            
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-surefire-plugin</artifactId>
                <version>2.22.2</version>
            </plugin>
            
            <plugin>
                <groupId>org.jacoco</groupId>
                <artifactId>jacoco-maven-plugin</artifactId>
                <version>0.8.7</version>
            </plugin>
        </plugins>
    </build>
</project>
```

---

## 5. 测试结构

### 5.1 测试分类

```
tests/
├── unit/                    # 单元测试
│   ├── test_parser/
│   ├── test_builder/
│   ├── test_model/
│   └── test_conversion/
│
├── integration/             # 集成测试
│   ├── test_reader_writer.py
│   ├── test_streaming.py
│   └── test_cross_language.py
│
├── performance/             # 性能测试
│   ├── test_large_files.py
│   ├── test_memory_usage.py
│   └── test_concurrent.py
│
└── fixtures/                # 测试数据
    ├── valid_files/
    ├── corrupted_files/
    └── expected_outputs/
```

---

## 6. 文档结构

```
docs/
├── design/                  # 设计文档
│   ├── README.md
│   ├── 01_data_model.md
│   ├── 02_class_diagram.md
│   ├── 03_sequence_diagram.md
│   ├── 04_swimlane_diagram.md
│   ├── 05_api_design.md
│   └── 06_file_structure.md
│
├── api/                     # API文档
│   ├── python/
│   │   ├── index.md
│   │   ├── reader.md
│   │   ├── writer.md
│   │   ├── model.md
│   │   └── examples.md
│   └── java/
│       ├── index.md
│       ├── reader.md
│       ├── writer.md
│       ├── model.md
│       └── examples.md
│
└── user_guide/              # 用户指南
    ├── getting_started.md
    ├── basic_usage.md
    ├── advanced_features.md
    ├── performance_tuning.md
    └── troubleshooting.md
```