# API 设计文档

## 1. Python API

### 1.1 核心读取 API

```python
from mf4 import Mf4Reader, Mf4Writer
from mf4.model import FileHeader, Channel, Signal
from mf4.enums import DataType, ChannelType

# ============ 基本读取 ============

# 打开文件
with Mf4Reader.open("measurement.mf4") as reader:
    # 获取文件头
    header: FileHeader = reader.header
    
    # 获取所有通道列表
    channels: List[Channel] = reader.get_channels()
    
    # 获取特定通道
    channel: Channel = reader.get_channel("Engine_Speed")
    
    # 读取通道数据
    signal: Signal = reader.read_channel("Engine_Speed")
    
    # 获取时间轴
    time: np.ndarray = reader.get_time_channel()

# ============ 高级读取 ============

# 按时间范围读取
with Mf4Reader.open("measurement.mf4") as reader:
    signal = reader.read_channel(
        "Engine_Speed",
        start_time=10.0,
        end_time=20.0
    )

# 批量读取多个通道
with Mf4Reader.open("measurement.mf4") as reader:
    signals = reader.read_channels([
        "Engine_Speed",
        "Vehicle_Speed",
        "Throttle_Position"
    ])

# 流式读取大文件
from mf4 import Mf4StreamingReader

with Mf4StreamingReader.open("large_file.mf4", buffer_size=10000) as reader:
    for record in reader:
        process_record(record)
        
# 按批次流式读取
with Mf4StreamingReader.open("large_file.mf4") as reader:
    for batch in reader.read_batches(batch_size=5000):
        process_batch(batch)

# ============ 数据过滤 ============

with Mf4Reader.open("measurement.mf4") as reader:
    # 按条件过滤通道
    channels = reader.filter_channels(
        name_pattern="Engine_*",
        unit="rpm"
    )
    
    # 按数据类型过滤
    channels = reader.filter_channels(
        data_type=DataType.FLOAT64
    )
```

### 1.2 核心写入 API

```python
from mf4 import Mf4Writer
from mf4.model import FileHeader, Channel, ChannelGroup
from mf4.enums import DataType, ChannelType, CompressionType
import numpy as np

# ============ 基本写入 ============

with Mf4Writer.create("output.mf4") as writer:
    # 设置文件头
    writer.set_header(
        author="John Doe",
        organization="Example Corp",
        project="Engine Testing",
        comment="Test measurement"
    )
    
    # 添加通道组
    cg_id = writer.add_channel_group(
        name="Engine_Data",
        comment="Engine measurement data"
    )
    
    # 添加通道定义
    writer.add_channel(
        cg_id,
        name="Engine_Speed",
        unit="rpm",
        data_type=DataType.FLOAT64,
        comment="Engine speed"
    )
    
    writer.add_channel(
        cg_id,
        name="Vehicle_Speed",
        unit="km/h",
        data_type=DataType.FLOAT64
    )
    
    # 写入数据
    timestamps = np.linspace(0, 10, 1000)
    engine_speed = np.random.uniform(1000, 6000, 1000)
    vehicle_speed = np.random.uniform(0, 120, 1000)
    
    writer.write_data(
        cg_id,
        timestamps=timestamps,
        data={
            "Engine_Speed": engine_speed,
            "Vehicle_Speed": vehicle_speed
        }
    )

# ============ 高级写入 ============

# 流式写入
with Mf4Writer.create("streaming_output.mf4") as writer:
    writer.set_header(author="Test")
    cg_id = writer.add_channel_group("Stream_Data")
    writer.add_channel(cg_id, "Value", unit="V", data_type=DataType.FLOAT64)
    
    # 流式写入数据
    for i in range(100):
        batch_data = generate_batch_data(i)
        writer.append_data(cg_id, batch_data)

# 带压缩写入
with Mf4Writer.create(
    "compressed.mf4",
    compression=CompressionType.DEFLATE
) as writer:
    writer.set_header(author="Test")
    # ... 写入操作

# 添加附件
with Mf4Writer.create("with_attachment.mf4") as writer:
    writer.set_header(author="Test")
    
    # 添加配置文件附件
    with open("config.json", "rb") as f:
        writer.add_attachment(
            filename="config.json",
            content=f.read(),
            mime_type="application/json",
            comment="Measurement configuration"
        )
    
    # 其他写入操作...
```

### 1.3 数据转换 API

```python
from mf4 import Mf4Converter

# ============ 格式转换 ============

# MF4 转 CSV
converter = Mf4Converter("input.mf4")
converter.to_csv("output.csv", channels=["Engine_Speed", "Vehicle_Speed"])

# MF4 转 Parquet
converter.to_parquet("output.parquet")

# MF4 转 HDF5
converter.to_hdf5("output.h5", group="/measurement")

# ============ 数据导出 ============

with Mf4Reader.open("measurement.mf4") as reader:
    # 导出为 DataFrame
    df = reader.to_pandas()
    
    # 导出特定通道
    df = reader.to_pandas(channels=["Engine_*"])
    
    # 导出到字典
    data_dict = reader.to_dict()

# ============ 数据导入 ============

import pandas as pd

df = pd.read_csv("data.csv")
with Mf4Writer.create("from_csv.mf4") as writer:
    writer.from_pandas(df, channel_group="Imported_Data")
```

### 1.4 查询 API

```python
from mf4.query import QueryBuilder

# ============ 查询构建 ============

with Mf4Reader.open("measurement.mf4") as reader:
    # 构建查询
    query = (QueryBuilder(reader)
        .select("Engine_Speed", "Vehicle_Speed")
        .where(time_range=(10.0, 20.0))
        .where(channel_value="Engine_Speed", min=2000, max=4000)
        .order_by("timestamp")
        .limit(1000))
    
    result = query.execute()
    
    # 聚合查询
    stats = (QueryBuilder(reader)
        .select("Engine_Speed")
        .aggregate(["min", "max", "mean", "std"]))
    
    print(stats)

# ============ 高级查询 ============

# 按条件查询数据点
with Mf4Reader.open("measurement.mf4") as reader:
    # 查找特定条件的数据点
    events = reader.find_events(
        channel="Engine_Speed",
        condition=lambda x: x > 5000,
        min_duration=0.5
    )
    
    # 提取事件数据
    for event in events:
        event_data = reader.extract_event(event)
        analyze_event(event_data)
```

### 1.5 配置 API

```python
from mf4 import Mf4Config

# ============ 全局配置 ============

config = Mf4Config(
    # 缓存配置
    cache_size_mb=100,
    cache_strategy="lru",
    
    # 性能配置
    buffer_size=10000,
    max_workers=4,
    use_memory_mapping=True,
    
    # 验证配置
    strict_mode=False,
    validate_on_read=True,
    validate_on_write=True,
    
    # 日志配置
    log_level="INFO",
    log_file="mf4.log"
)

# 应用配置
reader = Mf4Reader.open("measurement.mf4", config=config)
```

---

## 2. Java API

### 2.1 核心读取 API

```java
import com.mf4.Mf4Reader;
import com.mf4.Mf4Writer;
import com.mf4.model.*;
import com.mf4.enums.*;

// ============ 基本读取 ============

// 使用 try-with-resources
try (Mf4Reader reader = Mf4Reader.open("measurement.mf4")) {
    // 获取文件头
    FileHeader header = reader.getHeader();
    
    // 获取所有通道
    List<Channel> channels = reader.getChannels();
    
    // 获取特定通道
    Channel channel = reader.getChannel("Engine_Speed");
    
    // 读取通道数据
    Signal signal = reader.readChannel("Engine_Speed");
    
    // 获取时间轴
    double[] time = reader.getTimeChannel();
}

// ============ 高级读取 ============

// 按时间范围读取
try (Mf4Reader reader = Mf4Reader.open("measurement.mf4")) {
    Signal signal = reader.readChannel(
        "Engine_Speed",
        new TimeRange(10.0, 20.0)
    );
}

// 批量读取多个通道
try (Mf4Reader reader = Mf4Reader.open("measurement.mf4")) {
    List<Signal> signals = reader.readChannels(Arrays.asList(
        "Engine_Speed",
        "Vehicle_Speed",
        "Throttle_Position"
    ));
}

// 流式读取
try (Mf4StreamingReader reader = Mf4StreamingReader.open(
    "large_file.mf4", 10000)) {
    
    reader.forEach(record -> {
        processRecord(record);
    });
    
    // 或使用批量流式读取
    reader.streamBatches(5000)
        .forEach(batch -> processBatch(batch));
}

// ============ 数据过滤 ============

try (Mf4Reader reader = Mf4Reader.open("measurement.mf4")) {
    // 按名称模式过滤
    List<Channel> channels = reader.filterChannels(
        ChannelFilter.builder()
            .namePattern("Engine_*")
            .unit("rpm")
            .build()
    );
    
    // 按数据类型过滤
    List<Channel> channels = reader.filterChannels(
        ChannelFilter.builder()
            .dataType(DataType.FLOAT64)
            .build()
    );
}
```

### 2.2 核心写入 API

```java
import com.mf4.Mf4Writer;
import com.mf4.model.*;
import com.mf4.enums.*;

// ============ 基本写入 ============

try (Mf4Writer writer = Mf4Writer.create("output.mf4")) {
    // 设置文件头
    writer.setHeader(FileHeader.builder()
        .author("John Doe")
        .organization("Example Corp")
        .project("Engine Testing")
        .comment("Test measurement")
        .build());
    
    // 添加通道组
    int cgId = writer.addChannelGroup(ChannelGroup.builder()
        .name("Engine_Data")
        .comment("Engine measurement data")
        .build());
    
    // 添加通道定义
    writer.addChannel(cgId, Channel.builder()
        .name("Engine_Speed")
        .unit("rpm")
        .dataType(DataType.FLOAT64)
        .comment("Engine speed")
        .build());
    
    writer.addChannel(cgId, Channel.builder()
        .name("Vehicle_Speed")
        .unit("km/h")
        .dataType(DataType.FLOAT64)
        .build());
    
    // 写入数据
    double[] timestamps = generateTimestamps(0, 10, 1000);
    double[] engineSpeed = generateRandomData(1000, 6000, 1000);
    double[] vehicleSpeed = generateRandomData(0, 120, 1000);
    
    writer.writeData(cgId, timestamps, Map.of(
        "Engine_Speed", engineSpeed,
        "Vehicle_Speed", vehicleSpeed
    ));
}

// ============ 高级写入 ============

// 流式写入
try (Mf4Writer writer = Mf4Writer.create("streaming_output.mf4")) {
    writer.setHeader(FileHeader.builder().author("Test").build());
    
    int cgId = writer.addChannelGroup("Stream_Data");
    writer.addChannel(cgId, "Value", "V", DataType.FLOAT64);
    
    // 流式追加数据
    for (int i = 0; i < 100; i++) {
        Map<String, double[]> batchData = generateBatchData(i);
        writer.appendData(cgId, batchData);
    }
}

// 带压缩写入
Mf4WriterConfig config = Mf4WriterConfig.builder()
    .compression(CompressionType.DEFLATE)
    .compressionLevel(6)
    .build();

try (Mf4Writer writer = Mf4Writer.create("compressed.mf4", config)) {
    // 写入操作...
}

// 添加附件
try (Mf4Writer writer = Mf4Writer.create("with_attachment.mf4")) {
    writer.setHeader(FileHeader.builder().author("Test").build());
    
    // 添加配置文件附件
    byte[] configData = Files.readAllBytes(Paths.get("config.json"));
    writer.addAttachment(Attachment.builder()
        .filename("config.json")
        .content(configData)
        .mimeType("application/json")
        .comment("Measurement configuration")
        .build());
}
```

### 2.3 数据转换 API

```java
import com.mf4.Mf4Converter;

// ============ 格式转换 ============

// MF4 转 CSV
Mf4Converter converter = new Mf4Converter("input.mf4");
converter.toCsv("output.csv", 
    Arrays.asList("Engine_Speed", "Vehicle_Speed"));

// MF4 转 Parquet
converter.toParquet("output.parquet");

// MF4 转 HDF5
converter.toHdf5("output.h5", "/measurement");

// ============ 数据导出 ============

try (Mf4Reader reader = Mf4Reader.open("measurement.mf4")) {
    // 导出为表格数据
    TableData table = reader.toTable();
    
    // 导出特定通道
    TableData table = reader.toTable(
        ChannelFilter.builder().namePattern("Engine_*").build()
    );
}

// ============ 数据导入 ============

import com.mf4.importer.CsvImporter;

CsvImporter importer = new CsvImporter("data.csv");
try (Mf4Writer writer = Mf4Writer.create("from_csv.mf4")) {
    writer.importFrom(importer, "Imported_Data");
}
```

### 2.4 查询 API

```java
import com.mf4.query.*;

// ============ 查询构建 ============

try (Mf4Reader reader = Mf4Reader.open("measurement.mf4")) {
    // 构建查询
    QueryResult result = QueryBuilder.create(reader)
        .select("Engine_Speed", "Vehicle_Speed")
        .where(TimeRange.of(10.0, 20.0))
        .where(ChannelCondition.of("Engine_Speed", 2000, 4000))
        .orderBy("timestamp")
        .limit(1000)
        .execute();
    
    // 聚合查询
    AggregateResult stats = QueryBuilder.create(reader)
        .select("Engine_Speed")
        .aggregate(AggregateFunction.MIN, AggregateFunction.MAX,
                   AggregateFunction.MEAN, AggregateFunction.STD)
        .execute();
}

// ============ 事件检测 ============

try (Mf4Reader reader = Mf4Reader.open("measurement.mf4")) {
    // 查找事件
    List<Event> events = reader.findEvents(EventCondition.builder()
        .channel("Engine_Speed")
        .condition(value -> value > 5000)
        .minDuration(0.5)
        .build());
    
    // 提取事件数据
    for (Event event : events) {
        Signal eventData = reader.extractEvent(event);
        analyzeEvent(eventData);
    }
}
```

### 2.5 回调与监听 API

```java
import com.mf4.callback.*;

// ============ 进度监听 ============

ProgressListener listener = new ProgressListener() {
    @Override
    public void onProgress(int current, int total, String message) {
        System.out.printf("Progress: %d/%d - %s%n", 
            current, total, message);
    }
    
    @Override
    public void onComplete() {
        System.out.println("Operation completed!");
    }
    
    @Override
    public void onError(Exception error) {
        System.err.println("Error: " + error.getMessage());
    }
};

try (Mf4Reader reader = Mf4Reader.open("large_file.mf4")) {
    reader.setProgressListener(listener);
    // 读取操作...
}

// ============ 数据监听 ============

DataListener dataListener = new DataListener() {
    @Override
    public void onRecord(Record record) {
        processRecord(record);
    }
    
    @Override
    public void onBatch(List<Record> batch) {
        processBatch(batch);
    }
};

try (Mf4StreamingReader reader = Mf4StreamingReader.open("file.mf4")) {
    reader.setDataListener(dataListener);
    reader.start();
}
```

---

## 3. API 一致性对照表

| 功能 | Python API | Java API |
|------|-----------|----------|
| 打开文件 | `Mf4Reader.open(path)` | `Mf4Reader.open(path)` |
| 获取文件头 | `reader.header` | `reader.getHeader()` |
| 获取通道列表 | `reader.get_channels()` | `reader.getChannels()` |
| 读取通道 | `reader.read_channel(name)` | `reader.readChannel(name)` |
| 创建文件 | `Mf4Writer.create(path)` | `Mf4Writer.create(path)` |
| 设置文件头 | `writer.set_header(...)` | `writer.setHeader(...)` |
| 添加通道组 | `writer.add_channel_group(name)` | `writer.addChannelGroup(name)` |
| 写入数据 | `writer.write_data(cg_id, data)` | `writer.writeData(cgId, data)` |
| 流式读取 | `Mf4StreamingReader.open()` | `Mf4StreamingReader.open()` |
| 转换格式 | `Mf4Converter(path).to_csv()` | `new Mf4Converter(path).toCsv()` |

---

## 4. 错误处理

### 4.1 Python 异常

```python
from mf4.exceptions import (
    Mf4Error,
    Mf4FileNotFoundError,
    Mf4CorruptedFileError,
    Mf4UnsupportedVersionError,
    Mf4ChannelNotFoundError,
    Mf4ValidationError
)

try:
    with Mf4Reader.open("file.mf4") as reader:
        signal = reader.read_channel("Invalid_Channel")
except Mf4FileNotFoundError as e:
    print(f"File not found: {e}")
except Mf4CorruptedFileError as e:
    print(f"Corrupted file: {e}")
except Mf4ChannelNotFoundError as e:
    print(f"Channel not found: {e}")
except Mf4Error as e:
    print(f"MF4 error: {e}")
```

### 4.2 Java 异常

```java
import com.mf4.exceptions.*;

try {
    try (Mf4Reader reader = Mf4Reader.open("file.mf4")) {
        Signal signal = reader.readChannel("Invalid_Channel");
    }
} catch (Mf4FileNotFoundException e) {
    System.err.println("File not found: " + e.getMessage());
} catch (Mf4CorruptedFileException e) {
    System.err.println("Corrupted file: " + e.getMessage());
} catch (Mf4ChannelNotFoundException e) {
    System.err.println("Channel not found: " + e.getMessage());
} catch (Mf4Exception e) {
    System.err.println("MF4 error: " + e.getMessage());
}
```

---

## 5. 配置选项

### 5.1 Python 配置

```python
from mf4 import Mf4Config

config = Mf4Config(
    # I/O 配置
    buffer_size=10000,
    use_memory_mapping=True,
    
    # 缓存配置
    cache_enabled=True,
    cache_size_mb=100,
    
    # 性能配置
    max_workers=4,
    prefetch_size=3,
    
    # 验证配置
    validate_on_read=False,
    validate_on_write=True,
    
    # 日志配置
    log_level="INFO"
)
```

### 5.2 Java 配置

```java
import com.mf4.Mf4Config;

Mf4Config config = Mf4Config.builder()
    // I/O 配置
    .bufferSize(10000)
    .useMemoryMapping(true)
    
    // 缓存配置
    .cacheEnabled(true)
    .cacheSizeMb(100)
    
    // 性能配置
    .maxWorkers(4)
    .prefetchSize(3)
    
    // 验证配置
    .validateOnRead(false)
    .validateOnWrite(true)
    
    // 日志配置
    .logLevel("INFO")
    .build();
```