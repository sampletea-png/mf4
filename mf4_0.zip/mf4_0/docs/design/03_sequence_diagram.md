# 序列图设计

## 1. 读取 MF4 文件序列图

### 1.1 完整读取流程

```mermaid
sequenceDiagram
    participant Client
    participant Mf4Reader
    participant BlockParser
    participant RecordReader
    participant FileSystem

    Client->>Mf4Reader: open(file_path)
    activate Mf4Reader
    Mf4Reader->>FileSystem: open(file_path, 'rb')
    FileSystem-->>Mf4Reader: file_handle
    
    Mf4Reader->>BlockParser: parse_id_block()
    activate BlockParser
    BlockParser->>FileSystem: read(64 bytes)
    FileSystem-->>BlockParser: id_block_data
    BlockParser-->>Mf4Reader: id_info
    deactivate BlockParser
    
    Mf4Reader->>BlockParser: parse_hd_block()
    activate BlockParser
    BlockParser->>FileSystem: seek(header_offset)
    BlockParser->>FileSystem: read(header_size)
    FileSystem-->>BlockParser: header_data
    BlockParser->>BlockParser: resolve_links()
    BlockParser-->>Mf4Reader: FileHeader
    deactivate BlockParser
    
    loop For each DataGroup
        Mf4Reader->>BlockParser: parse_dg_block(offset)
        activate BlockParser
        BlockParser->>FileSystem: read(dg_size)
        FileSystem-->>BlockParser: dg_data
        
        loop For each ChannelGroup
            BlockParser->>FileSystem: read(cg_size)
            FileSystem-->>BlockParser: cg_data
            
            loop For each Channel
                BlockParser->>FileSystem: read(cn_size)
                FileSystem-->>BlockParser: cn_data
                BlockParser->>BlockParser: parse_conversion()
            end
            
            BlockParser-->>Mf4Reader: ChannelGroup
        end
        
        BlockParser-->>Mf4Reader: DataGroup
        deactivate BlockParser
    end
    
    Mf4Reader-->>Client: Mf4File object
    deactivate Mf4Reader
```

### 1.2 读取单个通道数据

```mermaid
sequenceDiagram
    participant Client
    participant Mf4Reader
    participant Channel
    participant RecordReader
    participant FileSystem

    Client->>Mf4Reader: get_channel("Engine_Speed")
    Mf4Reader->>Mf4Reader: search_in_cache()
    alt Channel in cache
        Mf4Reader-->>Client: cached Channel
    else Channel not in cache
        Mf4Reader->>RecordReader: load_channel_metadata("Engine_Speed")
        activate RecordReader
        RecordReader->>FileSystem: seek(channel_offset)
        RecordReader->>FileSystem: read(channel_size)
        FileSystem-->>RecordReader: channel_data
        RecordReader-->>Mf4Reader: Channel
        deactivate RecordReader
        Mf4Reader->>Mf4Reader: cache_channel()
        Mf4Reader-->>Client: Channel
    end
    
    Client->>Channel: get_values()
    activate Channel
    Channel->>RecordReader: read_all_values()
    activate RecordReader
    
    RecordReader->>FileSystem: seek(data_section_offset)
    
    loop For each record
        RecordReader->>FileSystem: read(record_size)
        FileSystem-->>RecordReader: record_bytes
        RecordReader->>RecordReader: decode_value()
    end
    
    RecordReader-->>Channel: numpy.ndarray
    deactivate RecordReader
    Channel-->>Client: Signal(values, timestamps)
    deactivate Channel
```

### 1.3 流式读取大数据

```mermaid
sequenceDiagram
    participant Client
    participant StreamingReader
    participant RecordReader
    participant BufferPool
    participant FileSystem

    Client->>StreamingReader: create(file_path, buffer_size=10000)
    activate StreamingReader
    StreamingReader->>FileSystem: open(file_path)
    StreamingReader->>BufferPool: initialize(buffer_size)
    StreamingReader-->>Client: reader_iterator
    deactivate StreamingReader
    
    loop Iterator
        Client->>StreamingReader: __next__()
        activate StreamingReader
        
        alt Buffer empty
            StreamingReader->>BufferPool: get_next_buffer()
            activate BufferPool
            BufferPool->>FileSystem: read(buffer_size * record_size)
            FileSystem-->>BufferPool: buffer_data
            BufferPool->>BufferPool: decode_records()
            BufferPool-->>StreamingReader: records_batch
            deactivate BufferPool
        end
        
        StreamingReader->>StreamingReader: get_next_record()
        StreamingReader-->>Client: record_dict
        deactivate StreamingReader
    end
    
    Client->>StreamingReader: close()
    StreamingReader->>FileSystem: close()
    StreamingReader->>BufferPool: release()
```

---

## 2. 写入 MF4 文件序列图

### 2.1 完整写入流程

```mermaid
sequenceDiagram
    participant Client
    participant Mf4Writer
    participant BlockBuilder
    participant RecordWriter
    participant FileSystem

    Client->>Mf4Writer: create(file_path)
    activate Mf4Writer
    Mf4Writer->>FileSystem: open(file_path, 'wb')
    Mf4Writer->>BlockBuilder: build_id_block(version)
    activate BlockBuilder
    BlockBuilder->>FileSystem: write(id_block_bytes)
    BlockBuilder-->>Mf4Writer: id_block_position
    deactivate BlockBuilder
    
    Client->>Mf4Writer: set_header(header_info)
    Mf4Writer->>BlockBuilder: build_hd_block(header)
    activate BlockBuilder
    BlockBuilder->>BlockBuilder: create_placeholder()
    BlockBuilder->>FileSystem: write(header_block_bytes)
    BlockBuilder-->>Mf4Writer: header_position
    deactivate BlockBuilder
    
    Client->>Mf4Writer: add_channel_group("Engine", channels)
    Mf4Writer->>BlockBuilder: build_cg_block(channel_group)
    activate BlockBuilder
    
    loop For each Channel
        BlockBuilder->>FileSystem: write(cn_block_bytes)
        
        opt Has conversion
            BlockBuilder->>FileSystem: write(cc_block_bytes)
        end
    end
    
    BlockBuilder->>FileSystem: write(cg_block_bytes)
    BlockBuilder-->>Mf4Writer: cg_position
    deactivate BlockBuilder
    
    Client->>Mf4Writer: write_records(cg_id, records)
    Mf4Writer->>RecordWriter: write_records(records)
    activate RecordWriter
    
    loop For each record
        RecordWriter->>RecordWriter: encode_record()
        RecordWriter->>FileSystem: write(record_bytes)
    end
    
    RecordWriter-->>Mf4Writer: data_position
    deactivate RecordWriter
    
    Client->>Mf4Writer: save()
    Mf4Writer->>BlockBuilder: update_links()
    activate BlockBuilder
    BlockBuilder->>FileSystem: seek(link_positions)
    BlockBuilder->>FileSystem: write(link_values)
    BlockBuilder-->>Mf4Writer: links_updated
    deactivate BlockBuilder
    
    Mf4Writer->>FileSystem: flush()
    Mf4Writer-->>Client: success
    deactivate Mf4Writer
```

### 2.2 流式写入大数据

```mermaid
sequenceDiagram
    participant Client
    participant StreamingWriter
    participant RecordWriter
    participant WriteQueue
    participant FileSystem

    Client->>StreamingWriter: create(file_path, buffer_size=10000)
    activate StreamingWriter
    StreamingWriter->>FileSystem: open(file_path)
    StreamingWriter->>WriteQueue: initialize(buffer_size)
    StreamingWriter->>FileSystem: write(metadata_blocks)
    StreamingWriter-->>Client: writer
    deactivate StreamingWriter
    
    loop Stream records
        Client->>StreamingWriter: write(record)
        activate StreamingWriter
        StreamingWriter->>WriteQueue: enqueue(record)
        
        alt Queue full
            StreamingWriter->>FileSystem: write_batch(queue_records)
            StreamingWriter->>WriteQueue: clear()
        end
        
        deactivate StreamingWriter
    end
    
    Client->>StreamingWriter: flush()
    activate StreamingWriter
    StreamingWriter->>WriteQueue: get_remaining()
    StreamingWriter->>FileSystem: write_batch(remaining)
    StreamingWriter->>FileSystem: flush()
    deactivate StreamingWriter
    
    Client->>StreamingWriter: finalize()
    activate StreamingWriter
    StreamingWriter->>FileSystem: seek(link_positions)
    StreamingWriter->>FileSystem: write(final_links)
    StreamingWriter->>FileSystem: close()
    deactivate StreamingWriter
```

---

## 3. 数据转换序列图

### 3.1 通道值转换流程

```mermaid
sequenceDiagram
    participant Client
    participant RecordReader
    participant RecordLayout
    participant ConversionStrategy
    participant FileSystem

    Client->>RecordReader: read_channel_values(channel, start, count)
    activate RecordReader
    
    RecordReader->>RecordLayout: get_offset(channel.name)
    activate RecordLayout
    RecordLayout-->>RecordReader: (byte_offset, bit_offset, bit_count)
    deactivate RecordLayout
    
    RecordReader->>FileSystem: seek(data_section_start + start * record_size)
    
    loop For each record
        RecordReader->>FileSystem: read(record_size)
        FileSystem-->>RecordReader: record_bytes
        
        RecordReader->>RecordLayout: extract_field(bytes, offset)
        activate RecordLayout
        RecordLayout-->>RecordReader: raw_value
        deactivate RecordLayout
        
        alt Channel has conversion
            RecordReader->>ConversionStrategy: convert(raw_value)
            activate ConversionStrategy
            
            alt Linear conversion
                ConversionStrategy->>ConversionStrategy: y = a * x + b
            else Rational conversion
                ConversionStrategy->>ConversionStrategy: y = (a*x + b) / (c*x + d)
            else Tabular conversion
                ConversionStrategy->>ConversionStrategy: interpolate(x)
            end
            
            ConversionStrategy-->>RecordReader: converted_value
            deactivate ConversionStrategy
        else No conversion
            RecordReader->>RecordReader: use raw_value
        end
    end
    
    RecordReader-->>Client: Signal(values, timestamps)
    deactivate RecordReader
```

---

## 4. 异常处理序列图

### 4.1 读取异常处理

```mermaid
sequenceDiagram
    participant Client
    participant Mf4Reader
    participant BlockParser
    participant Validator
    participant Logger

    Client->>Mf4Reader: open(corrupted_file.mf4)
    activate Mf4Reader
    
    Mf4Reader->>BlockParser: parse_id_block()
    activate BlockParser
    
    alt Invalid ID block
        BlockParser->>Validator: validate_id_block(data)
        activate Validator
        Validator-->>BlockParser: ValidationError("Invalid magic number")
        deactivate Validator
        
        BlockParser->>Logger: log_error(validation_error)
        BlockParser-->>Mf4Reader: raise Mf4FormatException
        deactivate BlockParser
        
        Mf4Reader->>Logger: log_error("Failed to parse file")
        Mf4Reader-->>Client: raise Mf4FormatException
    else Valid ID block
        BlockParser-->>Mf4Reader: id_info
        deactivate BlockParser
        
        Mf4Reader->>BlockParser: parse_hd_block()
        activate BlockParser
        
        alt Unsupported version
            BlockParser->>Validator: check_version(version)
            activate Validator
            Validator-->>BlockParser: ValidationError("Unsupported version 3.0")
            deactivate Validator
            
            BlockParser-->>Mf4Reader: raise UnsupportedVersionError
            deactivate BlockParser
            Mf4Reader-->>Client: raise UnsupportedVersionError
        else Link resolution failed
            BlockParser->>BlockParser: resolve_links()
            BlockParser->>Logger: log_warning("Broken link at offset 0x1000")
            BlockParser-->>Mf4Reader: partial_header
            Mf4Reader->>Logger: log_warning("Partial file read")
            Mf4Reader-->>Client: Mf4File with warnings
        end
    end
    
    deactivate Mf4Reader
```

### 4.2 写入验证流程

```mermaid
sequenceDiagram
    participant Client
    participant Mf4Writer
    participant DataValidator
    participant Logger
    participant FileSystem

    Client->>Mf4Writer: add_channel(channel)
    activate Mf4Writer
    
    Mf4Writer->>DataValidator: validate_channel(channel)
    activate DataValidator
    
    alt Missing required field
        DataValidator-->>Mf4Writer: ValidationError("Channel name required")
        deactivate DataValidator
        Mf4Writer-->>Client: raise ValidationError
    else Invalid data type
        DataValidator-->>Mf4Writer: ValidationError("Unsupported data type")
        deactivate DataValidator
        Mf4Writer-->>Client: raise ValidationError
    else Valid channel
        DataValidator-->>Mf4Writer: Valid
        deactivate DataValidator
        Mf4Writer->>Mf4Writer: add_to_internal_list()
        Mf4Writer-->>Client: channel_id
    end
    
    deactivate Mf4Writer
    
    Client->>Mf4Writer: write_records(cg_id, records)
    activate Mf4Writer
    
    Mf4Writer->>DataValidator: validate_records(records, channel_group)
    activate DataValidator
    
    alt Record count mismatch
        DataValidator->>Logger: log_error("Expected 100 records, got 150")
        DataValidator-->>Mf4Writer: ValidationError("Record count mismatch")
        deactivate DataValidator
        Mf4Writer-->>Client: raise ValidationError
    else Data range violation
        DataValidator->>Logger: log_warning("Value out of range at record 50")
        DataValidator-->>Mf4Writer: ValidationWarning
        deactivate DataValidator
        Mf4Writer->>Client: warn("Values clipped")
        Mf4Writer->>FileSystem: write_records_with_clipping()
        Mf4Writer-->>Client: success
    else All valid
        DataValidator-->>Mf4Writer: Valid
        deactivate DataValidator
        Mf4Writer->>FileSystem: write_records()
        Mf4Writer-->>Client: success
    end
    
    deactivate Mf4Writer
```

---

## 5. 缓存机制序列图

### 5.1 元数据缓存流程

```mermaid
sequenceDiagram
    participant Client
    participant Mf4Reader
    participant MetadataCache
    participant BlockParser
    participant FileSystem

    Client->>Mf4Reader: get_channel("Engine_Speed")
    activate Mf4Reader
    
    Mf4Reader->>MetadataCache: get("Engine_Speed")
    activate MetadataCache
    
    alt Cache hit
        MetadataCache-->>Mf4Reader: cached_channel
        deactivate MetadataCache
        Mf4Reader-->>Client: Channel
    else Cache miss
        MetadataCache-->>Mf4Reader: None
        deactivate MetadataCache
        
        Mf4Reader->>BlockParser: parse_channel_by_name("Engine_Speed")
        activate BlockParser
        BlockParser->>FileSystem: read(channel_data)
        FileSystem-->>BlockParser: bytes
        BlockParser-->>Mf4Reader: Channel
        deactivate BlockParser
        
        Mf4Reader->>MetadataCache: put("Engine_Speed", channel)
        activate MetadataCache
        MetadataCache->>MetadataCache: check_cache_size()
        
        alt Cache full
            MetadataCache->>MetadataCache: evict_lru()
        end
        
        MetadataCache-->>Mf4Reader: cached
        deactivate MetadataCache
        
        Mf4Reader-->>Client: Channel
    end
    
    deactivate Mf4Reader
```

---

## 6. 并发处理序列图

### 6.1 多线程读取

```mermaid
sequenceDiagram
    participant Client
    participant ThreadPool
    participant Mf4Reader
    participant FileSystem
    participant ResultAggregator

    Client->>ThreadPool: submit_read_tasks([file1, file2, file3])
    activate ThreadPool
    
    par Thread 1
        ThreadPool->>Mf4Reader: open(file1)
        activate Mf4Reader
        Mf4Reader->>FileSystem: read(file1)
        FileSystem-->>Mf4Reader: data
        Mf4Reader->>ResultAggregator: add_result(file1_result)
        deactivate Mf4Reader
    and Thread 2
        ThreadPool->>Mf4Reader: open(file2)
        activate Mf4Reader
        Mf4Reader->>FileSystem: read(file2)
        FileSystem-->>Mf4Reader: data
        Mf4Reader->>ResultAggregator: add_result(file2_result)
        deactivate Mf4Reader
    and Thread 3
        ThreadPool->>Mf4Reader: open(file3)
        activate Mf4Reader
        Mf4Reader->>FileSystem: read(file3)
        FileSystem-->>Mf4Reader: data
        Mf4Reader->>ResultAggregator: add_result(file3_result)
        deactivate Mf4Reader
    end
    
    ThreadPool->>ResultAggregator: get_all_results()
    activate ResultAggregator
    ResultAggregator-->>ThreadPool: [result1, result2, result3]
    deactivate ResultAggregator
    
    ThreadPool-->>Client: all_results
    deactivate ThreadPool
```