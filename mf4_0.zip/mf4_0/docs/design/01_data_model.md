# 数据模型设计

## 1. MF4 文件结构模型

### 1.1 文件整体结构

```
┌─────────────────────────────────────────────────────────────┐
│                      MF4 File Structure                      │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  IDBLOCK (Identification Block) - 64 bytes           │   │
│  │  - File Identifier: "MDF     "                        │   │
│  │  - Version String                                     │   │
│  │  - Program Identifier                                 │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                               │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  HDBLOCK (Header Block)                               │   │
│  │  - Links to DG, TX, PR, SR blocks                    │   │
│  │  - Start Time, Author, Organization                  │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                               │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  DG blocks (Data Group Blocks)                         │   │
│  │  - CG block (Channel Group)                           │   │
│  │    - CN blocks (Channels)                             │   │
│  │    - CC blocks (Channel Conversion)                   │   │
│  │  - Data Records                                       │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                               │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  Supporting Blocks                                     │   │
│  │  - TXBLOCK (Text Block)                               │   │
│  │  - PRBLOCK (Program Block)                           │   │
│  │  - SRBLOCK (Sample Reduction)                        │   │
│  │  - ATBLOCK (Attachment)                               │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. 核心数据模型

### 2.1 UML 类图 (Mermaid)

```mermaid
classDiagram
    class Mf4File {
        +FileHeader header
        +List~DataGroup~ dataGroups
        +List~Attachment~ attachments
        +Metadata metadata
        +read(path: str)
        +write(path: str)
        +get_channel(name: str)
        +get_channels()
        +get_time_channel()
    }

    class FileHeader {
        +str version
        +str program_id
        +datetime start_time
        +str author
        +str organization
        +str project
        +str subject
        +datetime end_time
        +validate()
    }

    class DataGroup {
        +int id
        +List~ChannelGroup~ channelGroups
        +RecordReader reader
        +int record_count
        +get_channel_group()
        +read_records(start, count)
        +get_all_channels()
    }

    class ChannelGroup {
        +int id
        +str name
        +str comment
        +List~Channel~ channels
        +List~ChannelConversion~ conversions
        +int record_id
        +int cycle_count
        +int data_group_id
        +get_channel(name)
        +get_record_size()
    }

    class Channel {
        +int id
        +str name
        +str unit
        +str comment
        +ChannelType type
        +DataType data_type
        +int bit_offset
        +int byte_offset
        +int bit_count
        +int channel_group_id
        +ChannelConversion conversion
        +ChannelSource source
        +get_values()
        +get_value_at(index)
    }

    class ChannelConversion {
        +int id
        +ConversionType type
        +float a
        +float b
        +float c
        +float d
        +List~float~ coeffs
        +convert(value)
        +inverse(value)
    }

    class ChannelSource {
        +str name
        +str path
        +str comment
        +SourceType type
    }

    class Signal {
        +Channel channel
        +List~float~ timestamps
        +List~any~ values
        +str unit
        +str name
        +get_sample_rate()
        +interpolate(time)
        +get_statistics()
    }

    class Attachment {
        +int id
        +str filename
        +bytes content
        +str mime_type
        +datetime create_time
        +save_to(path)
    }

    class Metadata {
        +dict custom_fields
        +add(key, value)
        +get(key)
        +remove(key)
    }

    Mf4File "1" *-- "1" FileHeader
    Mf4File "1" *-- "0..*" DataGroup
    Mf4File "1" *-- "0..*" Attachment
    Mf4File "1" *-- "1" Metadata
    DataGroup "1" *-- "1..*" ChannelGroup
    ChannelGroup "1" *-- "1..*" Channel
    Channel "1" o-- "0..1" ChannelConversion
    Channel "1" o-- "0..1" ChannelSource
    Signal "1" --> "1" Channel
```

---

## 3. 枚举类型定义

### 3.1 ChannelType (通道类型)

```python
# Python
class ChannelType(Enum):
    VALUE = 0           # 数据通道
    MASTER = 1          # 主通道（时间轴）
    VIRTUAL_MASTER = 2  # 虚拟主通道
    SYNC = 3            # 同步通道
```

```java
// Java
public enum ChannelType {
    VALUE(0),
    MASTER(1),
    VIRTUAL_MASTER(2),
    SYNC(3);
}
```

### 3.2 DataType (数据类型)

```python
# Python
class DataType(Enum):
    # 整数类型
    UINT8 = 0
    UINT16 = 1
    UINT32 = 2
    UINT64 = 3
    INT8 = 4
    INT16 = 5
    INT32 = 6
    INT64 = 7
    # 浮点类型
    FLOAT32 = 8
    FLOAT64 = 9
    # 字符串类型
    STRING_UTF8 = 10
    STRING_UTF16 = 11
    STRING_LATIN1 = 12
    # 字节数组
    BYTE_ARRAY = 13
    # 布尔类型
    BOOL = 14
```

### 3.3 ConversionType (转换类型)

```python
class ConversionType(Enum):
    NONE = 0                    # 无转换
    LINEAR = 1                  # 线性转换: y = a*x + b
    RATIONAL = 2                # 有理转换: y = (a*x + b) / (c*x + d)
    ALGEBRAIC = 3               # 代数转换: 公式字符串
    TABULAR = 4                 # 表格转换
    TEXT = 5                    # 文本转换
    DATE = 6                    # 日期转换
```

---

## 4. 数据模型 JSON Schema

### 4.1 Channel JSON Schema

```json
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "Channel",
  "type": "object",
  "required": ["id", "name", "type", "data_type"],
  "properties": {
    "id": {
      "type": "integer",
      "description": "Channel unique identifier"
    },
    "name": {
      "type": "string",
      "description": "Channel name"
    },
    "unit": {
      "type": "string",
      "description": "Physical unit"
    },
    "comment": {
      "type": "string",
      "description": "Channel description"
    },
    "type": {
      "$ref": "#/definitions/ChannelType"
    },
    "data_type": {
      "$ref": "#/definitions/DataType"
    },
    "bit_offset": {
      "type": "integer",
      "minimum": 0,
      "default": 0
    },
    "byte_offset": {
      "type": "integer",
      "minimum": 0
    },
    "bit_count": {
      "type": "integer",
      "minimum": 1
    },
    "conversion": {
      "$ref": "#/definitions/ChannelConversion"
    }
  },
  "definitions": {
    "ChannelType": {
      "type": "string",
      "enum": ["VALUE", "MASTER", "VIRTUAL_MASTER", "SYNC"]
    },
    "DataType": {
      "type": "string",
      "enum": ["UINT8", "UINT16", "UINT32", "UINT64", 
               "INT8", "INT16", "INT32", "INT64",
               "FLOAT32", "FLOAT64", "STRING_UTF8", "BOOL"]
    },
    "ChannelConversion": {
      "type": "object",
      "properties": {
        "type": { "$ref": "#/definitions/ConversionType" },
        "a": { "type": "number" },
        "b": { "type": "number" },
        "c": { "type": "number" },
        "d": { "type": "number" }
      }
    }
  }
}
```

---

## 5. 数据关系说明

### 5.1 实体关系图 (ER Diagram)

```mermaid
erDiagram
    MF4_FILE ||--|| FILE_HEADER : contains
    MF4_FILE ||--o{ DATA_GROUP : contains
    MF4_FILE ||--o{ ATTACHMENT : contains
    MF4_FILE ||--o{ METADATA : has
    
    DATA_GROUP ||--o{ CHANNEL_GROUP : contains
    DATA_GROUP ||--|{ RECORD_DATA : contains
    
    CHANNEL_GROUP ||--o{ CHANNEL : contains
    CHANNEL_GROUP ||--o{ CHANNEL_CONVERSION : has
    
    CHANNEL ||--o| CHANNEL_CONVERSION : uses
    CHANNEL ||--o| CHANNEL_SOURCE : references
    
    CHANNEL ||--o{ SIGNAL : produces
    
    CHANNEL_GROUP ||--|{ RECORD : generates
    RECORD ||--o{ VALUE : contains

    MF4_FILE {
        string file_path PK
        string version
        datetime created_at
        datetime modified_at
    }
    
    FILE_HEADER {
        int id PK
        string version
        string program_id
        datetime start_time
        string author
        string organization
    }
    
    DATA_GROUP {
        int id PK
        int file_id FK
        int sequence
        int data_section_offset
    }
    
    CHANNEL_GROUP {
        int id PK
        int data_group_id FK
        string name
        string comment
        int cycle_count
    }
    
    CHANNEL {
        int id PK
        int channel_group_id FK
        int conversion_id FK
        string name UK
        string unit
        string comment
        string data_type
        int byte_offset
        int bit_offset
        int bit_count
    }
    
    CHANNEL_CONVERSION {
        int id PK
        string conversion_type
        float a
        float b
        float c
        float d
    }
    
    SIGNAL {
        int id PK
        int channel_id FK
        float[] timestamps
        float[] values
    }
```

---

## 6. 数据流模型

### 6.1 读取流程数据流

```
┌─────────┐    ┌──────────┐    ┌─────────────┐    ┌──────────┐
│ MF4    │    │ Block    │    │ Record     │    │ Signal   │
│ File   │───▶│ Parser   │───▶│ Decoder    │───▶│ Object   │
│ (Disk) │    │          │    │             │    │          │
└─────────┘    └──────────┘    └─────────────┘    └──────────┘
     │              │                  │                │
     ▼              ▼                  ▼                ▼
  Binary         Metadata          Raw Data         Structured
  Bytes          Blocks            Bytes            Values
                 (JSON)
```

### 6.2 写入流程数据流

```
┌──────────┐    ┌─────────────┐    ┌──────────┐    ┌─────────┐
│ Signal   │    │ Record     │    │ Block    │    │ MF4    │
│ Object   │───▶│ Encoder    │───▶│ Builder  │───▶│ File   │
│          │    │             │    │          │    │ (Disk) │
└──────────┘    └─────────────┘    └──────────┘    └─────────┘
     │                │                  │               │
     ▼                ▼                  ▼               ▼
 Structured      Raw Data           Metadata        Binary
 Values          Bytes              Blocks          Bytes
```

---

## 7. 内存模型

### 7.1 流式读取内存布局

```
┌─────────────────────────────────────────────────────┐
│                    Memory Layout                     │
├─────────────────────────────────────────────────────┤
│                                                     │
│  ┌─────────────┐     ┌──────────────────────────┐  │
│  │  Metadata   │     │   Record Buffer Pool     │  │
│  │  (常驻内存)  │     │   (环形缓冲区)            │  │
│  │             │     │                          │  │
│  │  - Header   │     │  ┌────┬────┬────┬────┐  │  │
│  │  - Channels │     │  │ R0 │ R1 │ R2 │ R3 │  │  │
│  │  - Groups   │     │  └────┴────┴────┴────┘  │  │
│  │  (~1MB)     │     │  (可配置大小，默认16MB)   │  │
│  └─────────────┘     └──────────────────────────┘  │
│                                                     │
│  ┌─────────────────────────────────────────────┐  │
│  │          File Memory Map (可选)              │  │
│  │  - 按需映射数据区域                            │  │
│  │  - 避免全量加载到内存                          │  │
│  └─────────────────────────────────────────────┘  │
│                                                     │
└─────────────────────────────────────────────────────┘
```

### 7.2 内存估算

| 组件 | 典型大小 | 说明 |
|------|----------|------|
| FileHeader | ~1KB | 文件头元数据 |
| Channel 定义 | ~100 bytes/channel | 每个通道的元数据 |
| ChannelGroup | ~500 bytes/group | 每个通道组的元数据 |
| Record Buffer | 可配置 (16MB) | 流式读取缓冲区 |
| 峰值内存 | < 100MB | 10,000 通道 + 缓冲区 |

---

## 8. 性能考虑

### 8.1 延迟加载策略

```python
class Channel:
    def __init__(self, metadata):
        self._metadata = metadata
        self._values = None  # 延迟加载
    
    @property
    def values(self):
        if self._values is None:
            self._values = self._load_values()
        return self._values
    
    def _load_values(self):
        # 从文件中按需加载
        pass
```

### 8.2 缓存策略

```python
from functools import lru_cache

class Mf4Reader:
    @lru_cache(maxsize=1000)
    def get_channel_metadata(self, channel_id: int) -> Channel:
        # 缓存通道元数据
        pass
```
