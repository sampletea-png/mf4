package com.mf4.enums;

/**
 * 通道类型枚举
 * 
 * 定义 MF4 文件中通道的功能类型，用于区分数据通道和时间轴通道。
 *
 * Example:
 * <pre>
 * Channel channel = new Channel();
 * channel.setType(ChannelType.MASTER); // 设置为时间轴通道
 * </pre>
 */
public enum ChannelType {
    
    /** 数据通道，存储实际测量数据 */
    VALUE(0),
    
    /** 主通道（时间轴） */
    MASTER(1),
    
    /** 虚拟主通道，通过计算生成时间轴 */
    VIRTUAL_MASTER(2),
    
    /** 同步通道，用于同步多个数据源 */
    SYNC(3);
    
    private final int code;
    
    ChannelType(int code) {
        this.code = code;
    }
    
    public int getCode() {
        return code;
    }
    
    public static ChannelType fromCode(int code) {
        for (ChannelType type : values()) {
            if (type.code == code) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown channel type code: " + code);
    }
}