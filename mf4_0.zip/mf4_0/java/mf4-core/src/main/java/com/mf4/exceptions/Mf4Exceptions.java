package com.mf4.exceptions;

/**
 * 文件未找到异常
 * 
 * 当指定的 MF4 文件不存在时抛出。
 */
public class Mf4FileNotFoundException extends Mf4Exception {
    
    public Mf4FileNotFoundException(String filePath) {
        super("MF4 file not found", filePath);
    }
}

/**
 * 文件损坏异常
 * 
 * 当 MF4 文件结构损坏或数据不完整时抛出。
 */
class Mf4CorruptedFileException extends Mf4Exception {
    
    private final String blockType;
    private final Long offset;
    
    public Mf4CorruptedFileException(String message, String filePath) {
        super(message, filePath);
        this.blockType = null;
        this.offset = null;
    }
    
    public Mf4CorruptedFileException(String message, String filePath, 
                                     String blockType, Long offset) {
        super(message, filePath);
        this.blockType = blockType;
        this.offset = offset;
    }
    
    public String getBlockType() {
        return blockType;
    }
    
    public Long getOffset() {
        return offset;
    }
}

/**
 * 版本不支持异常
 * 
 * 当尝试读取不支持的 MF4 版本时抛出。
 */
class Mf4UnsupportedVersionException extends Mf4Exception {
    
    private final String version;
    private final String[] supportedVersions;
    
    public Mf4UnsupportedVersionException(String version, String filePath) {
        super("Unsupported MF4 version: " + version, filePath);
        this.version = version;
        this.supportedVersions = new String[]{"4.00", "4.10", "4.11"};
    }
    
    public String getVersion() {
        return version;
    }
    
    public String[] getSupportedVersions() {
        return supportedVersions;
    }
}

/**
 * 通道未找到异常
 * 
 * 当请求的通道在 MF4 文件中不存在时抛出。
 */
class Mf4ChannelNotFoundException extends Mf4Exception {
    
    private final String channelName;
    
    public Mf4ChannelNotFoundException(String channelName, String filePath) {
        super("Channel not found: '" + channelName + "'", filePath);
        this.channelName = channelName;
    }
    
    public String getChannelName() {
        return channelName;
    }
}

/**
 * 验证失败异常
 * 
 * 当数据验证失败时抛出。
 */
class Mf4ValidationException extends Mf4Exception {
    
    private final String[] validationErrors;
    
    public Mf4ValidationException(String message, String filePath, 
                                    String[] validationErrors) {
        super(message, filePath, validationErrors);
        this.validationErrors = validationErrors;
    }
    
    public String[] getValidationErrors() {
        return validationErrors;
    }
}