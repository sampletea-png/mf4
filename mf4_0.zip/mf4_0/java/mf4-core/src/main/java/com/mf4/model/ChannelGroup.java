package com.mf4.model;

import java.util.ArrayList;
import java.util.List;

/**
 * 通道组数据模型
 * 
 * 一组共享相同时间轴和采样率的测量通道集合。
 */
public class ChannelGroup {
    
    private int id;
    private String name;
    private String comment;
    private List<Channel> channels = new ArrayList<>();
    private int dataGroupId;
    private int recordId;
    private long cycleCount;
    private long dataSectionOffset;
    private int recordSize;
    
    /**
     * 添加通道
     */
    public void addChannel(Channel channel) {
        channel.setChannelGroupId(this.id);
        channels.add(channel);
        updateRecordSize();
    }
    
    /**
     * 获取通道
     */
    public Channel getChannel(String name) {
        for (Channel ch : channels) {
            if (ch.getName().equals(name)) {
                return ch;
            }
        }
        throw new IllegalArgumentException("Channel not found: " + name);
    }
    
    /**
     * 更新记录大小
     */
    private void updateRecordSize() {
        int totalBits = 0;
        for (Channel ch : channels) {
            totalBits += ch.getBitCount();
        }
        recordSize = (totalBits + 7) / 8;
    }
    
    /**
     * 验证
     */
    public List<String> validate() {
        List<String> errors = new ArrayList<>();
        if (name == null || name.isEmpty()) {
            errors.add("ChannelGroup name is required");
        }
        if (recordSize < 0) {
            errors.add("Invalid record_size: " + recordSize);
        }
        return errors;
    }
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }
    
    public List<Channel> getChannels() { return channels; }
    public void setChannels(List<Channel> channels) { this.channels = channels; }
    
    public int getDataGroupId() { return dataGroupId; }
    public void setDataGroupId(int dataGroupId) { this.dataGroupId = dataGroupId; }
    
    public int getRecordId() { return recordId; }
    public void setRecordId(int recordId) { this.recordId = recordId; }
    
    public long getCycleCount() { return cycleCount; }
    public void setCycleCount(long cycleCount) { this.cycleCount = cycleCount; }
    
    public long getDataSectionOffset() { return dataSectionOffset; }
    public void setDataSectionOffset(long dataSectionOffset) { this.dataSectionOffset = dataSectionOffset; }
    
    public int getRecordSize() { return recordSize; }
    public void setRecordSize(int recordSize) { this.recordSize = recordSize; }
    
    @Override
    public String toString() {
        return "ChannelGroup{name='" + name + "', channels=" + channels.size() + "}";
    }
}