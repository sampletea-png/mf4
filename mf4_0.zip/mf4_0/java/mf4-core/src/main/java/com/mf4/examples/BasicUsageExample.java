package com.mf4.examples;

import com.mf4.Mf4Reader;
import com.mf4.Mf4Writer;
import com.mf4.config.Mf4Config;
import com.mf4.enums.DataType;
import com.mf4.enums.ChannelType;
import com.mf4.model.*;
import java.util.Map;
import java.util.HashMap;

/**
 * MF4 SDK 基本使用示例
 *
 * 演示如何读取和写入 MF4 文件。
 */
public class BasicUsageExample {
    
    public static void main(String[] args) {
        try {
            basicWriteExample();
            basicReadExample();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    /**
     * 基本写入示例
     *
     * 演示如何创建一个简单的 MF4 文件。
     */
    public static void basicWriteExample() throws Exception {
        System.out.println("=== 基本写入示例 ===");
        
        // 创建 MF4 文件
        try (Mf4Writer writer = Mf4Writer.create("output_basic.mf4")) {
            // 设置文件头信息
            writer.setHeader(FileHeader.builder()
                .author("John Doe")
                .organization("Example Corp")
                .project("Engine Testing")
                .comment("Sample measurement data")
                .build());
            
            // 添加通道组
            int cgId = writer.addChannelGroup("Engine_Data", "Engine measurement parameters");
            
            // 添加测量通道
            writer.addChannel(cgId, Channel.builder()
                .name("Engine_Speed")
                .unit("rpm")
                .dataType(DataType.FLOAT64)
                .type(ChannelType.VALUE)
                .comment("Engine rotational speed")
                .build());
            
            writer.addChannel(cgId, Channel.builder()
                .name("Vehicle_Speed")
                .unit("km/h")
                .dataType(DataType.FLOAT64)
                .build());
            
            writer.addChannel(cgId, Channel.builder()
                .name("Throttle_Position")
                .unit("%")
                .dataType(DataType.FLOAT64)
                .build());
            
            // 生成模拟数据
            int sampleCount = 1000;
            double[] timestamps = new double[sampleCount];
            double[] engineSpeed = new double[sampleCount];
            double[] vehicleSpeed = new double[sampleCount];
            double[] throttle = new double[sampleCount];
            
            for (int i = 0; i < sampleCount; i++) {
                timestamps[i] = i * 0.01;  // 10秒测量
                engineSpeed[i] = 3000 + 500 * Math.sin(timestamps[i]);
                vehicleSpeed[i] = Math.random() * 120;
                throttle[i] = Math.random() * 100;
            }
            
            // 写入数据
            Map<String, double[]> data = new HashMap<>();
            data.put("Engine_Speed", engineSpeed);
            data.put("Vehicle_Speed", vehicleSpeed);
            data.put("Throttle_Position", throttle);
            
            writer.writeData(cgId, timestamps, data);
        }
        
        System.out.println("文件已创建: output_basic.mf4");
    }
    
    /**
     * 基本读取示例
     *
     * 演示如何读取 MF4 文件中的数据。
     */
    public static void basicReadExample() throws Exception {
        System.out.println("\n=== 基本读取示例 ===");
        
        try (Mf4Reader reader = Mf4Reader.open("output_basic.mf4")) {
            // 获取文件头信息
            FileHeader header = reader.getHeader();
            System.out.println("文件版本: " + header.getVersion());
            System.out.println("作者: " + header.getAuthor());
            System.out.println("组织: " + header.getOrganization());
            
            // 获取所有通道
            var channels = reader.getChannels();
            System.out.println("\n通道数量: " + channels.size());
            
            for (Channel ch : channels) {
                System.out.println("  - " + ch.getName() + " (" + ch.getUnit() + ")");
            }
        }
    }
}