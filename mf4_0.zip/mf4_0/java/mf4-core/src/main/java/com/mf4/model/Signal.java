package com.mf4.model;

import java.util.Arrays;

/**
 * 信号数据模型
 * 
 * 包含完整的测量信号，包括时间轴、数值和元信息。
 *
 * Example:
 * <pre>
 * double[] timestamps = {0.0, 0.1, 0.2};
 * double[] values = {100.0, 200.0, 300.0};
 * 
 * Signal signal = new Signal("Engine_Speed", timestamps, values, "rpm");
 * System.out.println("Sample count: " + signal.getLength());
 * </pre>
 */
public class Signal {
    
    private String name;
    private double[] timestamps;
    private double[] values;
    private String unit;
    private String comment;
    private String source;
    
    /**
     * 创建信号
     * 
     * @param name 信号名称
     * @param timestamps 时间戳数组
     * @param values 数值数组
     * @param unit 单位
     */
    public Signal(String name, double[] timestamps, double[] values, String unit) {
        this.name = name;
        this.timestamps = timestamps != null ? timestamps : new double[0];
        this.values = values != null ? values : new double[0];
        this.unit = unit != null ? unit : "";
    }
    
    /**
     * 获取数据点数量
     */
    public int getLength() {
        return values.length;
    }
    
    /**
     * 获取指定索引的数据
     */
    public double[] get(int index) {
        return new double[]{timestamps[index], values[index]};
    }
    
    /**
     * 计算平均采样率
     */
    public double getSampleRate() {
        if (timestamps.length < 2) {
            return 0.0;
        }
        double duration = timestamps[timestamps.length - 1] - timestamps[0];
        if (duration == 0) {
            return 0.0;
        }
        return timestamps.length / duration;
    }
    
    /**
     * 计算统计信息
     */
    public SignalStatistics getStatistics() {
        if (values.length == 0) {
            return new SignalStatistics(0, 0, 0, 0, 0);
        }
        
        double min = values[0];
        double max = values[0];
        double sum = 0;
        
        for (double v : values) {
            if (v < min) min = v;
            if (v > max) max = v;
            sum += v;
        }
        
        double mean = sum / values.length;
        
        double varianceSum = 0;
        for (double v : values) {
            varianceSum += Math.pow(v - mean, 2);
        }
        double std = Math.sqrt(varianceSum / values.length);
        
        return new SignalStatistics(min, max, mean, std, values.length);
    }
    
    /**
     * 获取指定时间的值（线性插值）
     */
    public double getValueAtTime(double time) {
        if (timestamps.length == 0) {
            return 0.0;
        }
        
        // 二分查找
        int idx = Arrays.binarySearch(timestamps, time);
        if (idx >= 0) {
            return values[idx];
        }
        
        idx = -idx - 1;
        if (idx == 0) {
            return values[0];
        }
        if (idx >= timestamps.length) {
            return values[timestamps.length - 1];
        }
        
        // 线性插值
        double t1 = timestamps[idx - 1];
        double t2 = timestamps[idx];
        double v1 = values[idx - 1];
        double v2 = values[idx];
        double ratio = (time - t1) / (t2 - t1);
        
        return v1 + ratio * (v2 - v1);
    }
    
    // Getters and Setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public double[] getTimestamps() { return timestamps; }
    public void setTimestamps(double[] timestamps) { this.timestamps = timestamps; }
    
    public double[] getValues() { return values; }
    public void setValues(double[] values) { this.values = values; }
    
    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }
    
    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }
    
    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }
    
    @Override
    public String toString() {
        return "Signal{name='" + name + "', samples=" + values.length + "}";
    }
    
    /**
     * 信号统计信息
     */
    public static class SignalStatistics {
        public final double min;
        public final double max;
        public final double mean;
        public final double std;
        public final int count;
        
        public SignalStatistics(double min, double max, double mean, double std, int count) {
            this.min = min;
            this.max = max;
            this.mean = mean;
            this.std = std;
            this.count = count;
        }
        
        @Override
        public String toString() {
            return String.format("Statistics{min=%.2f, max=%.2f, mean=%.2f, std=%.2f, count=%d}",
                min, max, mean, std, count);
        }
    }
}