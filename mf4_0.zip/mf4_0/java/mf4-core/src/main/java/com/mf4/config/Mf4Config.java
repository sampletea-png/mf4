package com.mf4.config;

/**
 * MF4 SDK 配置类
 * 
 * 管理 SDK 的各种配置选项。
 *
 * Example:
 * <pre>
 * Mf4Config config = Mf4Config.builder()
 *     .bufferSize(20000)
 *     .cacheSizeMb(200)
 *     .validateOnWrite(true)
 *     .build();
 * 
 * Mf4Reader reader = new Mf4Reader("file.mf4", config);
 * </pre>
 */
public class Mf4Config {
    
    // I/O 配置
    private int bufferSize = 10000;
    private boolean useMemoryMapping = true;
    
    // 缓存配置
    private boolean cacheEnabled = true;
    private int cacheSizeMb = 100;
    private String cacheStrategy = "lru";
    
    // 性能配置
    private int maxWorkers = 0;
    private int prefetchSize = 3;
    private int batchWriteSize = 50000;
    
    // 验证配置
    private boolean validateOnRead = false;
    private boolean validateOnWrite = true;
    private boolean strictMode = false;
    
    // 日志配置
    private String logLevel = "INFO";
    private String logFile = null;
    
    // 兼容性配置
    private boolean tolerantMode = true;
    private double maxFileSizeGb = 50.0;
    
    /**
     * 获取默认配置
     */
    public static Mf4Config getDefault() {
        return new Mf4Config();
    }
    
    /**
     * 创建高性能配置
     */
    public static Mf4Config highPerformance() {
        Mf4Config config = new Mf4Config();
        config.bufferSize = 50000;
        config.useMemoryMapping = true;
        config.cacheEnabled = true;
        config.cacheSizeMb = 500;
        config.maxWorkers = 8;
        config.prefetchSize = 10;
        config.batchWriteSize = 100000;
        config.validateOnRead = false;
        config.validateOnWrite = false;
        return config;
    }
    
    /**
     * 创建低内存配置
     */
    public static Mf4Config lowMemory() {
        Mf4Config config = new Mf4Config();
        config.bufferSize = 1000;
        config.useMemoryMapping = false;
        config.cacheEnabled = true;
        config.cacheSizeMb = 20;
        config.maxWorkers = 1;
        config.prefetchSize = 1;
        config.batchWriteSize = 5000;
        return config;
    }
    
    /**
     * 创建 Builder
     */
    public static Builder builder() {
        return new Builder();
    }
    
    // Getters
    public int getBufferSize() { return bufferSize; }
    public boolean isUseMemoryMapping() { return useMemoryMapping; }
    public boolean isCacheEnabled() { return cacheEnabled; }
    public int getCacheSizeMb() { return cacheSizeMb; }
    public String getCacheStrategy() { return cacheStrategy; }
    public int getMaxWorkers() { return maxWorkers; }
    public int getPrefetchSize() { return prefetchSize; }
    public int getBatchWriteSize() { return batchWriteSize; }
    public boolean isValidateOnRead() { return validateOnRead; }
    public boolean isValidateOnWrite() { return validateOnWrite; }
    public boolean isStrictMode() { return strictMode; }
    public String getLogLevel() { return logLevel; }
    public String getLogFile() { return logFile; }
    public boolean isTolerantMode() { return tolerantMode; }
    public double getMaxFileSizeGb() { return maxFileSizeGb; }
    
    // Setters
    public void setBufferSize(int bufferSize) { this.bufferSize = bufferSize; }
    public void setUseMemoryMapping(boolean useMemoryMapping) { this.useMemoryMapping = useMemoryMapping; }
    public void setCacheEnabled(boolean cacheEnabled) { this.cacheEnabled = cacheEnabled; }
    public void setCacheSizeMb(int cacheSizeMb) { this.cacheSizeMb = cacheSizeMb; }
    public void setCacheStrategy(String cacheStrategy) { this.cacheStrategy = cacheStrategy; }
    public void setMaxWorkers(int maxWorkers) { this.maxWorkers = maxWorkers; }
    public void setPrefetchSize(int prefetchSize) { this.prefetchSize = prefetchSize; }
    public void setBatchWriteSize(int batchWriteSize) { this.batchWriteSize = batchWriteSize; }
    public void setValidateOnRead(boolean validateOnRead) { this.validateOnRead = validateOnRead; }
    public void setValidateOnWrite(boolean validateOnWrite) { this.validateOnWrite = validateOnWrite; }
    public void setStrictMode(boolean strictMode) { this.strictMode = strictMode; }
    public void setLogLevel(String logLevel) { this.logLevel = logLevel; }
    public void setLogFile(String logFile) { this.logFile = logFile; }
    public void setTolerantMode(boolean tolerantMode) { this.tolerantMode = tolerantMode; }
    public void setMaxFileSizeGb(double maxFileSizeGb) { this.maxFileSizeGb = maxFileSizeGb; }
    
    /**
     * Builder 类
     */
    public static class Builder {
        private Mf4Config config = new Mf4Config();
        
        public Builder bufferSize(int bufferSize) {
            config.bufferSize = bufferSize;
            return this;
        }
        
        public Builder useMemoryMapping(boolean useMemoryMapping) {
            config.useMemoryMapping = useMemoryMapping;
            return this;
        }
        
        public Builder cacheEnabled(boolean cacheEnabled) {
            config.cacheEnabled = cacheEnabled;
            return this;
        }
        
        public Builder cacheSizeMb(int cacheSizeMb) {
            config.cacheSizeMb = cacheSizeMb;
            return this;
        }
        
        public Builder validateOnWrite(boolean validateOnWrite) {
            config.validateOnWrite = validateOnWrite;
            return this;
        }
        
        public Builder validateOnRead(boolean validateOnRead) {
            config.validateOnRead = validateOnRead;
            return this;
        }
        
        public Mf4Config build() {
            return config;
        }
    }
}