package com.mf4.exceptions;

/**
 * MF4 SDK 基础异常类
 * 
 * 所有 MF4 相关异常的基类，提供统一的异常处理接口。
 *
 * Example:
 * <pre>
 * try {
 *     Mf4Reader reader = Mf4Reader.open("file.mf4");
 * } catch (Mf4Exception e) {
 *     System.err.println("Error: " + e.getMessage());
 * }
 * </pre>
 */
public class Mf4Exception extends Exception {
    
    private final String filePath;
    private final String[] details;
    
    /**
     * 创建异常
     * 
     * @param message 错误消息
     */
    public Mf4Exception(String message) {
        super(message);
        this.filePath = null;
        this.details = new String[0];
    }
    
    /**
     * 创建异常
     * 
     * @param message 错误消息
     * @param filePath 相关文件路径
     */
    public Mf4Exception(String message, String filePath) {
        super(filePath != null ? message + " (file: " + filePath + ")" : message);
        this.filePath = filePath;
        this.details = new String[0];
    }
    
    /**
     * 创建异常
     * 
     * @param message 错误消息
     * @param filePath 文件路径
     * @param details 详细信息
     */
    public Mf4Exception(String message, String filePath, String[] details) {
        super(buildMessage(message, filePath, details));
        this.filePath = filePath;
        this.details = details != null ? details : new String[0];
    }
    
    private static String buildMessage(String message, String filePath, String[] details) {
        StringBuilder sb = new StringBuilder(message);
        if (filePath != null) {
            sb.append(" (file: ").append(filePath).append(")");
        }
        if (details != null && details.length > 0) {
            sb.append("\nDetails: ");
            for (String detail : details) {
                sb.append(detail).append(", ");
            }
        }
        return sb.toString();
    }
    
    public String getFilePath() {
        return filePath;
    }
    
    public String[] getDetails() {
        return details;
    }
}