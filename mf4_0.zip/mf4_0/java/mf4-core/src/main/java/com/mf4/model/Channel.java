package com.mf4.model;

import com.mf4.enums.DataType;
import com.mf4.enums.ChannelType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 通道数据模型
 * 
 * 代表 MF4 文件中的一个测量通道，存储通道的元数据和数据位置信息。
 *
 * Example:
 * <pre>
 * Channel channel = Channel.builder()
 *     .name("Engine_Speed")
 *     .unit("rpm")
 *     .dataType(DataType.FLOAT64)
 *     .type(ChannelType.VALUE)
 *     .build();
 * </pre>
 */
public class Channel {
    
    /** 通道标识符 */
    private int id;
    
    /** 通道名称 */
    private String name;
    
    /** 物理单位 */
    private String unit;
    
    /** 通道描述 */
    private String comment;
    
    /** 通道类型 */
    private ChannelType type;
    
    /** 数据类型 */
    private DataType dataType;
    
    /** 位偏移量 */
    private int bitOffset;
    
    /** 字节偏移量 */
    private int byteOffset;
    
    /** 数据位数 */
    private int bitCount;
    
    /** 所属通道组ID */
    private int channelGroupId;
    
    /** 数据转换规则 */
    private ChannelConversion conversion;
    
    /** 自定义字段 */
    private Map<String, Object> customFields;
    
    /**
     * 创建 Channel Builder
     * 
     * @return Builder 实例
     */
    public static Builder builder() {
        return new Builder();
    }
    
    /**
     * 获取通道数据的字节大小
     * 
     * @return 字节大小
     */
    public int getByteSize() {
        return (bitCount + 7) / 8;
    }
    
    /**
     * 验证通道数据
     * 
     * @return 验证错误列表
     */
    public List<String> validate() {
        List<String> errors = new ArrayList<>();
        
        if (name == null || name.isEmpty()) {
            errors.add("Channel name is required");
        }
        
        if (bitOffset < 0 || bitOffset > 7) {
            errors.add("bitOffset must be 0-7, got " + bitOffset);
        }
        
        if (byteOffset < 0) {
            errors.add("byteOffset must be >= 0, got " + byteOffset);
        }
        
        if (bitCount < 1) {
            errors.add("bitCount must be >= 1, got " + bitCount);
        }
        
        return errors;
    }
    
    /**
     * 转换为 Map
     * 
     * @return 包含通道信息的 Map
     */
    public Map<String, Object> toMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("id", id);
        map.put("name", name);
        map.put("unit", unit);
        map.put("comment", comment);
        map.put("type", type != null ? type.name() : null);
        map.put("dataType", dataType != null ? dataType.name() : null);
        map.put("bitOffset", bitOffset);
        map.put("byteOffset", byteOffset);
        map.put("bitCount", bitCount);
        map.put("channelGroupId", channelGroupId);
        return map;
    }
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }
    
    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }
    
    public ChannelType getType() { return type; }
    public void setType(ChannelType type) { this.type = type; }
    
    public DataType getDataType() { return dataType; }
    public void setDataType(DataType dataType) { this.dataType = dataType; }
    
    public int getBitOffset() { return bitOffset; }
    public void setBitOffset(int bitOffset) { this.bitOffset = bitOffset; }
    
    public int getByteOffset() { return byteOffset; }
    public void setByteOffset(int byteOffset) { this.byteOffset = byteOffset; }
    
    public int getBitCount() { return bitCount; }
    public void setBitCount(int bitCount) { this.bitCount = bitCount; }
    
    public int getChannelGroupId() { return channelGroupId; }
    public void setChannelGroupId(int channelGroupId) { this.channelGroupId = channelGroupId; }
    
    public ChannelConversion getConversion() { return conversion; }
    public void setConversion(ChannelConversion conversion) { this.conversion = conversion; }
    
    public Map<String, Object> getCustomFields() { return customFields; }
    public void setCustomFields(Map<String, Object> customFields) { this.customFields = customFields; }
    
    /**
     * Channel Builder 类
     */
    public static class Builder {
        private Channel channel = new Channel();
        
        public Builder id(int id) {
            channel.id = id;
            return this;
        }
        
        public Builder name(String name) {
            channel.name = name;
            return this;
        }
        
        public Builder unit(String unit) {
            channel.unit = unit;
            return this;
        }
        
        public Builder comment(String comment) {
            channel.comment = comment;
            return this;
        }
        
        public Builder type(ChannelType type) {
            channel.type = type;
            return this;
        }
        
        public Builder dataType(DataType dataType) {
            channel.dataType = dataType;
            return this;
        }
        
        public Builder bitOffset(int bitOffset) {
            channel.bitOffset = bitOffset;
            return this;
        }
        
        public Builder byteOffset(int byteOffset) {
            channel.byteOffset = byteOffset;
            return this;
        }
        
        public Builder bitCount(int bitCount) {
            channel.bitCount = bitCount;
            return this;
        }
        
        public Builder channelGroupId(int channelGroupId) {
            channel.channelGroupId = channelGroupId;
            return this;
        }
        
        public Builder conversion(ChannelConversion conversion) {
            channel.conversion = conversion;
            return this;
        }
        
        public Channel build() {
            if (channel.type == null) {
                channel.type = ChannelType.VALUE;
            }
            if (channel.dataType == null) {
                channel.dataType = DataType.FLOAT64;
            }
            if (channel.customFields == null) {
                channel.customFields = new HashMap<>();
            }
            return channel;
        }
    }
    
    @Override
    public String toString() {
        return "Channel{name='" + name + "', unit='" + unit + "'}";
    }
}