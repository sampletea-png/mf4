package com.mf4;

import com.mf4.config.Mf4Config;
import com.mf4.enums.DataType;
import com.mf4.enums.ChannelType;
import com.mf4.exceptions.Mf4Exception;
import com.mf4.exceptions.Mf4WriteError;
import com.mf4.exceptions.Mf4ValidationException;
import com.mf4.model.*;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.Instant;
import java.util.*;

/**
 * MF4 文件写入器
 * 
 * 提供完整的 MF4 文件写入功能。
 *
 * Example:
 * <pre>
 * try (Mf4Writer writer = Mf4Writer.create("output.mf4")) {
 *     writer.setHeader(FileHeader.builder()
 *         .author("Test")
 *         .project("Demo")
 *         .build());
 *     
 *     int cgId = writer.addChannelGroup("Engine_Data");
 *     writer.addChannel(cgId, Channel.builder()
 *         .name("Speed")
 *         .unit("rpm")
 *         .dataType(DataType.FLOAT64)
 *         .build());
 *     
 *     double[] timestamps = {0.0, 0.1, 0.2};
 *     double[] values = {100.0, 200.0, 300.0};
 *     writer.writeData(cgId, timestamps, Map.of("Speed", values));
 * }
 * </pre>
 */
public class Mf4Writer implements Closeable {
    
    private final String filePath;
    private final Mf4Config config;
    private RandomAccessFile fileHandle;
    private boolean isOpen = false;
    
    private FileHeader header;
    private List<ChannelGroup> channelGroups = new ArrayList<>();
    private List<Attachment> attachments = new ArrayList<>();
    private int idCounter = 0;
    
    /**
     * 创建 Mf4Writer
     * 
     * @param filePath 输出文件路径
     * @param config 配置选项（可选）
     */
    public Mf4Writer(String filePath, Mf4Config config) {
        this.filePath = filePath;
        this.config = config != null ? config : Mf4Config.getDefault();
        
        header = new FileHeader();
    }
    
    /**
     * 上下文管理器方式创建写入器
     * 
     * @param filePath 输出文件路径
     * @return Mf4Writer 实例
     * @throws Mf4Exception 创建失败
     */
    public static Mf4Writer create(String filePath) throws Mf4Exception {
        Mf4Writer writer = new Mf4Writer(filePath, null);
        writer.openFile();
        return writer;
    }
    
    /**
     * 打开文件
     */
    private void openFile() throws Mf4Exception {
        if (isOpen) {
            return;
        }
        
        try {
            fileHandle = new RandomAccessFile(filePath, "rw");
            fileHandle.setLength(0);
            isOpen = true;
            writeIdBlock();
            writeHeaderBlock();
        } catch (FileNotFoundException e) {
            throw new Mf4WriteError("Cannot create file", filePath);
        } catch (IOException e) {
            throw new Mf4WriteError("Failed to create file: " + e.getMessage(), filePath);
        }
    }
    
    /**
     * 写入身份识别块（IDBLOCK）
     */
    private void writeIdBlock() throws IOException {
        fileHandle.seek(0);
        
        // 文件标识符
        fileHandle.write("MDF     ".getBytes("ISO-8859-1"));
        
        // 版本
        String version = header.getVersion();
        byte[] versionBytes = String.format("%-8s", version).getBytes("ISO-8859-1");
        fileHandle.write(versionBytes);
        
        // 程序标识符
        fileHandle.write("        ".getBytes("ISO-8859-1"));
        fileHandle.write("MF4SDK  ".getBytes("ISO-8859-1"));
        
        // 保留字节
        byte[] reserved = new byte[40];
        Arrays.fill(reserved, (byte) 0);
        fileHandle.write(reserved);
    }
    
    /**
     * 写入文件头块（HDBLOCK）
     */
    private void writeHeaderBlock() throws IOException {
        fileHandle.seek(64);
        
        // 块类型
        fileHandle.write("##HD".getBytes("ISO-8859-1"));
        
        // 块大小
        ByteBuffer buffer = ByteBuffer.allocate(2);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        buffer.putShort((short) 104);
        fileHandle.write(buffer.array());
        
        // 链接数量
        buffer.clear();
        buffer.putShort((short) 5);
        fileHandle.write(buffer.array());
        
        // 链接（DG、TX、PR、SR、RDBL）
        for (int i = 0; i < 5; i++) {
            buffer.clear();
            buffer = ByteBuffer.allocate(8);
            buffer.order(ByteOrder.LITTLE_ENDIAN);
            buffer.putLong(0L);
            fileHandle.write(buffer.array());
        }
        
        // 时间戳
        ZonedDateTime startTime = header.getStartTime();
        if (startTime == null) {
            startTime = ZonedDateTime.now(ZoneOffset.UTC);
        }
        long timestampNs = startTime.toInstant().toEpochMilli() * 1_000_000L;
        buffer = ByteBuffer.allocate(8);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        buffer.putLong(timestampNs);
        fileHandle.write(buffer.array());
        
        // 时区和夏令时偏移
        fileHandle.write(new byte[4]);
        
        // 标志
        fileHandle.write(new byte[2]);
        
        // 作者
        String author = header.getAuthor() != null ? header.getAuthor() : "";
        byte[] authorBytes = String.format("%-32s", author).getBytes("ISO-8859-1");
        fileHandle.write(authorBytes);
        
        // 组织
        String org = header.getOrganization() != null ? header.getOrganization() : "";
        byte[] orgBytes = String.format("%-32s", org).getBytes("ISO-8859-1");
        fileHandle.write(orgBytes);
        
        // 项目
        String project = header.getProject() != null ? header.getProject() : "";
        byte[] projectBytes = String.format("%-32s", project).getBytes("ISO-8859-1");
        fileHandle.write(projectBytes);
        
        // 主题
        String subject = header.getSubject() != null ? header.getSubject() : "";
        byte[] subjectBytes = String.format("%-32s", subject).getBytes("ISO-8859-1");
        fileHandle.write(subjectBytes);
    }
    
    /**
     * 设置文件头信息
     * 
     * @param header 文件头实例
     */
    public void setHeader(FileHeader header) {
        this.header = header;
    }
    
    /**
     * 添加通道组
     * 
     * @param name 通道组名称
     * @param comment 描述注释
     * @return 通道组ID
     */
    public int addChannelGroup(String name, String comment) {
        int id = ++idCounter;
        ChannelGroup cg = new ChannelGroup();
        cg.setId(id);
        cg.setName(name);
        cg.setComment(comment);
        channelGroups.add(cg);
        return id;
    }
    
    /**
     * 添加通道组（无注释）
     * 
     * @param name 通道组名称
     * @return 通道组ID
     */
    public int addChannelGroup(String name) {
        return addChannelGroup(name, "");
    }
    
    /**
     * 添加通道
     * 
     * @param cgId 通道组ID
     * @param channel 通道实例
     * @return 通道ID
     */
    public int addChannel(int cgId, Channel channel) throws Mf4Exception {
        ChannelGroup cg = findChannelGroup(cgId);
        if (cg == null) {
            throw new Mf4Exception("Channel group not found: " + cgId, filePath);
        }
        
        int id = ++idCounter;
        channel.setId(id);
        channel.setChannelGroupId(cgId);
        cg.addChannel(channel);
        
        return id;
    }
    
    /**
     * 写入数据
     * 
     * @param cgId 通道组ID
     * @param timestamps 时间戳数组
     * @param data 数据映射（通道名 -> 数值数组）
     * @throws Mf4ValidationException 数据验证失败
     */
    public void writeData(int cgId, double[] timestamps, Map<String, double[]> data) 
            throws Mf4ValidationException, Mf4Exception {
        
        if (config.isValidateOnWrite()) {
            List<String> errors = validateData(cgId, timestamps, data);
            if (!errors.isEmpty()) {
                throw new Mf4ValidationException("Data validation failed", 
                    filePath, errors.toArray(new String[0]));
            }
        }
        
        // 简化实现：写入数据到文件
        try {
            fileHandle.seek(fileHandle.length());
            for (int i = 0; i < timestamps.length; i++) {
                ByteBuffer buffer = ByteBuffer.allocate(8);
                buffer.order(ByteOrder.LITTLE_ENDIAN);
                buffer.putDouble(timestamps[i]);
                fileHandle.write(buffer.array());
                
                for (double[] values : data.values()) {
                    buffer.clear();
                    buffer.putDouble(values[i]);
                    fileHandle.write(buffer.array());
                }
            }
        } catch (IOException e) {
            throw new Mf4WriteError("Failed to write data", filePath);
        }
    }
    
    /**
     * 验证数据
     */
    private List<String> validateData(int cgId, double[] timestamps, Map<String, double[]> data) {
        List<String> errors = new ArrayList<>();
        
        ChannelGroup cg = findChannelGroup(cgId);
        if (cg == null) {
            errors.add("Channel group not found: " + cgId);
            return errors;
        }
        
        // 检查数据长度
        for (Channel channel : cg.getChannels()) {
            if (channel.getName() != null && !data.containsKey(channel.getName())) {
                errors.add("Missing data for channel: " + channel.getName());
            } else if (data.containsKey(channel.getName())) {
                double[] values = data.get(channel.getName());
                if (values.length != timestamps.length) {
                    errors.add(String.format(
                        "Length mismatch for channel %s: %d != %d",
                        channel.getName(), values.length, timestamps.length
                    ));
                }
            }
        }
        
        return errors;
    }
    
    /**
     * 查找通道组
     */
    private ChannelGroup findChannelGroup(int id) {
        for (ChannelGroup cg : channelGroups) {
            if (cg.getId() == id) {
                return cg;
            }
        }
        return null;
    }
    
    /**
     * 添加附件
     * 
     * @param filename 文件名
     * @param content 文件内容
     * @param mimeType MIME类型
     * @return 附件ID
     */
    public int addAttachment(String filename, byte[] content, String mimeType) {
        int id = ++idCounter;
        Attachment att = new Attachment();
        att.setId(id);
        att.setFilename(filename);
        att.setContent(content);
        att.setMimeType(mimeType);
        attachments.add(att);
        return id;
    }
    
    /**
     * 保存文件
     * 
     * @throws Mf4Exception 保存失败
     */
    public void save() throws Mf4Exception {
        if (!isOpen) {
            throw new Mf4WriteError("File not open", filePath);
        }
        
        try {
            fileHandle.getFD().sync();
        } catch (IOException e) {
            throw new Mf4WriteError("Failed to save file", filePath);
        }
    }
    
    /**
     * 关闭文件
     */
    @Override
    public void close() throws IOException {
        if (fileHandle != null) {
            fileHandle.close();
            fileHandle = null;
        }
        isOpen = false;
    }
    
    @Override
    public String toString() {
        return "Mf4Writer{filePath='" + filePath + "', isOpen=" + isOpen + "}";
    }
}