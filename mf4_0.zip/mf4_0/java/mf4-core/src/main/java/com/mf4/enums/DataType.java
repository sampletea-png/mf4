package com.mf4.enums;

/**
 * 数据类型枚举
 * 
 * 定义 MF4 文件中支持的各种数据类型，包括整数、浮点数、字符串等。
 * 每种数据类型对应一个特定的数值编码，符合 ASAM MDF 规范。
 *
 * Example:
 * <pre>
 * DataType type = DataType.FLOAT64;
 * int byteSize = type.getByteSize(); // 8
 * String numpyType = type.getNumpyDtype(); // "float64"
 * </pre>
 */
public enum DataType {
    
    /** 无符号8位整数 (0-255) */
    UINT8(0, 1, "uint8"),
    
    /** 无符号16位整数 (0-65535) */
    UINT16(1, 2, "uint16"),
    
    /** 无符号32位整数 */
    UINT32(2, 4, "uint32"),
    
    /** 无符号64位整数 */
    UINT64(3, 8, "uint64"),
    
    /** 有符号8位整数 (-128 to 127) */
    INT8(4, 1, "int8"),
    
    /** 有符号16位整数 (-32768 to 32767) */
    INT16(5, 2, "int16"),
    
    /** 有符号32位整数 */
    INT32(6, 4, "int32"),
    
    /** 有符号64位整数 */
    INT64(7, 8, "int64"),
    
    /** 32位单精度浮点数 */
    FLOAT32(8, 4, "float32"),
    
    /** 64位双精度浮点数 */
    FLOAT64(9, 8, "float64"),
    
    /** UTF-8编码字符串 */
    STRING_UTF8(10, 0, "object"),
    
    /** UTF-16编码字符串 */
    STRING_UTF16(11, 0, "object"),
    
    /** Latin-1编码字符串 */
    STRING_LATIN1(12, 0, "object"),
    
    /** 字节数组 */
    BYTE_ARRAY(13, 0, "object"),
    
    /** 布尔类型 */
    BOOL(14, 1, "bool");
    
    private final int mdfCode;
    private final int byteSize;
    private final String numpyDtype;
    
    DataType(int mdfCode, int byteSize, String numpyDtype) {
        this.mdfCode = mdfCode;
        this.byteSize = byteSize;
        this.numpyDtype = numpyDtype;
    }
    
    /**
     * 获取 MDF 规范的数值编码
     * 
     * @return MDF 数据类型编码
     */
    public int getMdfCode() {
        return mdfCode;
    }
    
    /**
     * 获取数据类型的字节大小
     * 
     * @return 字节大小，字符串类型返回0（可变长度）
     */
    public int getByteSize() {
        return byteSize;
    }
    
    /**
     * 获取对应的 NumPy 数据类型字符串
     * 
     * @return NumPy 数据类型
     */
    public String getNumpyDtype() {
        return numpyDtype;
    }
    
    /**
     * 从 MDF 编码创建 DataType
     * 
     * @param code MDF 数据类型编码
     * @return 对应的 DataType
     * @throws IllegalArgumentException 如果编码无效
     */
    public static DataType fromMdfCode(int code) {
        for (DataType type : values()) {
            if (type.mdfCode == code) {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown MDF data type code: " + code);
    }
}