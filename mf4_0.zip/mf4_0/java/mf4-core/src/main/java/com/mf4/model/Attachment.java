package com.mf4.model;

import java.time.ZonedDateTime;

/**
 * 附件数据模型
 * 
 * 存储与 MF4 文件相关的附加文件。
 */
public class Attachment {
    
    private int id;
    private String filename;
    private byte[] content;
    private String mimeType;
    private String comment;
    private ZonedDateTime createTime;
    
    /**
     * 获取附件大小
     */
    public int getSize() {
        return content != null ? content.length : 0;
    }
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getFilename() { return filename; }
    public void setFilename(String filename) { this.filename = filename; }
    
    public byte[] getContent() { return content; }
    public void setContent(byte[] content) { this.content = content; }
    
    public String getMimeType() { return mimeType; }
    public void setMimeType(String mimeType) { this.mimeType = mimeType; }
    
    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }
    
    public ZonedDateTime getCreateTime() { return createTime; }
    public void setCreateTime(ZonedDateTime createTime) { this.createTime = createTime; }
    
    @Override
    public String toString() {
        return "Attachment{filename='" + filename + "', size=" + getSize() + " bytes}";
    }
}

/**
 * 通道转换规则模型
 * 
 * 定义如何将原始数据值转换为物理值。
 */
class ChannelConversion {
    
    private int id;
    private String type = "NONE";
    private String name;
    private String comment;
    
    // 线性转换参数: y = a*x + b
    private double a = 1.0;
    private double b = 0.0;
    
    // 有理转换额外参数: y = (a*x + b) / (c*x + d)
    private double c = 0.0;
    private double d = 1.0;
    
    /**
     * 应用转换
     */
    public double apply(double value) {
        if ("NONE".equals(type)) {
            return value;
        } else if ("LINEAR".equals(type)) {
            return a * value + b;
        } else if ("RATIONAL".equals(type)) {
            double denominator = c * value + d;
            if (denominator == 0) {
                throw new ArithmeticException("Division by zero in rational conversion");
            }
            return (a * value + b) / denominator;
        }
        return value;
    }
    
    /**
     * 逆转换
     */
    public double inverse(double value) {
        if ("NONE".equals(type)) {
            return value;
        } else if ("LINEAR".equals(type)) {
            if (a == 0) {
                throw new ArithmeticException("Cannot inverse: coefficient 'a' is zero");
            }
            return (value - b) / a;
        }
        throw new UnsupportedOperationException("Inverse not supported for type: " + type);
    }
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }
    
    public double getA() { return a; }
    public void setA(double a) { this.a = a; }
    
    public double getB() { return b; }
    public void setB(double b) { this.b = b; }
    
    public double getC() { return c; }
    public void setC(double c) { this.c = c; }
    
    public double getD() { return d; }
    public void setD(double d) { this.d = d; }
}

/**
 * 数据组模型
 */
class DataGroup {
    
    private int id;
    private List<ChannelGroup> channelGroups = new ArrayList<>();
    private long recordCount;
    private long dataOffset;
    
    public void addChannelGroup(ChannelGroup cg) {
        cg.setDataGroupId(this.id);
        channelGroups.add(cg);
    }
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public List<ChannelGroup> getChannelGroups() { return channelGroups; }
    public void setChannelGroups(List<ChannelGroup> channelGroups) { this.channelGroups = channelGroups; }
    
    public long getRecordCount() { return recordCount; }
    public void setRecordCount(long recordCount) { this.recordCount = recordCount; }
    
    public long getDataOffset() { return dataOffset; }
    public void setDataOffset(long dataOffset) { this.dataOffset = dataOffset; }
}