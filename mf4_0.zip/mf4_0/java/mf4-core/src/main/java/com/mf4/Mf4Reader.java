package com.mf4;

import com.mf4.config.Mf4Config;
import com.mf4.enums.DataType;
import com.mf4.enums.ChannelType;
import com.mf4.exceptions.*;
import com.mf4.model.*;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.*;

/**
 * MF4 文件读取器
 * 
 * 提供完整的 MF4 文件读取功能，支持随机访问和流式读取。
 *
 * Example:
 * <pre>
 * try (Mf4Reader reader = Mf4Reader.open("measurement.mf4")) {
 *     FileHeader header = reader.getHeader();
 *     List<Channel> channels = reader.getChannels();
 *     Signal signal = reader.readChannel("Engine_Speed");
 * }
 * </pre>
 *
 * Note:
 * - 使用 try-with-resources 确保资源正确释放
 * - 大文件建议使用 Mf4StreamingReader 或设置较大的 buffer_size
 */
public class Mf4Reader implements Closeable {
    
    private final String filePath;
    private final Mf4Config config;
    private RandomAccessFile fileHandle;
    private boolean isOpen = false;
    
    private FileHeader header;
    private List<DataGroup> dataGroups = new ArrayList<>();
    private Map<String, Channel> channelMap = new HashMap<>();
    
    /**
     * 创建 Mf4Reader
     * 
     * @param filePath MF4 文件路径
     * @param config 配置选项（可选）
     * @throws Mf4FileNotFoundException 文件不存在
     */
    public Mf4Reader(String filePath, Mf4Config config) throws Mf4FileNotFoundException {
        this.filePath = filePath;
        this.config = config != null ? config : Mf4Config.getDefault();
        
        // 验证文件存在性
        File file = new File(filePath);
        if (!file.exists()) {
            throw new Mf4FileNotFoundException(filePath);
        }
        if (!file.canRead()) {
            throw new Mf4Exception("Cannot read file", filePath);
        }
    }
    
    /**
     * 打开文件（上下文管理器方式）
     * 
     * @param filePath MF4 文件路径
     * @return Mf4Reader 实例
     * @throws Mf4Exception 打开失败
     */
    public static Mf4Reader open(String filePath) throws Mf4Exception {
        Mf4Reader reader = new Mf4Reader(filePath, null);
        reader.openFile();
        return reader;
    }
    
    /**
     * 打开文件
     * 
     * @throws Mf4Exception 打开失败
     */
    private void openFile() throws Mf4Exception {
        if (isOpen) {
            return;
        }
        
        try {
            fileHandle = new RandomAccessFile(filePath, "r");
            isOpen = true;
            readFileStructure();
        } catch (FileNotFoundException e) {
            throw new Mf4FileNotFoundException(filePath);
        } catch (IOException e) {
            throw new Mf4Exception("Failed to open file: " + e.getMessage(), filePath);
        }
    }
    
    /**
     * 读取文件结构
     * 
     * @throws IOException 读取失败
     */
    private void readFileStructure() throws IOException {
        readIdBlock();
        readHeaderBlock();
        readDataGroups();
    }
    
    /**
     * 读取身份识别块（IDBLOCK）
     */
    private void readIdBlock() throws IOException {
        fileHandle.seek(0);
        
        // 读取文件标识符
        byte[] fileIdBytes = new byte[8];
        fileHandle.readFully(fileIdBytes);
        String fileId = new String(fileIdBytes, "ISO-8859-1").trim();
        
        if (!fileId.equals("MDF")) {
            throw new Mf4Exception("Invalid file identifier: " + fileId, filePath);
        }
        
        // 读取版本
        byte[] versionBytes = new byte[8];
        fileHandle.readFully(versionBytes);
        String version = new String(versionBytes, "ISO-8859-1").trim();
        
        String[] supportedVersions = {"4.00", "4.10", "4.11", "4.20"};
        if (!Arrays.asList(supportedVersions).contains(version)) {
            throw new Mf4UnsupportedVersionException(version, filePath);
        }
        
        // 读取程序标识符
        fileHandle.skipBytes(8);
        byte[] programIdBytes = new byte[8];
        fileHandle.readFully(programIdBytes);
        String programId = new String(programIdBytes, "ISO-8859-1").trim();
        
        header = new FileHeader();
        header.setVersion(version);
        header.setProgramId(programId);
    }
    
    /**
     * 读取文件头块（HDBLOCK）
     */
    private void readHeaderBlock() throws IOException {
        fileHandle.seek(64);
        
        // 读取块类型
        byte[] blockTypeBytes = new byte[4];
        fileHandle.readFully(blockTypeBytes);
        String blockType = new String(blockTypeBytes, "ISO-8859-1");
        
        if (!blockType.equals("##HD")) {
            throw new Mf4Exception("Invalid header block type: " + blockType, filePath);
        }
        
        // 读取块大小
        ByteBuffer buffer = ByteBuffer.allocate(2);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        fileHandle.readFully(buffer.array());
        int blockSize = buffer.getShort(0);
        
        // 跳过链接数量
        fileHandle.skipBytes(2);
        
        // 读取链接
        long dgFirst = readUInt64();
        fileHandle.skipBytes(8 * 4); // 跳过其他链接
        
        // 读取时间戳
        long startTimeNs = readUInt64();
        Instant instant = Instant.ofEpochSecond(
            startTimeNs / 1_000_000_000L,
            startTimeNs % 1_000_000_000L
        );
        header.setStartTime(ZonedDateTime.ofInstant(instant, ZoneOffset.UTC));
        
        // 跳过时区偏移
        fileHandle.skipBytes(4);
        
        // 读取作者、组织、项目、主题
        byte[] authorBytes = new byte[32];
        fileHandle.readFully(authorBytes);
        header.setAuthor(new String(authorBytes, "ISO-8859-1").trim());
        
        byte[] orgBytes = new byte[32];
        fileHandle.readFully(orgBytes);
        header.setOrganization(new String(orgBytes, "ISO-8859-1").trim());
        
        byte[] projectBytes = new byte[32];
        fileHandle.readFully(projectBytes);
        header.setProject(new String(projectBytes, "ISO-8859-1").trim());
        
        byte[] subjectBytes = new byte[32];
        fileHandle.readFully(subjectBytes);
        header.setSubject(new String(subjectBytes, "ISO-8859-1").trim());
    }
    
    /**
     * 读取数据组块
     */
    private void readDataGroups() throws IOException {
        // 简化实现
    }
    
    /**
     * 读取无符号64位整数
     */
    private long readUInt64() throws IOException {
        ByteBuffer buffer = ByteBuffer.allocate(8);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        fileHandle.readFully(buffer.array());
        return buffer.getLong(0);
    }
    
    /**
     * 获取文件头
     * 
     * @return FileHeader 实例
     */
    public FileHeader getHeader() throws Mf4Exception {
        if (!isOpen) {
            openFile();
        }
        return header;
    }
    
    /**
     * 获取所有通道
     * 
     * @return 通道列表
     */
    public List<Channel> getChannels() throws Mf4Exception {
        if (!isOpen) {
            openFile();
        }
        return new ArrayList<>(channelMap.values());
    }
    
    /**
     * 获取指定名称的通道
     * 
     * @param name 通道名称
     * @return Channel 实例
     * @throws Mf4ChannelNotFoundException 通道不存在
     */
    public Channel getChannel(String name) throws Mf4ChannelNotFoundException {
        if (!channelMap.containsKey(name)) {
            throw new Mf4ChannelNotFoundException(name, filePath);
        }
        return channelMap.get(name);
    }
    
    /**
     * 关闭文件
     */
    @Override
    public void close() throws IOException {
        if (fileHandle != null) {
            fileHandle.close();
            fileHandle = null;
        }
        isOpen = false;
    }
    
    @Override
    public String toString() {
        return "Mf4Reader{filePath='" + filePath + "', isOpen=" + isOpen + "}";
    }
}