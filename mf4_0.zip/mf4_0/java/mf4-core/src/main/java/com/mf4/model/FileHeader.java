package com.mf4.model;

import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 文件头数据模型
 * 
 * 存储 MF4 文件的元数据信息。
 *
 * Example:
 * <pre>
 * FileHeader header = FileHeader.builder()
 *     .author("Test Author")
 *     .organization("Test Org")
 *     .project("Test Project")
 *     .build();
 * </pre>
 */
public class FileHeader {
    
    private String version = "4.10";
    private String programId = "MF4SDK";
    private String author = "";
    private String organization = "";
    private String project = "";
    private String subject = "";
    private String comment = "";
    private ZonedDateTime startTime = ZonedDateTime.now(java.time.ZoneOffset.UTC);
    private ZonedDateTime endTime;
    private String fileUuid = UUID.randomUUID().toString();
    private Map<String, Object> customFields = new HashMap<>();
    
    /**
     * 创建 Builder
     */
    public static Builder builder() {
        return new Builder();
    }
    
    /**
     * 验证文件头
     * 
     * @return 验证错误列表
     */
    public java.util.List<String> validate() {
        java.util.List<String> errors = new java.util.ArrayList<>();
        
        String[] validVersions = {"4.00", "4.10", "4.11", "4.20"};
        if (!java.util.Arrays.asList(validVersions).contains(version)) {
            errors.add("Invalid version: " + version);
        }
        
        if (endTime != null && startTime != null && endTime.isBefore(startTime)) {
            errors.add("endTime must be >= startTime");
        }
        
        try {
            UUID.fromString(fileUuid);
        } catch (IllegalArgumentException e) {
            errors.add("Invalid UUID format: " + fileUuid);
        }
        
        return errors;
    }
    
    /**
     * 转换为 Map
     */
    public Map<String, Object> toMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("version", version);
        map.put("programId", programId);
        map.put("author", author);
        map.put("organization", organization);
        map.put("project", project);
        map.put("subject", subject);
        map.put("comment", comment);
        map.put("startTime", startTime != null ? startTime.toString() : null);
        map.put("endTime", endTime != null ? endTime.toString() : null);
        map.put("fileUuid", fileUuid);
        return map;
    }
    
    // Getters and Setters
    public String getVersion() { return version; }
    public void setVersion(String version) { this.version = version; }
    
    public String getProgramId() { return programId; }
    public void setProgramId(String programId) { this.programId = programId; }
    
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
    
    public String getOrganization() { return organization; }
    public void setOrganization(String organization) { this.organization = organization; }
    
    public String getProject() { return project; }
    public void setProject(String project) { this.project = project; }
    
    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }
    
    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }
    
    public ZonedDateTime getStartTime() { return startTime; }
    public void setStartTime(ZonedDateTime startTime) { this.startTime = startTime; }
    
    public ZonedDateTime getEndTime() { return endTime; }
    public void setEndTime(ZonedDateTime endTime) { this.endTime = endTime; }
    
    public String getFileUuid() { return fileUuid; }
    public void setFileUuid(String fileUuid) { this.fileUuid = fileUuid; }
    
    public Map<String, Object> getCustomFields() { return customFields; }
    public void setCustomFields(Map<String, Object> customFields) { this.customFields = customFields; }
    
    /**
     * Builder 类
     */
    public static class Builder {
        private FileHeader header = new FileHeader();
        
        public Builder version(String version) {
            header.version = version;
            return this;
        }
        
        public Builder programId(String programId) {
            header.programId = programId;
            return this;
        }
        
        public Builder author(String author) {
            header.author = author;
            return this;
        }
        
        public Builder organization(String organization) {
            header.organization = organization;
            return this;
        }
        
        public Builder project(String project) {
            header.project = project;
            return this;
        }
        
        public Builder subject(String subject) {
            header.subject = subject;
            return this;
        }
        
        public Builder comment(String comment) {
            header.comment = comment;
            return this;
        }
        
        public Builder startTime(ZonedDateTime startTime) {
            header.startTime = startTime;
            return this;
        }
        
        public Builder endTime(ZonedDateTime endTime) {
            header.endTime = endTime;
            return this;
        }
        
        public FileHeader build() {
            return header;
        }
    }
    
    @Override
    public String toString() {
        return "FileHeader{version='" + version + "', author='" + author + "'}";
    }
}