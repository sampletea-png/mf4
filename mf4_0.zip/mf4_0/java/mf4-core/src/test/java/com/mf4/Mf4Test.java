package com.mf4;

import com.mf4.config.Mf4Config;
import com.mf4.enums.DataType;
import com.mf4.enums.ChannelType;
import com.mf4.exceptions.Mf4Exception;
import com.mf4.model.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 测试 Mf4Writer 和 Mf4Reader
 */
class Mf4WriterReaderTest {
    
    @Test
    void testCreateBasicFile(@TempDir Path tempDir) throws Exception {
        Path filePath = tempDir.resolve("test_basic.mf4");
        
        // 创建文件
        try (Mf4Writer writer = Mf4Writer.create(filePath.toString())) {
            writer.setHeader(FileHeader.builder()
                .author("Test Author")
                .organization("Test Org")
                .project("Test Project")
                .build());
            
            int cgId = writer.addChannelGroup("Engine_Data");
            writer.addChannel(cgId, Channel.builder()
                .name("Speed")
                .unit("rpm")
                .dataType(DataType.FLOAT64)
                .build());
            
            double[] timestamps = {0.0, 0.1, 0.2, 0.3, 0.4};
            double[] values = {1000.0, 1100.0, 1200.0, 1300.0, 1400.0};
            
            writer.writeData(cgId, timestamps, Map.of("Speed", values));
        }
        
        // 验证文件已创建
        assertTrue(Files.exists(filePath));
        assertTrue(Files.size(filePath) > 0);
    }
    
    @Test
    void testCreateFileWithMultipleChannels(@TempDir Path tempDir) throws Exception {
        Path filePath = tempDir.resolve("test_multi.mf4");
        
        try (Mf4Writer writer = Mf4Writer.create(filePath.toString())) {
            writer.setHeader(FileHeader.builder()
                .author("Multi Channel Test")
                .build());
            
            int cgId = writer.addChannelGroup("Multi_Data");
            
            writer.addChannel(cgId, Channel.builder()
                .name("Signal_A")
                .unit("V")
                .dataType(DataType.FLOAT64)
                .build());
            
            writer.addChannel(cgId, Channel.builder()
                .name("Signal_B")
                .unit("A")
                .dataType(DataType.FLOAT64)
                .build());
            
            writer.addChannel(cgId, Channel.builder()
                .name("Signal_C")
                .unit("W")
                .dataType(DataType.FLOAT64)
                .build());
            
            int count = 100;
            double[] timestamps = new double[count];
            double[] valuesA = new double[count];
            double[] valuesB = new double[count];
            double[] valuesC = new double[count];
            
            for (int i = 0; i < count; i++) {
                timestamps[i] = i * 0.01;
                valuesA[i] = Math.sin(i * 0.1);
                valuesB[i] = Math.cos(i * 0.1);
                valuesC[i] = valuesA[i] * valuesB[i];
            }
            
            writer.writeData(cgId, timestamps, Map.of(
                "Signal_A", valuesA,
                "Signal_B", valuesB,
                "Signal_C", valuesC
            ));
        }
        
        assertTrue(Files.exists(filePath));
    }
    
    @Test
    void testReaderOpenFile(@TempDir Path tempDir) throws Exception {
        Path filePath = tempDir.resolve("test_read.mf4");
        
        // 先创建文件
        try (Mf4Writer writer = Mf4Writer.create(filePath.toString())) {
            writer.setHeader(FileHeader.builder().author("Read Test").build());
            int cgId = writer.addChannelGroup("Data");
            writer.addChannel(cgId, Channel.builder().name("Test").unit("V").build());
            
            double[] ts = {0.0, 1.0};
            double[] vals = {1.0, 2.0};
            writer.writeData(cgId, ts, Map.of("Test", vals));
        }
        
        // 测试读取
        try (Mf4Reader reader = Mf4Reader.open(filePath.toString())) {
            FileHeader header = reader.getHeader();
            assertNotNull(header);
            assertEquals("Read Test", header.getAuthor());
        }
    }
    
    @Test
    void testFileNotFound() {
        assertThrows(Exception.class, () -> {
            Mf4Reader.open("nonexistent_file.mf4");
        });
    }
}

/**
 * 测试配置类
 */
class Mf4ConfigTest {
    
    @Test
    void testDefaultConfig() {
        Mf4Config config = Mf4Config.getDefault();
        assertEquals(10000, config.getBufferSize());
        assertTrue(config.isCacheEnabled());
        assertTrue(config.isValidateOnWrite());
    }
    
    @Test
    void testHighPerformanceConfig() {
        Mf4Config config = Mf4Config.highPerformance();
        assertEquals(50000, config.getBufferSize());
        assertEquals(500, config.getCacheSizeMb());
        assertEquals(8, config.getMaxWorkers());
    }
    
    @Test
    void testLowMemoryConfig() {
        Mf4Config config = Mf4Config.lowMemory();
        assertEquals(1000, config.getBufferSize());
        assertEquals(20, config.getCacheSizeMb());
        assertEquals(1, config.getMaxWorkers());
    }
    
    @Test
    void testCustomConfig() {
        Mf4Config config = Mf4Config.builder()
            .bufferSize(25000)
            .cacheSizeMb(150)
            .validateOnWrite(false)
            .build();
        
        assertEquals(25000, config.getBufferSize());
        assertEquals(150, config.getCacheSizeMb());
        assertFalse(config.isValidateOnWrite());
    }
}

/**
 * 测试数据模型
 */
class ModelTest {
    
    @Test
    void testChannelBuilder() {
        Channel channel = Channel.builder()
            .id(1)
            .name("Engine_Speed")
            .unit("rpm")
            .dataType(DataType.FLOAT64)
            .type(ChannelType.VALUE)
            .byteOffset(0)
            .bitCount(64)
            .build();
        
        assertEquals(1, channel.getId());
        assertEquals("Engine_Speed", channel.getName());
        assertEquals("rpm", channel.getUnit());
        assertEquals(DataType.FLOAT64, channel.getDataType());
        assertEquals(8, channel.getByteSize());
    }
    
    @Test
    void testChannelValidation() {
        Channel validChannel = Channel.builder()
            .name("Test")
            .build();
        
        assertTrue(validChannel.validate().isEmpty());
        
        Channel invalidChannel = new Channel();
        assertFalse(invalidChannel.validate().isEmpty());
    }
    
    @Test
    void testFileHeaderBuilder() {
        FileHeader header = FileHeader.builder()
            .author("Test Author")
            .organization("Test Org")
            .project("Test Project")
            .build();
        
        assertEquals("Test Author", header.getAuthor());
        assertEquals("Test Org", header.getOrganization());
        assertEquals("Test Project", header.getProject());
        assertNotNull(header.getStartTime());
    }
    
    @Test
    void testFileHeaderValidation() {
        FileHeader header = FileHeader.builder()
            .version("4.10")
            .build();
        
        assertTrue(header.validate().isEmpty());
        
        FileHeader invalidHeader = FileHeader.builder()
            .version("3.0")
            .build();
        
        assertFalse(invalidHeader.validate().isEmpty());
    }
    
    @Test
    void testSignalStatistics() {
        double[] timestamps = {0.0, 1.0, 2.0, 3.0, 4.0};
        double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
        
        Signal signal = new Signal("Test", timestamps, values, "V");
        
        assertEquals(5, signal.getLength());
        assertEquals(1.0, signal.getSampleRate());
        
        Signal.SignalStatistics stats = signal.getStatistics();
        assertEquals(1.0, stats.min);
        assertEquals(5.0, stats.max);
        assertEquals(3.0, stats.mean);
    }
    
    @Test
    void testSignalInterpolation() {
        double[] timestamps = {0.0, 10.0};
        double[] values = {0.0, 100.0};
        
        Signal signal = new Signal("Test", timestamps, values, "V");
        
        assertEquals(50.0, signal.getValueAtTime(5.0));
        assertEquals(0.0, signal.getValueAtTime(-5.0));
        assertEquals(100.0, signal.getValueAtTime(15.0));
    }
}

/**
 * 测试枚举类
 */
class EnumTest {
    
    @Test
    void testDataType() {
        assertEquals(DataType.FLOAT64, DataType.fromMdfCode(9));
        assertEquals(DataType.INT32, DataType.fromMdfCode(6));
        
        assertEquals(8, DataType.FLOAT64.getByteSize());
        assertEquals(4, DataType.FLOAT32.getByteSize());
        
        assertEquals("float64", DataType.FLOAT64.getNumpyDtype());
    }
    
    @Test
    void testDataTypeInvalidCode() {
        assertThrows(IllegalArgumentException.class, () -> {
            DataType.fromMdfCode(999);
        });
    }
    
    @Test
    void testChannelType() {
        assertEquals(ChannelType.VALUE, ChannelType.fromCode(0));
        assertEquals(ChannelType.MASTER, ChannelType.fromCode(1));
    }
}